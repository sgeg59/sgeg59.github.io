(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.family3r = function() {
	this.initialize(img.family3r);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,518);


(lib.sl1 = function() {
	this.initialize(img.sl1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,300);


(lib.sl2 = function() {
	this.initialize(img.sl2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,303,300);


(lib.sl3 = function() {
	this.initialize(img.sl3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,300);


(lib.sl4 = function() {
	this.initialize(img.sl4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,300);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.trans21sl2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgSvAllMAAAg/HMAlfgMCMAAABLJg");
	this.shape.setTransform(30,391,1.25,2.626);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.trans21sl2, new cjs.Rectangle(-120,-240.5,300,1263), null);


(lib.trans3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AyvfQMAAAg+fMAlfAAAMAAAA+fg");
	this.shape.setTransform(30,325,1.25,2.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.trans3, new cjs.Rectangle(-120,-200,300,1050), null);


(lib.text21sl3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("AgiCvIAAkbIhhAAIAAhCIEHAAIAABCIhiAAIAAEbg");
	this.shape.setTransform(15.1,2.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("AhGCkQgegRgPgcQgQgdAAgoIAAhkQAAgnAQgdQAPgdAegQQAdgQApAAQAqAAAdAQQAeAQAPAdQAQAdAAAnIAABkQAAAogQAdQgPAcgeARQgdAQgqAAQgpAAgdgQgAgghpQgPAHgJAOQgIAOAAAUIAABkQAAAVAIAOQAJAOAPAHQAPAHARAAQASAAAPgHQAOgHAKgOQAIgOAAgVIAAhkQAAgUgIgOQgKgOgOgHQgPgIgSAAQgRAAgPAIg");
	this.shape_1.setTransform(-15.3,2.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text21sl3, new cjs.Rectangle(-32.5,-32.2,65,64.5), null);


(lib.text3sl4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("AgiCvIAAkaIhhAAIAAhDIEHAAIAABDIhhAAIAAEag");
	this.shape.setTransform(-22.5,13.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("AhHCkQgdgQgQgdQgPgdAAgoIAAhkQAAgmAPgeQAQgdAdgQQAegQApAAQAqAAAdAQQAeAQAPAdQAPAeABAmIAABkQgBAogPAdQgPAdgeAQQgdAPgqABQgpgBgegPgAgghpQgPAHgIAOQgJAOAAAUIAABkQAAAVAJAOQAIAOAPAHQAOAHASAAQASAAAPgHQAPgHAIgOQAJgOAAgVIAAhkQAAgUgJgOQgIgOgPgHQgPgIgSAAQgSAAgOAIg");
	this.shape_1.setTransform(-52.9,13.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text3sl4, new cjs.Rectangle(-70.1,-21.3,65,64.5), null);


(lib.text3sl3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("AA8HXQgrgagZgrQgZgrgBg2QABg1AZgtQAZgqArgaQArgbA2AAQA2AAArAbQAsAaAZAqQAaAtABA1QgBA2gaArQgZArgsAaQgrAZg2ABQg2gBgrgZgABzEFQgQATAAAZQAAAZAQASQAQAQAaABQAagBAQgQQARgSgBgZQABgZgRgTQgQgRgaAAQgaAAgQARgAlFEYIJepgIAtAtIpeJfgAj+iJQgrgagbgsQgZgqgBg1QABg2AZgsQAbgrArgbQArgZA2gBQA2ABArAZQAsAbAYArQAbAsAAA2QAAA1gbAqQgYAsgsAaQgrAZg2ABQg2gBgrgZgAjHlaQgQARAAAbQAAAZAQAQQAPARAbABQAbgBAPgRQAQgQAAgZQAAgbgQgRQgPgRgbgBQgbABgPARg");
	this.shape.setTransform(66.8,30.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("AijHGQhMgsgphIQgohJgBhZIC5AAQAABDAlAsQAmAqA9ACQApgBAfgUQAfgUARggQARgiAAglIAAgiQAAgmgRgiQgRgggfgUQgfgUgpgBQgpABgeAVQgeAVgQAjIi/iBIBknFIHSAAIAACmIk/AAIgtDLQAZgPAegIQAegHAjAAQBSABBHAqQBFAsAqBHQAqBJACBaIAAAMQgBBZgkBJQgmBIhFAsQhEAqhgABQhmgBhLgqg");
	this.shape_1.setTransform(-18.7,31.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text3sl3, new cjs.Rectangle(-62.9,-62.5,174.4,173.4), null);


(lib.text2sl5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape.setTransform(115.8,149);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("AgKArQgGgCgGgDQgEgEgEgHQgDgGAAgKIAAg2IANAAIAAA1QAAAIADAFQADAFAFACQAFACAEAAQAGAAAEgCQAFgDADgFQADgEAAgHIAAg2IANAAIAABWIgNAAIAAgJQgEAFgGADQgFADgGAAIgKgCg");
	this.shape_1.setTransform(108.8,145.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AgTAtIAAhXIANAAIAAAJQAEgFAFgDQAFgDAGAAIAGAAIAAANIgGAAQgFAAgFACQgEADgDAEQgDAFAAAIIAAA2g");
	this.shape_2.setTransform(101.9,145.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_3.setTransform(96.4,149);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAIAAAJADQAHADAFAIQAFAIABAMIAAAYQgBALgFAIQgFAIgHADQgJADgIAAQgFAAgGgDQgGgCgDgGIAAApgAgJgtQgGACgCAFQgDAFAAAHIAAAYQAAAGADAFQACAFAGACQAEADAFAAQAGAAAEgDQAFgCADgFQADgFAAgGIAAgYQAAgHgDgFQgDgFgFgCQgEgDgGAAQgFAAgEADg");
	this.shape_4.setTransform(89.5,146.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F2E2D").s().p("AgOArQgIgDgEgHQgFgGgBgLIANAAQABAJAGAFQAGAEAIAAQAJAAAFgEQAEgDAAgGQAAgEgCgEQgDgDgHgCIgQgEIgKgEQgFgCgDgFQgEgFAAgHQAAgJAEgFQAEgGAHgDQAGgDAJAAQAIAAAHADQAHADAEAGQAEAGABAKIgNAAQgBgIgFgEQgFgEgHAAQgIAAgEAEQgFADAAAGQAAAFADADQAEADAFABIAQAEQAKADAGAFQAGAGAAAMQAAAIgEAGQgEAFgHADQgHACgJAAQgIAAgIgDg");
	this.shape_5.setTransform(80.8,145.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F2E2D").s().p("AggAsIAAgMIAwg/IgvAAIAAgMIA/AAIAAAMIgxA/IAyAAIAAAMg");
	this.shape_6.setTransform(72.9,145.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAIAAAJADQAHADAFAIQAFAIABAMIAAAYQgBALgFAIQgFAIgHADQgJADgIAAQgFAAgGgDQgGgCgDgGIAAApgAgJgtQgFACgEAFQgCAFAAAHIAAAYQAAAGACAFQAEAFAFACQAEADAFAAQAGAAAEgDQAGgCACgFQADgFAAgGIAAgYQAAgHgDgFQgCgFgGgCQgEgDgGAAQgFAAgEADg");
	this.shape_7.setTransform(64.4,146.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_8.setTransform(51.5,145.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_9.setTransform(43.3,145.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2F2E2D").s().p("AAWA7IAAhDIgqBDIgOAAIAAhWIAOAAIAABDIAqhDIANAAIAABWgAgCglQgGAAgFgCQgFgEgDgEQgDgFAAgGIALAAQAAAEADAEQADADAFAAIAGAAQAEAAADgDQAEgEAAgEIAKAAQAAAGgDAFQgDAEgEAEQgGACgFAAg");
	this.shape_10.setTransform(34.8,143.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_11.setTransform(25.5,145.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgHAAgNIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAHADQAIADAFAGQAFAHABALIgNAAQgBgGgDgEQgDgEgEgCQgFgCgFAAQgFAAgFADQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAFAAAFgCQAEgCADgEQADgEABgGIANAAQgBALgFAHQgFAGgIADQgGADgHAAIgCAAg");
	this.shape_12.setTransform(16.9,145.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_13.setTransform(4,145.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2F2E2D").s().p("AAVAsIAAgnIgpAAIAAAnIgMAAIAAhXIAMAAIAAAlIApAAIAAglIAMAAIAABXg");
	this.shape_14.setTransform(-5,145.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2F2E2D").s().p("AAVAsIAAhDIgqBDIgMAAIAAhXIAMAAIAABDIAqhDIAOAAIAABXg");
	this.shape_15.setTransform(-18.2,145.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2F2E2D").s().p("AAFA7IAAhlIgWATIAAgQIAWgTIANAAIAAB1g");
	this.shape_16.setTransform(135.3,121.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2F2E2D").s().p("AgPA6QgIgDgFgIQgFgHAAgNIAAgBIACAAIAEAAIAFAAIACAAIAAABQAAAIADAEQADAFAFADQAFACAFAAQAJAAAGgFQAGgGAAgKQAAgGgDgFQgCgFgFgDQgFgDgGAAIgIAAIAAgLIAIAAQAJAAAGgGQAGgFAAgLQAAgGgDgFQgDgFgFgCQgFgDgGAAQgFAAgFADQgEACgDAFQgDAFAAAHIAAACIgCAAIgFAAIgEAAIgCAAIAAgCQAAgMAFgIQAFgIAIgDQAIgDAHAAQAJAAAIADQAHAEAFAHQAFAIAAALQAAAKgEAIQgEAHgGACQAGADAEAIQAEAHAAAKQAAAMgFAHQgFAIgHADQgIADgIAAQgIAAgIgDg");
	this.shape_17.setTransform(128.2,121.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2F2E2D").s().p("AgHARIAGgQIgHAAIAAgRIARAAIAAARIgGAQg");
	this.shape_18.setTransform(117.9,127.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_19.setTransform(110.9,123);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2F2E2D").s().p("AggAsIAAhXIAlAAQAJAAAGAEQAGADADAGQACAFAAAGQAAAGgCAFQgDAFgDADQAFACADAGQACAFAAAGQAAAHgCAFQgDAGgGADQgFAEgKAAgAgTAgIAaAAQAHAAADgDQADgDAAgHQAAgHgDgDQgDgEgHAAIgaAAgAgTgGIAYAAQAHAAADgDQADgEAAgGQAAgGgDgDQgDgDgHAAIgYAAg");
	this.shape_20.setTransform(102.3,123.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_21.setTransform(93.3,123);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_22.setTransform(84.2,123);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2F2E2D").s().p("AATAsIAAgiIgIACIgJABQgHAAgIgDQgIgDgFgHQgFgIAAgMIAAgXIANAAIAAAXQAAAHADAFQADAFAFACQAFACAEAAIAKgBIAHgCIAAgpIANAAIAABXgAAYgLIAAgBIAAgCIAAACIAAAAg");
	this.shape_23.setTransform(75.3,123.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2F2E2D").s().p("AgbA7IACgNQAGABAEgCQAEgCACgFIADgJIgghYIAOAAIAYBGIAZhGIAOAAIgmBoQgDAJgHAEQgEACgFAAIgJgBg");
	this.shape_24.setTransform(67.5,124.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIALAAIAZglIAPAAIgeApIAhAug");
	this.shape_25.setTransform(59.9,123.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_26.setTransform(50.8,123);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2F2E2D").s().p("AAjBGIAAgVIhFAAIAAAVIgNAAIAAgiIADAAIAEgBIADgBQACgBACgFQACgEACgIIACgWIACghIACgeIA5AAIAABpIAOAAIAAAigAgMgmIgEAtQgDATgEAKIAtAAIAAhcIghAAg");
	this.shape_27.setTransform(40.8,122.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2F2E2D").s().p("AgbA7IACgNQAGABAEgCQAEgCACgFIADgJIgghYIAOAAIAYBGIAZhGIAOAAIgmBoQgDAJgHAEQgEACgFAAIgJgBg");
	this.shape_28.setTransform(27.8,124.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgHAAgNIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAHADQAIADAFAGQAFAHABALIgNAAQgBgGgDgEQgDgEgEgCQgFgCgFAAQgFAAgFADQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAFAAAFgCQAEgCADgEQADgEABgGIANAAQgBALgFAHQgFAGgIADQgGADgHAAIgCAAg");
	this.shape_29.setTransform(19.6,123);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_30.setTransform(10.7,123);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAIAAAJADQAHADAFAIQAFAIABAMIAAAYQgBALgFAIQgFAIgHADQgJADgIAAQgFAAgGgDQgGgCgDgGIAAApgAgJgtQgGACgCAFQgDAFAAAHIAAAYQAAAGADAFQACAFAGACQAEADAFAAQAGAAAEgDQAFgCADgFQADgFAAgGIAAgYQAAgHgDgFQgDgFgFgCQgEgDgGAAQgFAAgEADg");
	this.shape_31.setTransform(1.8,124.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2F2E2D").s().p("AAfA2IAAgVIg8AAIAAAVIgNAAIAAghIAGAAIACgBIADgBQACgBACgGQABgFABgJIACgbIABgYIA1AAIAABKIAMAAIAAAhgAgLgdIgDAeQgBAMgDAIIAkAAIAAg/IgcAAg");
	this.shape_32.setTransform(-7.8,124.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_33.setTransform(-17.2,123);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_34.setTransform(-29.8,123);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2F2E2D").s().p("AATAsIAAhLIglAAIAABLIgNAAIAAhXIA/AAIAABXg");
	this.shape_35.setTransform(-38.8,123.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2F2E2D").s().p("AArAsIgZgnIgMAAIAAAnIgLAAIAAgnIgMAAIgZAnIgPAAIAeguIgbgpIAPAAIAXAlIALAAIAAglIALAAIAAAlIALAAIAXglIAPAAIgbApIAeAug");
	this.shape_36.setTransform(105.3,100.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_37.setTransform(94.7,100.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#2F2E2D").s().p("AAfA2IAAgVIg8AAIAAAVIgNAAIAAghIAGAAIACgBIADgBQACgBACgGQABgFABgJIACgbIABgZIA1AAIAABLIAMAAIAAAhgAgLgdIgDAeQgBAMgDAIIAkAAIAAg/IgcAAg");
	this.shape_38.setTransform(85.5,101.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_39.setTransform(76.3,100.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAJAAAHADQAIADAFAIQAFAIAAAMIAAAYQAAALgFAIQgFAIgIADQgHADgJAAQgFAAgGgDQgGgCgDgGIAAApgAgKgtQgFACgDAFQgCAFAAAHIAAAYQAAAGACAFQADAFAFACQAFADAFAAQAGAAAEgDQAGgCACgFQAEgFAAgGIAAgYQAAgHgEgFQgCgFgGgCQgEgDgGAAQgFAAgFADg");
	this.shape_40.setTransform(67.3,102.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#2F2E2D").s().p("AATAsIAAhLIglAAIAABLIgNAAIAAhXIA/AAIAABXg");
	this.shape_41.setTransform(58,100.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_42.setTransform(45.3,100.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#2F2E2D").s().p("AgkAsIAAgMQAGAAADgCQAEgBABgDIACgGIACgMIABgTIACggIA0AAIAABXIgNAAIAAhLIgbAAIgBAfQgBAOgCAJQgDAKgEAFQgDAEgFABIgIABIgGAAg");
	this.shape_43.setTransform(35.6,100.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_44.setTransform(27.2,100.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#2F2E2D").s().p("AAfA2IAAgVIg8AAIAAAVIgNAAIAAghIAGAAIACgBIADgBQACgBACgGQABgFABgJIACgbIABgZIA1AAIAABLIAMAAIAAAhgAgLgdIgDAeQgBAMgDAIIAkAAIAAg/IgcAAg");
	this.shape_45.setTransform(17.8,101.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_46.setTransform(9.3,100.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_47.setTransform(1.1,100.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#2F2E2D").s().p("AggAsIAAhXIAlAAQAJAAAGAEQAGADADAGQACAFAAAGQAAAGgCAFQgDAFgDADQAFACADAGQACAFAAAGQAAAHgCAFQgDAGgGADQgFAEgKAAgAgTAgIAaAAQAHAAADgDQADgDAAgHQAAgHgDgDQgDgEgHAAIgaAAgAgTgGIAYAAQAHAAADgDQADgEAAgGQAAgGgDgDQgDgDgHAAIgYAAg");
	this.shape_48.setTransform(-11.5,100.7);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#2F2E2D").s().p("AAdAsIAAhXIANAAIAABXgAgpAsIAAhXIANAAIAAAgIARAAQALAAAGAEQAGAFACAFQADAHAAAGQAAAHgDAHQgDAGgHAEQgFAEgLAAgAgcAgIARAAQAIAAADgEQAEgEAAgIQAAgIgEgEQgDgEgIAAIgRAAg");
	this.shape_49.setTransform(152.7,78.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAIAAAJADQAHADAFAIQAFAIABAMIAAAYQgBALgFAIQgFAIgHADQgJADgIAAQgFAAgGgDQgGgCgDgGIAAApgAgJgtQgFACgEAFQgCAFAAAHIAAAYQAAAGACAFQAEAFAFACQAEADAFAAQAGAAAEgDQAGgCACgFQADgFAAgGIAAgYQAAgHgDgFQgCgFgGgCQgEgDgGAAQgFAAgEADg");
	this.shape_50.setTransform(142.7,79.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#2F2E2D").s().p("AAVAsIAAhDIgqBDIgMAAIAAhXIAMAAIAABDIAqhDIANAAIAABXg");
	this.shape_51.setTransform(133.3,78.3);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_52.setTransform(124.8,78.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#2F2E2D").s().p("AghA9IAAh2IAMAAIAAAIQAEgGAGgCQAGgDAFAAQAJAAAHADQAIADAFAIQAGAIgBAMIAAAYQABALgGAIQgFAIgIADQgHADgJAAQgFAAgGgDQgGgCgEgGIAAApgAgKgtQgEACgEAFQgDAFAAAHIAAAYQAAAGADAFQAEAFAEACQAGADAEAAQAGAAAFgDQAEgCAEgFQADgFAAgGIAAgYQAAgHgDgFQgEgFgEgCQgFgDgGAAQgEAAgGADg");
	this.shape_53.setTransform(116.6,79.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_54.setTransform(107.2,78.2);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#2F2E2D").s().p("AggAsIAAhXIAlAAQAJAAAGAEQAGADADAGQACAFAAAGQAAAGgCAFQgDAFgDADQAFACADAGQACAFAAAGQAAAHgCAFQgDAGgGADQgFAEgKAAgAgTAgIAaAAQAHAAADgDQADgDAAgHQAAgHgDgDQgDgEgHAAIgaAAgAgTgGIAYAAQAHAAADgDQADgEAAgGQAAgGgDgDQgDgDgHAAIgYAAg");
	this.shape_55.setTransform(98.6,78.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIAKAAIAaglIAPAAIgdApIAgAug");
	this.shape_56.setTransform(90.4,78.3);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_57.setTransform(77.5,78.2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIALAAIAZglIAPAAIgeApIAhAug");
	this.shape_58.setTransform(69.5,78.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#2F2E2D").s().p("AATAsIAAhLIglAAIAABLIgNAAIAAhXIA/AAIAABXg");
	this.shape_59.setTransform(60.2,78.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#2F2E2D").s().p("AgbA7IACgNQAGABAEgCQAEgCACgFIADgJIgghYIAOAAIAYBGIAZhGIAOAAIgmBoQgDAJgHAEQgEACgFAAIgJgBg");
	this.shape_60.setTransform(51.7,79.9);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIAKAAIAaglIAPAAIgdApIAgAug");
	this.shape_61.setTransform(44.1,78.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_62.setTransform(35,78.2);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#2F2E2D").s().p("AATAsIAAhLIglAAIAABLIgNAAIAAhXIA/AAIAABXg");
	this.shape_63.setTransform(25.9,78.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#2F2E2D").s().p("AAWAsIAAhDIgqBDIgOAAIAAhXIAOAAIAABDIAqhDIAMAAIAABXg");
	this.shape_64.setTransform(12.9,78.3);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#2F2E2D").s().p("AAVAsIAAhDIgqBDIgMAAIAAhXIAMAAIAABDIAqhDIANAAIAABXg");
	this.shape_65.setTransform(-0.3,78.3);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#2F2E2D").s().p("AAWAsIAAhDIgqBDIgOAAIAAhXIAOAAIAABDIAqhDIAMAAIAABXg");
	this.shape_66.setTransform(-9.7,78.3);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#2F2E2D").s().p("AAZA2IAAgVIg+AAIAAhXIANAAIAABLIAlAAIAAhLIAMAAIAABLIANAAIAAAhg");
	this.shape_67.setTransform(-18.7,79.4);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIALAAIAZglIAPAAIgeApIAhAug");
	this.shape_68.setTransform(-27.5,78.3);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_69.setTransform(-36.8,78.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_70.setTransform(-49.4,78.2);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#2F2E2D").s().p("AATAsIAAhLIglAAIAABLIgNAAIAAhXIA/AAIAABXg");
	this.shape_71.setTransform(-58.4,78.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#2F2E2D").s().p("AAUAsIAAgiIgQAAIgUAiIgPAAIAXgjQgIgCgEgDQgEgEgCgEQgCgGAAgFQAAgHADgGQACgGAGgFQAGgEALAAIAgAAIAABXgAgLgbQgEADAAAIQAAAIAEAEQADADAIAAIAUAAIAAgeIgUAAQgIAAgDAEg");
	this.shape_72.setTransform(158.2,55.9);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#2F2E2D").s().p("AAWAsIAAhDIgqBDIgOAAIAAhXIAOAAIAABDIAqhDIAMAAIAABXg");
	this.shape_73.setTransform(149.6,55.9);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#2F2E2D").s().p("AAZA2IAAgVIg+AAIAAhXIANAAIAABLIAlAAIAAhLIAMAAIAABLIANAAIAAAhg");
	this.shape_74.setTransform(140.6,57);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_75.setTransform(130.8,55.8);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#2F2E2D").s().p("AAeAsIAAhAIgaAqIgHAAIgagrIAABBIgNAAIAAhXIANAAIAeAyIAdgyIANAAIAABXg");
	this.shape_76.setTransform(120.8,55.9);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAIAAAJADQAHADAFAIQAFAIABAMIAAAYQgBALgFAIQgFAIgHADQgJADgIAAQgFAAgGgDQgGgCgDgGIAAApgAgJgtQgGACgCAFQgDAFAAAHIAAAYQAAAGADAFQACAFAGACQAEADAFAAQAGAAAEgDQAFgCADgFQADgFAAgGIAAgYQAAgHgDgFQgDgFgFgCQgEgDgGAAQgFAAgEADg");
	this.shape_77.setTransform(110.7,57.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_78.setTransform(101.5,55.8);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#2F2E2D").s().p("AgFBLIAAgeIgFAAQgIAAgIgEQgIgDgFgHQgFgIAAgNIAAgUQAAgNAFgIQAFgHAIgDQAIgEAIAAIAFAAIAAgdIALAAIAAAdIAFAAQAIAAAIAEQAIADAFAHQAFAIAAANIAAAUQAAANgFAIQgFAHgIADQgIAEgIAAIgFAAIAAAegAAGAgIAFAAQAGAAAFgCQAFgDADgEQADgFAAgIIAAgUQAAgIgDgFQgDgEgFgDQgFgCgGAAIgFAAgAgVgeQgFADgDAEQgDAFAAAIIAAAUQAAAIADAFQADAEAFADQAFACAGAAIAFAAIAAhAIgFAAQgGAAgFACg");
	this.shape_79.setTransform(91.4,55.9);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#2F2E2D").s().p("AAVAsIAAgnIgoAAIAAAnIgOAAIAAhXIAOAAIAAAlIAoAAIAAglIANAAIAABXg");
	this.shape_80.setTransform(81.2,55.9);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#2F2E2D").s().p("AAVAsIAAhDIgqBDIgMAAIAAhXIAMAAIAABDIAqhDIAOAAIAABXg");
	this.shape_81.setTransform(71.8,55.9);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#2F2E2D").s().p("AATAsIAAgiIgOAAIgWAiIgOAAIAWgjQgGgCgFgDQgEgEgCgEQgCgGAAgFQAAgHACgGQACgGAHgFQAGgEALAAIAgAAIAABXgAgLgbQgEADAAAIQAAAIAEAEQAEADAHAAIATAAIAAgeIgTAAQgHAAgEAEg");
	this.shape_82.setTransform(58.8,55.9);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_83.setTransform(50.2,55.8);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#2F2E2D").s().p("AAVAsIAAgnIgpAAIAAAnIgMAAIAAhXIAMAAIAAAlIApAAIAAglIAMAAIAABXg");
	this.shape_84.setTransform(41.2,55.9);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#2F2E2D").s().p("AAAA9QgHAAgIgDQgIgDgFgIQgFgIAAgMIAAggQAAgLACgIQACgHAFgFQAFgGAHgDIAQgHIAXgIIAEAMIgYAIIgOAGQgGADgEAFQgEAFAAAIIAAACQAFgFAFgDQAGgCAFAAQAIAAAIADQAIADAFAIQAFAHAAAMIAAAPQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgHQgFADgDAEQgDAFAAAHIAAAPQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgPQgBgHgCgFQgDgEgFgDQgFgCgGAAQgFAAgFACg");
	this.shape_85.setTransform(32.1,54.3);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_86.setTransform(23.2,55.8);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAJAAAHADQAIADAFAIQAFAIAAAMIAAAYQAAALgFAIQgFAIgIADQgHADgJAAQgFAAgGgDQgGgCgDgGIAAApgAgKgtQgFACgDAFQgCAFAAAHIAAAYQAAAGACAFQADAFAFACQAFADAFAAQAGAAAEgDQAGgCACgFQAEgFAAgGIAAgYQAAgHgEgFQgCgFgGgCQgEgDgGAAQgFAAgFADg");
	this.shape_87.setTransform(14.2,57.3);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#2F2E2D").s().p("AAfA2IAAgVIg8AAIAAAVIgNAAIAAghIAGAAIACAAIADgCQACgBACgFQABgGABgJIACgbIABgZIA1AAIAABLIAMAAIAAAhgAgLgdIgDAeQgBANgDAHIAkAAIAAg+IgcAAg");
	this.shape_88.setTransform(4.6,57);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_89.setTransform(-4.6,55.8);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#2F2E2D").s().p("AATAsIAAhLIglAAIAABLIgNAAIAAhXIA/AAIAABXg");
	this.shape_90.setTransform(-13.6,55.9);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_91.setTransform(-26.4,55.8);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_92.setTransform(-35.2,55.8);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#2F2E2D").s().p("AgkAsIAAgMQAHAAACgCQADgBACgDIADgGIABgMIABgTIACggIA0AAIAABXIgNAAIAAhLIgaAAIgDAfQgBAOgCAJQgCAKgEAFQgDAEgGABIgHABIgGAAg");
	this.shape_93.setTransform(-44.9,55.9);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_94.setTransform(-53.4,55.8);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#2F2E2D").s().p("AglA7IAAh2IBCAAIAAAOIg2AAIAAAnIAdAAQALAAAGADQAHADAEAEQAEAGABAFIABALQAAAIgDAIQgDAIgHAFQgIAEgNAAgAgZAvIAdAAQAKgBAFgFQAGgFAAgKQAAgJgGgGQgFgFgKAAIgdAAg");
	this.shape_95.setTransform(-62.4,54.3);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#2F2E2D").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_96.setTransform(152.1,37);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#2F2E2D").s().p("AAeAsIAAhAIgZAqIgIAAIgagrIAABBIgNAAIAAhXIAOAAIAcAyIAegyIANAAIAABXg");
	this.shape_97.setTransform(144.1,33.5);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#2F2E2D").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_98.setTransform(136.1,37);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#2F2E2D").s().p("AggAsIAAhXIAlAAQAJAAAGAEQAGADADAGQACAFAAAGQAAAGgCAFQgDAFgDADQAFACADAGQACAFAAAGQAAAHgCAFQgDAGgGADQgFAEgKAAgAgTAgIAaAAQAHAAADgDQADgDAAgHQAAgHgDgDQgDgEgHAAIgaAAgAgTgGIAYAAQAHAAADgDQADgEAAgGQAAgGgDgDQgDgDgHAAIgYAAg");
	this.shape_99.setTransform(129.5,33.5);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIALAAIAZglIAPAAIgeApIAhAug");
	this.shape_100.setTransform(121.2,33.5);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#2F2E2D").s().p("AAOA8IAAghIg1AAIAAgLIA1hLIAOAAIAABLIAMAAIAAALIgMAAIAAAhgAgYAQIAmAAIAAg2g");
	this.shape_101.setTransform(108.3,31.9);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#2F2E2D").s().p("AAFA8IAAhnIgWAUIAAgQIAWgUIANAAIAAB3g");
	this.shape_102.setTransform(100.8,31.9);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#2F2E2D").s().p("AAFA8IAAhnIgWAUIAAgQIAWgUIANAAIAAB3g");
	this.shape_103.setTransform(95,31.9);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#2F2E2D").s().p("AgYAGIAAgKIAwAAIAAAKg");
	this.shape_104.setTransform(85.3,33.1);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#2F2E2D").s().p("AAeAsIAAhAIgaAqIgHAAIgagrIAABBIgNAAIAAhXIAOAAIAcAyIAegyIANAAIAABXg");
	this.shape_105.setTransform(72.4,33.5);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#2F2E2D").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_106.setTransform(64.5,37);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#2F2E2D").s().p("AggAsIAAhXIAlAAQAJAAAGAEQAGADADAGQACAFAAAGQAAAGgCAFQgDAFgDADQAFACADAGQACAFAAAGQAAAHgCAFQgDAGgGADQgFAEgKAAgAgTAgIAaAAQAHAAADgDQADgDAAgHQAAgHgDgDQgDgEgHAAIgaAAgAgTgGIAYAAQAHAAADgDQADgEAAgGQAAgGgDgDQgDgDgHAAIgYAAg");
	this.shape_107.setTransform(57.8,33.5);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIALAAIAZglIAPAAIgeApIAhAug");
	this.shape_108.setTransform(49.6,33.5);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#2F2E2D").s().p("AAOA8IAAghIg1AAIAAgLIA1hLIAOAAIAABLIAMAAIAAALIgMAAIAAAhgAgYAQIAmAAIAAg2g");
	this.shape_109.setTransform(36.7,31.9);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#2F2E2D").s().p("AAAA9QgHABgIgEQgIgDgFgHQgFgIAAgNIAAgBIAMAAIAAABQAAAIADAEQADAFAFADQAFACAFAAQAGAAAFgCQAEgDADgFQADgEAAgIIAAgUQgDAEgGACQgGACgGAAQgHAAgIgDQgIgDgFgIQgFgGAAgNIAAgIQAAgNAFgHQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAHAAANIAAA1QAAANgFAIQgFAHgIADQgHADgHAAIgCAAgAgKgtQgFACgDAFQgDAFAAAHIAAAIQAAAHADAFQADAFAFABQAFADAFAAQAGAAAFgDQAEgBADgFQADgFAAgHIAAgIQAAgHgDgFQgDgFgEgCQgFgDgGAAQgFAAgFADg");
	this.shape_110.setTransform(27.9,31.9);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#2F2E2D").s().p("AAQAuQgIAAgIgDQgHgDgFgIQgFgIAAgMIAAgGIgTAAIAAAmIgNAAIAAhWIANAAIAAAkIATAAIAAgFQAAgMAFgIQAFgIAHgDQAIgDAIAAQAIAAAIADQAIADAFAIQAFAIAAANIAAAWQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAAFgeQgFACgBAFQgDAFgBAHIAAAXQABAHADAFQABAFAFACQAFADAGAAQAGAAAFgDQAEgCADgFQADgFABgHIAAgXQgBgHgDgFQgDgFgEgCQgFgDgGAAQgGAAgFADg");
	this.shape_111.setTransform(13.6,33.4);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#2F2E2D").s().p("AgeAsIAAhXIANAAIAAAgIATAAQAMAAAGAEQAGAFADAFQACAHAAAGQAAAHgDAHQgDAGgGAEQgHAEgLAAgAgRAgIATAAQAIAAAEgEQAEgEAAgIQAAgIgEgEQgEgEgIAAIgTAAg");
	this.shape_112.setTransform(3.6,33.5);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#2F2E2D").s().p("AAfA2IAAgVIg8AAIAAAVIgNAAIAAghIAGAAIACAAIADgBQACgCACgFQABgGABgJIACgbIABgZIA1AAIAABLIAMAAIAAAhgAgLgdIgDAfQgBALgDAIIAkAAIAAg+IgcAAg");
	this.shape_113.setTransform(-5.8,34.6);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_114.setTransform(-15.1,33.4);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#2F2E2D").s().p("AAqA2IAAgVIhfAAIAAhXIANAAIAABLIAcAAIAAhLIAMAAIAABLIAdAAIAAhLIANAAIAABLIAMAAIAAAhg");
	this.shape_115.setTransform(-25.2,34.6);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_116.setTransform(-36.4,33.4);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#2F2E2D").s().p("AgkAsIAAgMQAGAAAEgCQADgBABgDIACgGIACgMIABgTIACggIA0AAIAABXIgNAAIAAhLIgbAAIgCAfQgBAOgBAJQgCAKgFAFQgDAEgGABIgHABIgGAAg");
	this.shape_117.setTransform(-46.1,33.5);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#2F2E2D").s().p("AATAsIAAhLIglAAIAABLIgNAAIAAhXIA/AAIAABXg");
	this.shape_118.setTransform(-54.7,33.5);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_119.setTransform(135.9,11);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#2F2E2D").s().p("AgQA8IAlhqIg2AAIAAgNIBDAAIAAANIglBqg");
	this.shape_120.setTransform(127.7,9.5);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#2F2E2D").s().p("AghA9IAAgNIApgvQAGgEADgHQAFgIAAgIQAAgHgDgEQgEgFgEgCQgFgDgGAAQgFAAgFADQgEACgEAFQgDAEAAAIIAAADIgBAAIgFAAIgEAAIgCAAIAAgDQAAgNAFgHQAFgIAIgDQAHgDAIgBQAJABAHADQAIADAFAIQAFAHAAAMQAAALgEAJQgFAHgIAJIgiAmIAzAAIAAANg");
	this.shape_121.setTransform(119.7,9.4);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#2F2E2D").s().p("AgHARIAGgQIgHAAIAAgRIARAAIAAARIgGAQg");
	this.shape_122.setTransform(109.4,15.4);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_123.setTransform(102.4,11);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#2F2E2D").s().p("AggAsIAAhXIAlAAQAJAAAGAEQAGADADAGQACAFAAAGQAAAGgCAFQgDAFgDADQAFACADAGQACAFAAAGQAAAHgCAFQgDAGgGADQgFAEgKAAgAgTAgIAaAAQAHAAADgDQADgDAAgHQAAgHgDgDQgDgEgHAAIgaAAgAgTgGIAYAAQAHAAADgDQADgEAAgGQAAgGgDgDQgDgDgHAAIgYAAg");
	this.shape_124.setTransform(93.8,11.1);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_125.setTransform(84.7,11);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAIAAAJADQAHADAFAIQAFAIAAAMIAAAYQAAALgFAIQgFAIgHADQgJADgIAAQgFAAgGgDQgGgCgDgGIAAApgAgKgtQgEACgEAFQgCAFAAAHIAAAYQAAAGACAFQAEAFAEACQAFADAFAAQAGAAAEgDQAGgCACgFQADgFABgGIAAgYQgBgHgDgFQgCgFgGgCQgEgDgGAAQgFAAgFADg");
	this.shape_126.setTransform(75.8,12.5);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_127.setTransform(66.4,11);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgHAAgNIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAHADQAIADAFAGQAFAHABALIgNAAQgBgGgDgEQgDgEgEgCQgFgCgFAAQgFAAgFADQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAFAAAFgCQAEgCADgEQADgEABgGIANAAQgBALgFAHQgFAGgIADQgGADgHAAIgCAAg");
	this.shape_128.setTransform(57.8,11);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#2F2E2D").s().p("AAVAsIAAhDIgpBDIgOAAIAAhXIAOAAIAABDIAphDIAOAAIAABXg");
	this.shape_129.setTransform(48.7,11.1);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#2F2E2D").s().p("AAYA8IAAhpIgvAAIAABpIgOAAIAAh3IBLAAIAAB3g");
	this.shape_130.setTransform(38.8,9.5);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#2F2E2D").s().p("AgbA7IACgNQAGABAEgCQAEgCACgFIADgJIgghYIAOAAIAYBGIAZhGIAOAAIgmBoQgDAJgHAEQgEACgFAAIgJgBg");
	this.shape_131.setTransform(25.8,12.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgHAAgNIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAHADQAIADAFAGQAFAHABALIgNAAQgBgGgDgEQgDgEgEgCQgFgCgFAAQgFAAgFADQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAFAAAFgCQAEgCADgEQADgEABgGIANAAQgBALgFAHQgFAGgIADQgGADgHAAIgCAAg");
	this.shape_132.setTransform(17.6,11);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_133.setTransform(8.7,11);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#2F2E2D").s().p("AghA9IAAh2IAMAAIAAAIQAEgGAGgCQAGgDAFAAQAJAAAIADQAHADAFAIQAGAIAAAMIAAAYQAAALgGAIQgFAIgHADQgIADgJAAQgFAAgGgDQgGgCgEgGIAAApgAgJgtQgGACgCAFQgEAFAAAHIAAAYQAAAGAEAFQACAFAGACQAFADAEAAQAGAAAFgDQAFgCADgFQACgFAAgGIAAgYQAAgHgCgFQgDgFgFgCQgFgDgGAAQgEAAgFADg");
	this.shape_134.setTransform(-0.2,12.5);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#2F2E2D").s().p("AAfA3IAAgWIg8AAIAAAWIgNAAIAAgiIAGAAIACAAIADgBQACgCACgFQABgGABgKIACgbIABgYIA1AAIAABLIAMAAIAAAigAgLgdIgDAfQgBAMgDAHIAkAAIAAg+IgcAAg");
	this.shape_135.setTransform(-9.8,12.2);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_136.setTransform(-19.2,11);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_137.setTransform(-31.8,11);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#2F2E2D").s().p("AATAsIAAhLIglAAIAABLIgNAAIAAhXIA/AAIAABXg");
	this.shape_138.setTransform(-40.8,11.1);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#2F2E2D").s().p("AAdAsIAAhXIANAAIAABXgAgpAsIAAhXIANAAIAAAgIARAAQALAAAGAEQAGAFACAFQADAHAAAGQAAAHgDAHQgDAGgGAEQgGAEgLAAgAgcAgIARAAQAIAAADgEQAEgEAAgIQAAgIgEgEQgDgEgIAAIgRAAg");
	this.shape_139.setTransform(149.9,-11.3);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAIAAAJADQAHADAFAIQAFAIABAMIAAAYQgBALgFAIQgFAIgHADQgJADgIAAQgFAAgGgDQgGgCgDgGIAAApgAgJgtQgGACgCAFQgDAFAAAHIAAAYQAAAGADAFQACAFAGACQAEADAFAAQAGAAAEgDQAFgCAEgFQACgFAAgGIAAgYQAAgHgCgFQgEgFgFgCQgEgDgGAAQgFAAgEADg");
	this.shape_140.setTransform(139.9,-9.9);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#2F2E2D").s().p("AAWAsIAAhDIgrBDIgMAAIAAhXIAMAAIAABDIArhDIAMAAIAABXg");
	this.shape_141.setTransform(130.5,-11.3);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_142.setTransform(122,-11.3);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#2F2E2D").s().p("AghA9IAAh2IAMAAIAAAIQAEgGAGgCQAGgDAFAAQAJAAAHADQAIADAFAIQAGAIgBAMIAAAYQABALgGAIQgFAIgIADQgHADgJAAQgFAAgGgDQgGgCgEgGIAAApgAgKgtQgEACgEAFQgDAFAAAHIAAAYQAAAGADAFQAEAFAEACQAFADAFAAQAGAAAFgDQAEgCADgFQAEgFAAgGIAAgYQAAgHgEgFQgDgFgEgCQgFgDgGAAQgFAAgFADg");
	this.shape_143.setTransform(113.8,-9.9);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_144.setTransform(104.4,-11.4);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#2F2E2D").s().p("AggAsIAAhXIAlAAQAJAAAGAEQAGADADAGQACAFAAAGQAAAGgCAFQgDAFgDADQAFACADAGQACAFAAAGQAAAHgCAFQgDAGgGADQgFAEgKAAgAgTAgIAaAAQAHAAADgDQADgDAAgHQAAgHgDgDQgDgEgHAAIgaAAgAgTgGIAYAAQAHAAADgDQADgEAAgGQAAgGgDgDQgDgDgHAAIgYAAg");
	this.shape_145.setTransform(95.8,-11.3);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIAKAAIAaglIAPAAIgeApIAhAug");
	this.shape_146.setTransform(87.6,-11.3);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_147.setTransform(74.7,-11.4);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#2F2E2D").s().p("AAdAsIAAhXIANAAIAABXgAgpAsIAAhXIANAAIAAAgIARAAQALAAAGAEQAGAFACAFQADAHAAAGQAAAHgDAHQgDAGgGAEQgGAEgLAAgAgcAgIARAAQAIAAADgEQAEgEAAgIQAAgIgEgEQgDgEgIAAIgRAAg");
	this.shape_148.setTransform(64.8,-11.3);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#2F2E2D").s().p("AAVAsIAAgnIgpAAIAAAnIgNAAIAAhXIANAAIAAAlIApAAIAAglIAMAAIAABXg");
	this.shape_149.setTransform(54.7,-11.3);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_150.setTransform(46.2,-11.3);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_151.setTransform(37.8,-11.4);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#2F2E2D").s().p("AAVAsIAAgnIgoAAIAAAnIgOAAIAAhXIAOAAIAAAlIAoAAIAAglIANAAIAABXg");
	this.shape_152.setTransform(28.8,-11.3);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#2F2E2D").s().p("AAeAsIAAhAIgaAqIgHAAIgagrIAABBIgNAAIAAhXIAOAAIAcAyIAegyIANAAIAABXg");
	this.shape_153.setTransform(18.4,-11.3);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_154.setTransform(8.3,-11.4);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIALAAIAZglIAPAAIgdApIAgAug");
	this.shape_155.setTransform(0.2,-11.3);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#2F2E2D").s().p("AAXAsIgXgkIgWAkIgPAAIAegsIgcgrIAPAAIAUAgIAWggIAOAAIgcArIAeAsg");
	this.shape_156.setTransform(-8.5,-11.3);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_157.setTransform(-16.9,-11.4);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAJAAAHADQAIADAFAIQAFAIAAAMIAAAYQAAALgFAIQgFAIgIADQgHADgJAAQgFAAgGgDQgGgCgDgGIAAApgAgKgtQgFACgDAFQgCAFAAAHIAAAYQAAAGACAFQADAFAFACQAFADAFAAQAGAAAEgDQAGgCACgFQAEgFAAgGIAAgYQAAgHgEgFQgCgFgGgCQgEgDgGAAQgFAAgFADg");
	this.shape_158.setTransform(-25.8,-9.9);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_159.setTransform(-34.3,-11.3);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_160.setTransform(-46.5,-11.4);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#2F2E2D").s().p("AAVAsIAAgnIgpAAIAAAnIgMAAIAAhXIAMAAIAAAlIApAAIAAglIAMAAIAABXg");
	this.shape_161.setTransform(-55.5,-11.3);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#2F2E2D").s().p("AAeAsIAAhAIgZAqIgIAAIgagrIAABBIgNAAIAAhXIANAAIAdAyIAegyIANAAIAABXg");
	this.shape_162.setTransform(123.7,-33.7);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#2F2E2D").s().p("AAUAsIAAgiIgQAAIgUAiIgPAAIAXgjQgIgCgEgDQgEgEgCgEQgCgGAAgFQAAgHADgGQACgGAGgFQAGgEALAAIAgAAIAABXgAgLgbQgEADAAAIQAAAIAEAEQADADAIAAIAUAAIAAgeIgUAAQgIAAgDAEg");
	this.shape_163.setTransform(113.5,-33.7);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#2F2E2D").s().p("AgeAsIAAhXIANAAIAAAgIATAAQAMAAAGAEQAGAFADAFQACAHAAAGQAAAHgDAHQgDAGgGAEQgHAEgLAAgAgRAgIATAAQAIAAAEgEQAEgEAAgIQAAgIgEgEQgEgEgIAAIgTAAg");
	this.shape_164.setTransform(105.9,-33.7);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#2F2E2D").s().p("AAeAsIAAhAIgaAqIgHAAIgagrIAABBIgNAAIAAhXIAOAAIAcAyIAegyIANAAIAABXg");
	this.shape_165.setTransform(95.8,-33.7);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_166.setTransform(85.8,-33.8);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgHAAgNIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAHADQAIADAFAGQAFAHABALIgNAAQgBgGgDgEQgDgEgEgCQgFgCgFAAQgFAAgFADQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAFAAAFgCQAEgCADgEQADgEABgGIANAAQgBALgFAHQgFAGgIADQgGADgHAAIgCAAg");
	this.shape_167.setTransform(77,-33.8);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#2F2E2D").s().p("AAeAsIAAhAIgaAqIgHAAIgagrIAABBIgNAAIAAhXIANAAIAeAyIAdgyIANAAIAABXg");
	this.shape_168.setTransform(63.1,-33.7);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#2F2E2D").s().p("AAdAsIAAhXIANAAIAABXgAgpAsIAAhXIANAAIAAAgIARAAQALAAAGAEQAGAFADAFQACAHAAAGQAAAHgDAHQgDAGgGAEQgGAEgKAAgAgcAgIARAAQAIAAADgEQAEgEAAgIQAAgIgEgEQgDgEgIAAIgRAAg");
	this.shape_169.setTransform(52,-33.7);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#2F2E2D").s().p("AAVAsIAAgnIgpAAIAAAnIgMAAIAAhXIAMAAIAAAlIApAAIAAglIAMAAIAABXg");
	this.shape_170.setTransform(41.9,-33.7);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_171.setTransform(33.4,-33.7);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_172.setTransform(25.2,-33.8);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#2F2E2D").s().p("AAfA3IAAgWIg8AAIAAAWIgNAAIAAgiIAGAAIACgBIADAAQACgCACgGQABgFABgKIACgbIABgXIA1AAIAABKIAMAAIAAAigAgLgdIgDAfQgBAMgDAHIAkAAIAAg/IgcAAg");
	this.shape_173.setTransform(15.9,-32.6);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_174.setTransform(6.7,-33.8);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#2F2E2D").s().p("AgYAsIAAhXIAxAAIAAAMIgkAAIAABLg");
	this.shape_175.setTransform(-0.8,-33.7);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_176.setTransform(-9,-33.8);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#2F2E2D").s().p("AAVAsIAAgnIgpAAIAAAnIgMAAIAAhXIAMAAIAAAlIApAAIAAglIAMAAIAABXg");
	this.shape_177.setTransform(-18.2,-33.7);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#2F2E2D").s().p("AAeAsIAAhAIgZAqIgIAAIgagrIAABBIgNAAIAAhXIANAAIAdAyIAegyIANAAIAABXg");
	this.shape_178.setTransform(-28.5,-33.7);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#2F2E2D").s().p("AATAsIAAgiIgOAAIgWAiIgOAAIAWgjQgGgCgFgDQgEgEgCgEQgCgGAAgFQAAgHACgGQACgGAHgFQAGgEALAAIAgAAIAABXgAgLgbQgEADAAAIQAAAIAEAEQAEADAHAAIATAAIAAgeIgTAAQgHAAgEAEg");
	this.shape_179.setTransform(137.5,-56.1);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgHAAgNIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAHADQAIADAFAGQAFAHABALIgNAAQgBgGgDgEQgDgEgEgCQgFgCgFAAQgFAAgFADQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAFAAAFgCQAEgCADgEQADgEABgGIANAAQgBALgFAHQgFAGgIADQgGADgHAAIgCAAg");
	this.shape_180.setTransform(129.3,-56.2);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_181.setTransform(121.1,-56.1);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_182.setTransform(112.9,-56.2);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#2F2E2D").s().p("AAUAsIAAgiIgPAAIgVAiIgPAAIAWgjQgGgCgFgDQgEgEgCgEQgCgGAAgFQAAgHADgGQACgGAGgFQAGgEALAAIAgAAIAABXgAgLgbQgEADAAAIQAAAIAEAEQAEADAHAAIAUAAIAAgeIgUAAQgHAAgEAEg");
	this.shape_183.setTransform(104,-56.1);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#2F2E2D").s().p("AgkAsIAAgMQAHAAADgCQADgBABgDIADgGIABgMIABgTIACggIA0AAIAABXIgNAAIAAhLIgbAAIgCAfQgBAOgBAJQgCAKgFAFQgDAEgGABIgHABIgGAAg");
	this.shape_184.setTransform(94.8,-56.1);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#2F2E2D").s().p("AggAsIAAhXIAlAAQAJAAAGAEQAGADADAGQACAFAAAGQAAAGgCAFQgDAFgDADQAFACADAGQACAFAAAGQAAAHgCAFQgDAGgGADQgFAEgKAAgAgTAgIAaAAQAHAAADgDQADgDAAgHQAAgHgDgDQgDgEgHAAIgaAAgAgTgGIAYAAQAHAAADgDQADgEAAgGQAAgGgDgDQgDgDgHAAIgYAAg");
	this.shape_185.setTransform(86.5,-56.1);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_186.setTransform(77.2,-56.2);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_187.setTransform(69.1,-56.1);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgHAAgNIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAHADQAIADAFAGQAFAHABALIgNAAQgBgGgDgEQgDgEgEgCQgFgCgFAAQgFAAgFADQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAFAAAFgCQAEgCADgEQADgEABgGIANAAQgBALgFAHQgFAGgIADQgGADgHAAIgCAAg");
	this.shape_188.setTransform(61.1,-56.2);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_189.setTransform(52.1,-56.2);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#2F2E2D").s().p("AAfA3IAAgWIg8AAIAAAWIgNAAIAAgiIAGAAIACgBIADgBQACgBACgGQABgFABgKIACgbIABgXIA1AAIAABKIAMAAIAAAigAgLgdIgDAeQgBAMgDAIIAkAAIAAg/IgcAAg");
	this.shape_190.setTransform(42.8,-55);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_191.setTransform(33.7,-56.2);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAIAAAJADQAHADAFAIQAFAIABAMIAAAYQgBALgFAIQgFAIgHADQgJADgIAAQgFAAgGgDQgGgCgDgGIAAApgAgJgtQgGACgCAFQgDAFAAAHIAAAYQAAAGADAFQACAFAGACQAEADAFAAQAGAAAEgDQAFgCADgFQADgFAAgGIAAgYQAAgHgDgFQgDgFgFgCQgEgDgGAAQgFAAgEADg");
	this.shape_192.setTransform(24.7,-54.7);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#2F2E2D").s().p("AATAsIAAhLIglAAIAABLIgNAAIAAhXIA/AAIAABXg");
	this.shape_193.setTransform(15.4,-56.1);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_194.setTransform(2.4,-56.2);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIAKAAIAaglIAPAAIgdApIAgAug");
	this.shape_195.setTransform(-5.5,-56.1);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#2F2E2D").s().p("AAfA3IAAgWIg8AAIAAAWIgNAAIAAgiIAGAAIACgBIADgBQACgBACgGQABgFABgKIACgbIABgXIA1AAIAABKIAMAAIAAAigAgLgdIgDAeQgBAMgDAIIAkAAIAAg/IgcAAg");
	this.shape_196.setTransform(-15,-55);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#2F2E2D").s().p("AAVAsIAAhDIgqBDIgNAAIAAhXIANAAIAABDIAqhDIAOAAIAABXg");
	this.shape_197.setTransform(-24.4,-56.1);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIAKAAIAaglIAPAAIgdApIAgAug");
	this.shape_198.setTransform(-32.7,-56.1);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#2F2E2D").s().p("AgTA5QgIgFgFgJQgFgJAAgNIAAgpQAAgMAFgJQAFgJAIgFQAJgFAKAAQALAAAIAEQAJAFAFAIQAFAIAAAMIgNAAQgBgMgHgGQgHgGgKAAQgGAAgGADQgFADgEAGQgDAGAAAJIAAApQAAAJADAGQAEAGAFADQAGAEAGAAQAKAAAHgHQAHgGABgLIANAAQAAALgFAIQgFAJgJAEQgIAEgLAAQgKAAgJgEg");
	this.shape_199.setTransform(-42.1,-57.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text2sl5, new cjs.Rectangle(-69.6,-71,234.4,226), null);


(lib.text2sl4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("ABHCvIAAldIBEAAIAAFdgAiKCvIAAldIBDAAIAABrIADAAQApABAaARQAaARAOAbQANAbgBAgQABAhgNAbQgOAbgaARQgaARgpAAgAhHBtIADAAQASgBAMgHQAMgJAFgLQAHgNAAgOQAAgOgHgMQgFgNgMgIQgMgHgSAAIgDAAg");
	this.shape.setTransform(108.5,13.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("ABWDRIAAhEIirAAIAABEIg7AAIAAiHIAdAAIBVkaIA9AAIBVEaIAdAAIAACHgAAwBKIgwi0IgxC0IBhAAg");
	this.shape_1.setTransform(78.4,16.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6CD3DC").s().p("AhHCkQgdgQgQgdQgPgdAAgoIAAhkQAAgmAPgeQAQgdAdgQQAegQApAAQAqAAAdAQQAeAQAPAdQAPAeABAmIAABkQgBAogPAdQgPAdgeAQQgdAPgqABQgpgBgegPgAgghpQgPAHgJAOQgIAOAAAUIAABkQAAAVAIAOQAJAOAPAHQAOAHASAAQASAAAPgHQAPgHAJgOQAIgOAAgVIAAhkQAAgUgIgOQgJgOgPgHQgPgIgSAAQgSAAgOAIg");
	this.shape_2.setTransform(48,13.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6CD3DC").s().p("AhkCvIAAldIDJAAIAABDIiGAAIAAEag");
	this.shape_3.setTransform(18.4,13.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CD3DC").s().p("ABHCvIAAldIBEAAIAAFdgAiKCvIAAldIBDAAIAABrIADAAQApABAaARQAbARANAbQANAbgBAgQABAhgNAbQgNAbgbARQgaARgpAAgAhHBtIADAAQASgBAMgHQAMgJAFgLQAGgNABgOQgBgOgGgMQgFgNgMgIQgMgHgSAAIgDAAg");
	this.shape_4.setTransform(-13.1,13.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6CD3DC").s().p("AiDCvIAAldICQAAQA2ABAcAaQAcAcAAAtQAAAWgIATQgHASgQAMQATANAKAUQALATAAAYQAAAugdAcQgcAbg2ABgAhABtIBXAAQAVgBALgJQAKgLAAgSQAAgTgLgKQgMgKgTAAIhXAAgAhAgiIBOAAQAUAAALgJQAMgKAAgSQAAgTgMgIQgLgJgUAAIhOAAg");
	this.shape_5.setTransform(-42.6,13.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text2sl4, new cjs.Rectangle(-60.4,-21.3,186.6,64.5), null);


(lib.text2sl3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("AhGCiQgegPgPgcQgQgcAAgmIAAhkQAAgnAQgdQAPgdAegQQAdgQApAAQApAAAcAPQAdAPAQAbQAQAcACAkIhDAAQgDgbgTgNQgRgPgaAAQgRAAgPAHQgPAIgJANQgIAPAAAUIAABkQAAAUAIANQAJAOAPAGQAPAIARAAQAaAAARgOQATgOADgaIBDAAQgCAkgQAaQgQAbgdAOQgcAOgpAAQgpAAgdgPg");
	this.shape.setTransform(69,15.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("AhHCjQgdgPgQgeQgOgcgBgnIAAhlQABgnAOgdQAQgdAdgQQAegQApAAQAqAAAeAQQAdAQAQAdQAOAdABAnIAABlQgBAngOAcQgQAegdAPQgeARgqAAQgpAAgegRgAgghqQgPAIgIAOQgJAOAAAUIAABlQAAAUAJAOQAIAOAPAHQAOAHASABQASgBAPgHQAPgHAIgOQAJgOAAgUIAAhlQAAgUgJgOQgIgOgPgIQgPgHgSAAQgSAAgOAHg");
	this.shape_1.setTransform(38.3,15.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6CD3DC").s().p("ABBCvIAAiPIiBAAIAACPIhDAAIAAldIBDAAIAACMICBAAIAAiMIBDAAIAAFdg");
	this.shape_2.setTransform(7.9,15.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6CD3DC").s().p("AhbCUQgighgCg5IBEAAQABAbASAOQASAOAbABQAYgBAPgKQAQgLABgXQAAgQgKgLQgKgKgYAAIg5AAIAAhCIAxAAQAWAAALgJQAKgKAAgPQAAgPgHgKQgHgJgLgGQgMgFgOAAQgYAAgPAPQgQAPAAAaIhEAAQABgkAPgcQAPgbAcgQQAcgPAkAAQAfAAAaALQAbALARAWQARAYAAAjQAAAWgHATQgIASgQAPQAUAMAKAUQAKATAAAaQgBAhgPAYQgQAXgcANQgbAMglAAQg9AAgiggg");
	this.shape_3.setTransform(-22.2,15.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CD3DC").s().p("AiDCvIAAldICQAAQA1AAAdAcQAdAbgBAtQABAXgJARQgHATgQAMQASANAMAUQAKATAAAXQAAAwgcAbQgdAbg2ABgAhABsIBXAAQAVAAAKgKQALgKAAgSQAAgTgMgKQgKgJgUAAIhXAAgAhAgiIBOAAQAUAAALgKQAMgJAAgSQAAgTgMgJQgLgIgUgBIhOAAg");
	this.shape_4.setTransform(-52.3,15.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text2sl3, new cjs.Rectangle(-70.1,-18.9,156.2,64.5), null);


(lib.text2sl2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AA8HXQgrgagZgrQgZgrgBg2QABg1AZgtQAZgqArgaQArgbA2AAQA2AAArAbQAsAaAZAqQAaAtABA1QgBA2gaArQgZArgsAaQgrAZg2ABQg2gBgrgZgABzEFQgQATAAAZQAAAZAQASQAQAQAaABQAagBAQgQQARgSgBgZQABgZgRgTQgQgRgaAAQgaAAgQARgAlFEYIJepgIAtAtIpeJfgAj+iJQgrgagbgsQgZgqgBg1QABg2AZgsQAbgrArgbQArgZA2gBQA2ABArAZQAsAbAYArQAbAsAAA2QAAA1gbAqQgYAsgsAaQgrAZg2ABQg2gBgrgZgAjHlaQgQARAAAbQAAAZAQAQQAPARAbABQAbgBAPgRQAQgQAAgZQAAgbgQgRQgPgRgbgBQgbABgPARg");
	this.shape.setTransform(66.8,30.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AijHGQhMgsgphIQgohJgBhZIC5AAQAABDAlAsQAmAqA9ACQApgBAfgUQAfgUARggQARgiAAglIAAgiQAAgmgRgiQgRgggfgUQgfgUgpgBQgpABgeAVQgeAVgQAjIi/iBIBknFIHSAAIAACmIk/AAIgtDLQAZgPAegIQAegHAjAAQBSABBHAqQBFAsAqBHQAqBJACBaIAAAMQgBBZgkBJQgmBIhFAsQhEAqhgABQhmgBhLgqg");
	this.shape_1.setTransform(-18.7,31.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text2sl2, new cjs.Rectangle(-62.9,-62.5,174.4,173.4), null);


(lib.text1sl5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AgKArQgHgCgFgDQgEgEgDgHQgEgGAAgKIAAg2IANAAIAAA1QAAAIADAFQADAFAFACQAFACAEAAQAFAAAFgCQAFgDADgFQADgEAAgHIAAg2IANAAIAABWIgNAAIAAgJQgDAFgHADQgFADgGAAIgKgCg");
	this.shape.setTransform(121,82.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("AgTAtIAAhXIANAAIAAAJQAEgFAEgDQAHgDAFAAIAGAAIAAANIgGAAQgFAAgFACQgEADgDAEQgDAFAAAIIAAA2g");
	this.shape_1.setTransform(114.2,82.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_2.setTransform(108.6,86);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("AgYA8IAAgNIAGAAQAEAAACgCQAAAAAAAAQABAAAAgBQAAAAAAgBQABAAAAgBIAEgMIgghYIAOAAIAYBGIAZhGIAOAAIgnBsQgCAFgEADIgNACg");
	this.shape_3.setTransform(102.3,84.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2E2D").s().p("AAKA2QgIAAgEgCQgEgCgCgFQgCgFAAgHIAAg2IgMAAIAAgMIAMAAIAAgUIAMAAIAAAUIAVAAIAAAMIgVAAIAAA3QAAAEACACQABACAFAAIANAAIAAAMg");
	this.shape_4.setTransform(95.3,81.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F2E2D").s().p("AAJA7QgIABgEgCQgEgDgCgFQgCgEAAgHIAAhhIAMAAIAABiQAAAEACABQACADAEAAIADAAIAAALg");
	this.shape_5.setTransform(90.6,80.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_6.setTransform(83.6,82.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_7.setTransform(74.9,82.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2F2E2D").s().p("AgTAtIAAhXIANAAIAAAJQADgFAFgDQAGgDAHAAIAFAAIAAANIgFAAQgGAAgFACQgEADgDAEQgDAFAAAIIAAA2g");
	this.shape_8.setTransform(68.1,82.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2F2E2D").s().p("AgXAFIAAgKIAwAAIAAAKg");
	this.shape_9.setTransform(61.5,82.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2F2E2D").s().p("AghA9IAAh2IAMAAIAAAIQAEgGAGgCQAGgDAFAAQAJAAAHADQAIADAFAIQAGAIgBAMIAAAYQABALgGAIQgFAIgIADQgHADgJAAQgFAAgGgDQgGgCgEgGIAAApgAgKgtQgEACgEAFQgDAFAAAHIAAAYQAAAGADAFQAEAFAEACQAGADAEAAQAGAAAFgDQAEgCAEgFQADgFAAgGIAAgYQAAgHgDgFQgEgFgEgCQgFgDgGAAQgEAAgGADg");
	this.shape_10.setTransform(53.6,83.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2F2E2D").s().p("AgOArQgIgDgEgHQgFgGgBgLIANAAQABAJAGAFQAGAEAIAAQAJAAAFgEQAEgDAAgGQAAgEgCgEQgDgDgHgCIgQgEIgKgEQgFgCgDgFQgEgFAAgHQAAgJAEgFQAEgGAHgDQAGgDAJAAQAIAAAHADQAHADAEAGQAEAGABAKIgNAAQgBgIgFgEQgFgEgHAAQgIAAgEAEQgFADAAAGQAAAFADADQAEADAFABIAQAEQAKADAGAFQAGAGAAAMQAAAIgEAGQgEAFgHADQgHACgJAAQgIAAgIgDg");
	this.shape_11.setTransform(44.8,82.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2F2E2D").s().p("AggAsIAAgMIAwg/IgvAAIAAgMIA/AAIAAAMIgxA/IAyAAIAAAMg");
	this.shape_12.setTransform(36.9,82.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2F2E2D").s().p("AghA9IAAh2IAMAAIAAAIQAEgGAGgCQAGgDAFAAQAJAAAHADQAIADAFAIQAGAIgBAMIAAAYQABALgGAIQgFAIgIADQgHADgJAAQgFAAgGgDQgGgCgEgGIAAApgAgKgtQgEACgDAFQgEAFAAAHIAAAYQAAAGAEAFQADAFAEACQAGADAEAAQAGAAAFgDQAEgCAEgFQACgFABgGIAAgYQgBgHgCgFQgEgFgEgCQgFgDgGAAQgEAAgGADg");
	this.shape_13.setTransform(28.5,83.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_14.setTransform(15.6,82.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_15.setTransform(7.3,82.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2F2E2D").s().p("AAVA7IAAhDIgqBDIgMAAIAAhWIAMAAIAABDIAqhDIAOAAIAABWgAgCglQgGAAgFgCQgFgEgDgFQgDgEAAgGIAKAAQAAAEADAEQAEADAFAAIAFAAQAFAAAEgDQADgEAAgEIAKAAQAAAGgDAEQgDAFgFAEQgEACgHAAg");
	this.shape_16.setTransform(-1.1,80.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_17.setTransform(-10.5,82.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgHAAgNIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAHADQAIADAFAGQAFAHABALIgNAAQgBgGgDgEQgDgEgEgCQgFgCgFAAQgFAAgFADQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAFAAAFgCQAEgCADgEQADgEABgGIANAAQgBALgFAHQgFAGgIADQgGADgHAAIgCAAg");
	this.shape_18.setTransform(-19.1,82.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_19.setTransform(-32,82.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2F2E2D").s().p("AAVAsIAAgnIgoAAIAAAnIgOAAIAAhXIAOAAIAAAlIAoAAIAAglIANAAIAABXg");
	this.shape_20.setTransform(-41,82.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2F2E2D").s().p("AAWAsIAAhDIgqBDIgOAAIAAhXIAOAAIAABDIAqhDIAMAAIAABXg");
	this.shape_21.setTransform(124,60.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2F2E2D").s().p("AAVAsIAAhDIgqBDIgMAAIAAhXIAMAAIAABDIAqhDIAOAAIAABXg");
	this.shape_22.setTransform(114.6,60.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2F2E2D").s().p("AAZA2IAAgVIg+AAIAAhWIANAAIAABKIAkAAIAAhKIANAAIAABKIANAAIAAAhg");
	this.shape_23.setTransform(105.6,61.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_24.setTransform(95.8,60);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAIAAAJADQAHADAFAIQAFAIAAAMIAAAYQAAALgFAIQgFAIgHADQgJADgIAAQgFAAgGgDQgGgCgDgGIAAApgAgKgtQgEACgEAFQgCAFAAAHIAAAYQAAAGACAFQAEAFAEACQAFADAFAAQAGAAAEgDQAGgCACgFQADgFABgGIAAgYQgBgHgDgFQgCgFgGgCQgEgDgGAAQgFAAgFADg");
	this.shape_25.setTransform(87,61.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_26.setTransform(77.7,60);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2F2E2D").s().p("AgkAsIAAgMQAGAAADgCQADgBACgDIADgGIABgMIABgTIACggIA0AAIAABXIgNAAIAAhLIgaAAIgCAfQgCAOgCAJQgCAKgEAFQgDAEgFABIgIABIgGAAg");
	this.shape_27.setTransform(68.1,60.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIALAAIAZglIAPAAIgdApIAgAug");
	this.shape_28.setTransform(60.5,60.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_29.setTransform(51.5,60);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2F2E2D").s().p("AAfA2IAAgVIg8AAIAAAVIgNAAIAAghIAGAAIACgBIADgBQACgBACgGQABgFABgJIACgbIABgYIA1AAIAABKIAMAAIAAAhgAgLgdIgDAeQgBAMgDAIIAkAAIAAg/IgcAAg");
	this.shape_30.setTransform(42.1,61.2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_31.setTransform(29.2,60);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2F2E2D").s().p("AAdAsIAAhXIANAAIAABXgAgpAsIAAhXIANAAIAAAgIASAAQAKAAAGAEQAGAFADAFQACAHAAAGQAAAHgDAHQgDAGgHAEQgFAEgKAAgAgcAgIARAAQAIAAADgEQAEgEAAgIQAAgIgEgEQgDgEgIAAIgRAAg");
	this.shape_32.setTransform(19.3,60.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2F2E2D").s().p("AAVAsIAAgnIgoAAIAAAnIgOAAIAAhXIAOAAIAAAlIAoAAIAAglIANAAIAABXg");
	this.shape_33.setTransform(9.2,60.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_34.setTransform(0.7,60.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIALAAIAZglIAPAAIgeApIAhAug");
	this.shape_35.setTransform(-6.7,60.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_36.setTransform(-15.7,60);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_37.setTransform(-24.7,60);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#2F2E2D").s().p("AghA9IAAh2IAMAAIAAAIQAEgGAGgCQAGgDAFAAQAJAAAHADQAIADAFAIQAGAIgBAMIAAAYQABALgGAIQgFAIgIADQgHADgJAAQgFAAgGgDQgGgCgEgGIAAApgAgKgtQgEACgDAFQgEAFAAAHIAAAYQAAAGAEAFQADAFAEACQAGADAEAAQAGAAAFgDQAEgCAEgFQACgFAAgGIAAgYQAAgHgCgFQgEgFgEgCQgFgDgGAAQgEAAgGADg");
	this.shape_38.setTransform(-33.6,61.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#2F2E2D").s().p("AAZA7IAAhpIgxAAIAABpIgNAAIAAh1IBKAAIAAB1g");
	this.shape_39.setTransform(-43.5,58.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#2F2E2D").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_40.setTransform(147.6,41.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#2F2E2D").s().p("AgYAsIAAhXIAxAAIAAAMIgkAAIAABLg");
	this.shape_41.setTransform(142.2,37.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#2F2E2D").s().p("AgQA6QgHgEgFgHQgFgIgBgLQAAgKAEgHQADgHAIgEQgGgEgDgGQgEgHAAgJQAAgMAFgIQAEgHAIgEQAHgDAIAAQAIAAAIADQAIAEAEAHQAFAIAAAMQAAAJgEAHQgDAGgGAEQAIAEADAHQADAHAAAKQAAALgFAIQgEAHgJAEQgHADgJAAQgIAAgIgDgAgKAJQgEACgEAFQgCAFAAAHQAAAGACAFQAEAFAEADQAFACAFAAQAGAAAEgCQAGgDACgFQADgFABgGQgBgHgDgFQgCgFgGgCQgEgDgGAAQgFAAgFADgAgOgqQgFAGAAAKQAAAHACAEQADAFAFACQAEADAFAAQAFAAAFgDQAFgCACgFQADgEAAgHQABgKgGgGQgFgGgKAAQgJAAgFAGg");
	this.shape_42.setTransform(130.2,36.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#2F2E2D").s().p("AAFA7IAAhlIgWATIAAgQIAWgUIANAAIAAB2g");
	this.shape_43.setTransform(122.5,36.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#2F2E2D").s().p("AAAA9QgHABgIgEQgIgDgFgHQgFgIAAgNIAAg1QAAgNAFgHQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAHAAANIAAA1QAAANgFAIQgFAHgIADQgHADgHAAIgCAAgAgKgtQgFACgDAFQgDAFAAAHIAAA1QAAAIADAEQADAFAFADQAFACAFAAQAGAAAFgCQAFgDADgFQACgEABgIIAAg1QgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_44.setTransform(115.4,36.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#2F2E2D").s().p("AghA8IAAgLIApgvQAGgGADgHQAFgHAAgHQAAgHgEgGQgDgEgEgDQgFgCgGAAQgFAAgFACQgEADgEAEQgCAGAAAHIAAADIgCAAIgFAAIgEAAIgCAAIAAgDQAAgNAFgIQAFgHAIgDQAIgEAHABQAJgBAHAEQAIADAFAHQAFAIAAANQAAAKgEAJQgFAHgIAJIgiAnIAzAAIAAALg");
	this.shape_45.setTransform(106.6,36);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#2F2E2D").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_46.setTransform(100,41.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#2F2E2D").s().p("AAPA7IAAgfIg2AAIAAgNIA2hKIAMAAIAABKIANAAIAAANIgNAAIAAAfgAgZAPIAoAAIAAg2g");
	this.shape_47.setTransform(93.2,36.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#2F2E2D").s().p("AAAA9QgHABgIgEQgIgDgFgHQgFgIAAgNIAAg1QAAgNAFgHQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAHAAANIAAA1QAAANgFAIQgFAHgIADQgHADgHAAIgCAAgAgKgtQgFACgDAFQgDAFAAAHIAAA1QAAAIADAEQADAFAFADQAFACAFAAQAGAAAFgCQAFgDADgFQACgEABgIIAAg1QgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_48.setTransform(84.4,36.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#2F2E2D").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_49.setTransform(77.6,41.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#2F2E2D").s().p("AAAA9QgHABgIgEQgIgDgFgHQgFgIAAgNIAAg1QAAgNAFgHQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAHAAANIAAA1QAAANgFAIQgFAHgIADQgHADgHAAIgCAAgAgKgtQgFACgDAFQgDAFAAAHIAAA1QAAAIADAEQADAFAFADQAFACAFAAQAGAAAFgCQAFgDADgFQACgEABgIIAAg1QgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_50.setTransform(70.7,36.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#2F2E2D").s().p("AgPA6QgIgDgFgIQgFgHAAgNIAAgBIACAAIAEAAIAFAAIACAAIAAABQAAAIADAEQADAFAFADQAFACAFAAQAJAAAGgFQAGgGAAgKQAAgGgDgFQgCgFgFgDQgFgDgGAAIgIAAIAAgLIAIAAQAJAAAGgGQAGgFAAgLQAAgGgDgFQgDgFgFgCQgFgDgGAAQgFAAgFADQgEACgDAFQgDAFAAAHIAAACIgCAAIgFAAIgEAAIgCAAIAAgCQAAgMAFgIQAFgIAIgDQAIgDAHAAQAJAAAIADQAHAEAFAHQAFAIAAALQAAAKgEAIQgEAHgGACQAGADAEAIQAEAHAAAKQAAAMgFAHQgFAIgHADQgIADgIAAQgIAAgIgDg");
	this.shape_51.setTransform(61.7,36.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_52.setTransform(49.2,37.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#2F2E2D").s().p("AATAsIAAhLIglAAIAABLIgNAAIAAhXIA/AAIAABXg");
	this.shape_53.setTransform(40.2,37.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#2F2E2D").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_54.setTransform(29.5,41.2);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#2F2E2D").s().p("AgYAsIAAhXIAxAAIAAAMIgkAAIAABLg");
	this.shape_55.setTransform(24.2,37.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#2F2E2D").s().p("AgPA6QgIgEgGgHQgEgIAAgLQgBgKAEgHQAEgHAGgEQgFgEgEgGQgDgHAAgJQAAgMAFgIQAFgHAHgEQAHgDAIAAQAJAAAHADQAHAEAGAHQAEAIAAAMQAAAJgDAHQgEAGgFAEQAGAEAEAHQAEAHgBAKQAAALgEAIQgGAHgIAEQgHADgJAAQgIAAgHgDgAgKAJQgEACgEAFQgDAFAAAHQAAAGADAFQAEAFAEADQAGACAEAAQAGAAAFgCQAEgDAEgFQADgFAAgGQAAgHgDgFQgEgFgEgCQgFgDgGAAQgEAAgGADgAgOgqQgFAGgBAKQAAAHAEAEQACAFAFACQAFADAEAAQAFAAAGgDQAEgCACgFQAEgEAAgHQgBgKgFgGQgFgGgKAAQgIAAgGAGg");
	this.shape_56.setTransform(12.2,36.1);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#2F2E2D").s().p("AAFA7IAAhlIgWATIAAgQIAWgUIANAAIAAB2g");
	this.shape_57.setTransform(4.5,36.1);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#2F2E2D").s().p("AAAA9QgHABgIgEQgIgDgFgHQgFgIAAgNIAAg1QAAgNAFgHQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAHAAANIAAA1QAAANgFAIQgFAHgIADQgHADgHAAIgCAAgAgKgtQgFACgDAFQgDAFAAAHIAAA1QAAAIADAEQADAFAFADQAFACAFAAQAGAAAFgCQAFgDADgFQACgEABgIIAAg1QgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_58.setTransform(-2.6,36.1);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#2F2E2D").s().p("AghA8IAAgLIApgvQAGgGAEgHQADgHAAgHQAAgHgCgGQgDgEgFgDQgFgCgGAAQgFAAgEACQgGADgCAEQgEAGAAAHIAAADIgCAAIgEAAIgFAAIgBAAIAAgDQAAgNAFgIQAFgHAIgDQAIgEAHABQAIgBAIAEQAIADAFAHQAFAIABANQgBAKgFAJQgEAHgIAJIgiAnIA0AAIAAALg");
	this.shape_59.setTransform(-11.5,36);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#2F2E2D").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_60.setTransform(-18,41.2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#2F2E2D").s().p("AgPA6QgIgDgFgIQgFgHAAgNIAAgBIACAAIAEAAIAFAAIACAAIAAABQAAAIADAEQADAFAFADQAFACAFAAQAJAAAGgFQAGgGAAgKQAAgGgDgFQgCgFgFgDQgFgDgGAAIgIAAIAAgLIAIAAQAJAAAGgGQAGgFAAgLQAAgGgDgFQgDgFgFgCQgFgDgGAAQgFAAgFADQgEACgDAFQgDAFAAAHIAAACIgCAAIgFAAIgEAAIgCAAIAAgCQAAgMAFgIQAFgIAIgDQAIgDAHAAQAJAAAIADQAHAEAFAHQAFAIAAALQAAAKgEAIQgEAHgGACQAGADAEAIQAEAHAAAKQAAAMgFAHQgFAIgHADQgIADgIAAQgIAAgIgDg");
	this.shape_61.setTransform(-24.9,36.1);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#2F2E2D").s().p("AAAA9QgHABgIgEQgIgDgFgHQgFgIAAgNIAAg1QAAgNAFgHQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAHAAANIAAA1QAAANgFAIQgFAHgIADQgHADgHAAIgCAAgAgKgtQgFACgDAFQgDAFAAAHIAAA1QAAAIADAEQADAFAFADQAFACAFAAQAGAAAFgCQAFgDADgFQACgEABgIIAAg1QgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_62.setTransform(-33.6,36.1);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#2F2E2D").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_63.setTransform(-40.4,41.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#2F2E2D").s().p("AAOA7IAAgfIg1AAIAAgNIA1hKIAOAAIAABKIAMAAIAAANIgMAAIAAAfgAgYAPIAmAAIAAg2g");
	this.shape_64.setTransform(-47.2,36.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#2F2E2D").s().p("AAFA7IAAhlIgWATIAAgQIAWgUIANAAIAAB2g");
	this.shape_65.setTransform(-54.7,36.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgHAAgNIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAHADQAIADAFAGQAFAHABALIgNAAQgBgGgDgEQgDgEgEgCQgFgCgFAAQgFAAgFADQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAFAAAFgCQAEgCADgEQADgEABgGIANAAQgBALgFAHQgFAGgIADQgGADgHAAIgCAAg");
	this.shape_66.setTransform(-65.4,37.6);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_67.setTransform(99.4,15.3);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_68.setTransform(91.2,15.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#2F2E2D").s().p("AgbA7IACgNQAGABAEgCQAEgCACgFIADgJIgghYIAOAAIAYBGIAZhGIAOAAIgmBoQgDAJgHAEQgEACgFAAIgJgBg");
	this.shape_69.setTransform(82.8,16.9);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#2F2E2D").s().p("AggAsIAAhXIAlAAQAJAAAGAEQAGADADAGQACAFAAAGQAAAGgCAFQgDAFgDADQAFACADAGQACAFAAAGQAAAHgCAFQgDAGgGADQgFAEgKAAgAgTAgIAaAAQAHAAADgDQADgDAAgHQAAgHgDgDQgDgEgHAAIgaAAgAgTgGIAYAAQAHAAADgDQADgEAAgGQAAgGgDgDQgDgDgHAAIgYAAg");
	this.shape_70.setTransform(74.5,15.3);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_71.setTransform(66.1,15.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgHAAgNIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAHADQAIADAFAGQAFAHABALIgNAAQgBgGgDgEQgDgEgEgCQgFgCgFAAQgFAAgFADQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAFAAAFgCQAEgCADgEQADgEABgGIANAAQgBALgFAHQgFAGgIADQgGADgHAAIgCAAg");
	this.shape_72.setTransform(58,15.2);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#2F2E2D").s().p("AAWA7IAAhCIgqBCIgOAAIAAhWIAOAAIAABCIAqhCIAMAAIAABWgAgCgkQgGgBgFgDQgFgCgDgGQgDgEAAgHIALAAQAAAFADAEQADADAFAAIAGAAQAEAAAEgDQADgEAAgFIAKAAQAAAHgDAEQgDAGgEACQgFADgGABg");
	this.shape_73.setTransform(48.9,13.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAOIg3AAIAAAJQAAAHADAFQADAFAFACQAFADAFAAQAIAAAGgEQAFgFACgIIANAAQgBALgFAGQgFAHgIACQgGADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAEIArAAIAAgEQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_74.setTransform(39.8,15.2);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#2F2E2D").s().p("AAfA2IAAgVIg8AAIAAAVIgNAAIAAghIAGAAIACgBIADgBQACgBACgFQABgGABgJIACgbIABgZIA1AAIAABLIAMAAIAAAhgAgLgdIgDAeQgBAMgDAIIAkAAIAAg/IgcAAg");
	this.shape_75.setTransform(30.4,16.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#2F2E2D").s().p("AAUAsIAAgiIgQAAIgUAiIgPAAIAXgjQgIgCgEgDQgEgEgCgEQgCgGAAgFQAAgHADgGQACgGAGgFQAGgEALAAIAgAAIAABXgAgLgbQgEADAAAIQAAAIAEAEQADADAIAAIAUAAIAAgeIgUAAQgIAAgDAEg");
	this.shape_76.setTransform(17.4,15.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#2F2E2D").s().p("AAWAsIAAhDIgqBDIgOAAIAAhXIAOAAIAABDIAqhDIAMAAIAABXg");
	this.shape_77.setTransform(8.8,15.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#2F2E2D").s().p("AAZA2IAAgVIg+AAIAAhXIANAAIAABLIAlAAIAAhLIAMAAIAABLIANAAIAAAhg");
	this.shape_78.setTransform(-0.2,16.4);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIALAAIAZglIAPAAIgeApIAhAug");
	this.shape_79.setTransform(-8.9,15.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#2F2E2D").s().p("AAgA7IgLghIgqAAIgLAhIgNAAIAmh2IAOAAIAnB2gAASAOIgSg3IgRA3IAjAAg");
	this.shape_80.setTransform(-18.4,13.7);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#2F2E2D").s().p("AABAQIASgQIgSgQIAAgOIAcAZIAAALIgcAZgAgcAQIASgQIgSgQIAAgOIAcAZIAAALIgcAZg");
	this.shape_81.setTransform(123.3,-7.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#2F2E2D").s().p("AAYA7IAAhoIgwAAIAABoIgMAAIAAh2IBKAAIAAB2g");
	this.shape_82.setTransform(114.1,-8.7);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#2F2E2D").s().p("AgTA5QgIgFgFgJQgFgJAAgNIAAgpQAAgMAFgJQAFgJAIgFQAJgFAKAAQALAAAIAEQAJAFAFAIQAFAIAAAMIgNAAQgBgMgHgGQgHgGgKAAQgGAAgGADQgFADgEAGQgDAGAAAJIAAApQAAAJADAGQAEAGAFADQAGAEAGAAQAKAAAHgHQAHgGABgLIANAAQAAALgFAIQgFAJgJAEQgIAEgLAAQgKAAgJgEg");
	this.shape_83.setTransform(104.2,-8.7);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#2F2E2D").s().p("AgZA0QgKgKgCgRIAOAAQABALAHAGQAHAHAKAAQALgBAGgFQAFgGAAgKQAAgKgGgFQgGgGgKAAIgQAAIAAgMIAQAAQAFAAAEgCQAFgCADgFQACgEABgHQAAgFgDgFQgCgFgFgDQgFgDgGAAQgFAAgFADQgFACgEAGQgDAFgBAIIgNAAQABgMAFgIQAFgIAIgFQAIgEAJAAQALAAAHAFQAIAFAEAIQAEAIAAAIQAAAIgDAGQgDAHgIAEQAIAEAFAHQAEAHAAAKQAAAJgDAHQgEAIgIAFQgHAFgOAAQgQAAgLgJg");
	this.shape_84.setTransform(94.7,-8.7);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#2F2E2D").s().p("AAZA7IAAhoIgxAAIAABoIgMAAIAAh2IBJAAIAAB2g");
	this.shape_85.setTransform(85,-8.7);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#2F2E2D").s().p("AABAGIAAgLIAcgZIAAAOIgSAQIASAQIAAAPgAgcAGIAAgLIAcgZIAAAOIgTAQIATAQIAAAPg");
	this.shape_86.setTransform(75.8,-7.4);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#2F2E2D").s().p("AgTA5QgJgFgFgJQgEgJgBgNIAAgpQABgMAEgJQAFgJAJgFQAJgFAKAAQAMAAAIAFQAJAFAEAJQAGAJgBAMIAAApQABANgGAJQgEAJgJAFQgIAEgMAAQgKAAgJgEgAgMgsQgGADgDAGQgDAGAAAJIAAApQAAAJADAGQADAGAGADQAGAEAGAAQAHAAAGgEQAFgDAEgGQADgGABgJIAAgpQgBgJgDgGQgEgGgFgDQgGgDgHAAQgGAAgGADg");
	this.shape_87.setTransform(63.2,-8.7);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#2F2E2D").s().p("AAgA7IgLghIgqAAIgLAhIgNAAIAmh2IAOAAIAnB2gAASAOIgSg3IgRA3IAjAAg");
	this.shape_88.setTransform(53.6,-8.7);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#2F2E2D").s().p("AASAsIgagnIgMAAIAAAnIgNAAIAAhXIANAAIAAAlIALAAIAZglIAPAAIgeApIAhAug");
	this.shape_89.setTransform(41.4,-7.1);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#2F2E2D").s().p("AAVAsIAAhDIgpBDIgOAAIAAhXIAOAAIAABDIAphDIAOAAIAABXg");
	this.shape_90.setTransform(32,-7.1);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#2F2E2D").s().p("AAqA2IAAgVIhfAAIAAhXIANAAIAABLIAcAAIAAhLIAMAAIAABLIAdAAIAAhLIANAAIAABLIAMAAIAAAhg");
	this.shape_91.setTransform(21.6,-6);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#2F2E2D").s().p("AAVA7IAAhCIgqBCIgMAAIAAhWIAMAAIAABCIAqhCIAOAAIAABWgAgCgkQgGAAgFgEQgFgCgDgGQgDgEAAgHIAKAAQAAAGADACQAEAEAFAAIAFAAQAFAAADgDQAEgEAAgFIAKAAQAAAHgDAEQgDAGgFACQgEAEgHAAg");
	this.shape_92.setTransform(10.1,-8.7);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgIAAgMIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAIADQAIADAFAIQAFAIAAAMIAAAXQAAAMgFAIQgFAIgIADQgHADgHAAIgCAAgAgKgeQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAGAAAFgDQAFgCADgFQACgFABgHIAAgXQgBgHgCgFQgDgFgFgCQgFgDgGAAQgFAAgFADg");
	this.shape_93.setTransform(0.9,-7.2);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#2F2E2D").s().p("AgiA9IAAh2IAOAAIAAAIQADgGAGgCQAGgDAFAAQAIAAAJADQAHADAFAIQAFAIABAMIAAAYQgBALgFAIQgFAIgHADQgJADgIAAQgFAAgGgDQgGgCgDgGIAAApgAgJgtQgFACgEAFQgCAFAAAHIAAAYQAAAGACAFQAEAFAFACQAEADAFAAQAGAAAEgDQAGgCACgFQADgFAAgGIAAgYQAAgHgDgFQgCgFgGgCQgEgDgGAAQgFAAgEADg");
	this.shape_94.setTransform(-8,-5.7);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#2F2E2D").s().p("AgFAsIAAhLIgcAAIAAgMIBDAAIAAAMIgcAAIAABLg");
	this.shape_95.setTransform(-16.5,-7.1);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#2F2E2D").s().p("AAAAuQgHAAgIgDQgIgDgFgIQgFgHAAgNIAAgXQAAgMAFgIQAFgIAIgDQAIgDAHAAQAIAAAHADQAIADAFAGQAFAHABALIgNAAQgBgGgDgEQgDgEgEgCQgFgCgFAAQgFAAgFADQgFACgDAFQgDAFAAAHIAAAXQAAAHADAFQADAFAFACQAFADAFAAQAFAAAFgCQAEgCADgEQADgEABgGIANAAQgBALgFAHQgFAGgIADQgGADgHAAIgCAAg");
	this.shape_96.setTransform(-24.6,-7.2);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#2F2E2D").s().p("AgTArQgGgCgEgGQgEgGAAgJQgBgFACgFQACgEAEgFQAEgDAIgCIAPgDIAVgCIAAgCQAAgHgDgFQgDgFgFgCQgFgDgGAAQgGAAgGAFQgGAEgCAIIgNAAQABgLAGgGQAFgGAHgDQAIgDAGAAQAJAAAIADQAHADAFAIQAGAIAAANIAAA2IgNAAIAAgJQgEAGgHACQgHADgIAAQgIAAgHgDgAAAADQgJACgEACQgFADgBADQgCADAAAEQAAAGAFAEQAFAEAJAAQAGAAAGgDQAFgCAEgFQADgEAAgHIAAgMIgWACg");
	this.shape_97.setTransform(-33.7,-7.2);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#2F2E2D").s().p("AgZA0QgKgKgCgRIAOAAQABALAHAGQAHAHAKAAQALgBAGgFQAFgGAAgKQAAgKgGgFQgGgGgKAAIgQAAIAAgMIAQAAQAFAAAEgCQAFgCADgFQACgEABgHQAAgFgDgFQgCgFgFgDQgFgDgGAAQgFAAgFADQgFACgEAGQgDAFgBAIIgNAAQABgMAFgIQAFgIAIgFQAIgEAJAAQALAAAHAFQAIAFAEAIQAEAIAAAIQAAAIgDAGQgDAHgIAEQAIAEAFAHQAEAHAAAKQAAAJgDAHQgEAIgIAFQgHAFgOAAQgQAAgLgJg");
	this.shape_98.setTransform(-42.7,-8.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text1sl5, new cjs.Rectangle(-71.9,-22,223.9,114), null);


(lib.text1sl4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("AhqCvIAAldIDVAAIAABDIiRAAIAABJIBuAAIAABBIhuAAIAABOICRAAIAABCg");
	this.shape.setTransform(109.3,13.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("AiGCvIAAldIA/AAIAAEbIApAAIAAkbIA9AAIAAEbIAqAAIAAkbIA/AAIAAFdg");
	this.shape_1.setTransform(78.4,13.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6CD3DC").s().p("AiDCvIAAldIBDAAIAABrIBLAAQApABAbARQAbARANAbQANAbAAAgQAAAhgNAbQgNAbgbARQgbARgpAAgAhABtIBLAAQATgBALgHQAMgJAGgLQAGgNAAgOQAAgOgGgMQgGgNgMgIQgLgHgTAAIhLAAg");
	this.shape_2.setTransform(49.2,13.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6CD3DC").s().p("ABWCvIhWj2IhXD2IhEAAIB9ldIA9AAIB9Fdg");
	this.shape_3.setTransform(17.7,13.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CD3DC").s().p("AhGCkQgegQgPgdQgPgdgBgoIAAhkQABgmAPgeQAPgdAegQQAdgQApAAQAqAAAeAQQAdAQAQAdQAPAeAAAmIAABkQAAAogPAdQgQAdgdAQQgeAPgqABQgpgBgdgPgAgghpQgPAHgJAOQgIAOAAAUIAABkQAAAVAIAOQAJAOAPAHQAPAHARAAQATAAAOgHQAOgHAJgOQAJgOAAgVIAAhkQAAgUgJgOQgJgOgOgHQgOgIgTAAQgRAAgPAIg");
	this.shape_4.setTransform(-12.8,13.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6CD3DC").s().p("AiDCvIAAldIDnAAIAABDIikAAIAABJIBWAAQA0AAAcAdQAeAcAAAyQAAAugdAcQgcAbg2ABgAhABtIBXAAQAVgBALgJQAKgLAAgSQAAgTgLgKQgMgKgTAAIhXAAg");
	this.shape_5.setTransform(-42.6,13.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text1sl4, new cjs.Rectangle(-60.4,-21.3,186.6,64.5), null);


(lib.text1sl3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("ABBDWIAAjrIiBDrIhDAAIAAldIBDAAIAADqICBjqIBDAAIAAFdgAgOidQgYgBgPgQQgQgPgBgYIAZAAQAAAOAJAJQAJAIANABIAdAAQAOgBAIgIQAJgJAAgOIAZAAQgBAYgPAPQgQAQgYABg");
	this.shape.setTransform(108.8,9.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("ABICvIAAldIBCAAIAAFdgAiKCvIAAldIBDAAIAABrIACAAQAqABAbARQAaARANAbQAMAbAAAgQAAAhgMAbQgNAbgaARQgbARgqAAgAhHBtIACAAQATgBAMgHQAMgJAFgLQAHgNgBgOQABgOgHgMQgFgNgMgIQgMgHgTAAIgCAAg");
	this.shape_1.setTransform(78.1,13.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6CD3DC").s().p("AiDCvIAAldICQAAQA2ABAcAaQAdAcAAAtQgBAWgHATQgIASgQAMQATANAKAUQALATAAAYQAAAugdAcQgcAbg2ABgAhABtIBXAAQAVgBALgJQAKgLAAgSQAAgTgLgKQgMgKgTAAIhXAAgAhAgiIBPAAQATAAALgJQALgKAAgSQAAgTgLgIQgLgJgTAAIhPAAg");
	this.shape_2.setTransform(48.6,13.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6CD3DC").s().p("AiDCvIAAldICOAAQAqAAAaARQAbAQANAcQANAcAAAgQAAAggNAaQgNAcgbARQgaARgqAAIhLAAIAABsgAhAABIBLAAQATgBALgGQAMgJAGgMQAGgNAAgNQAAgOgGgMQgGgMgMgJQgLgHgTAAIhLAAg");
	this.shape_3.setTransform(18.8,13.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CD3DC").s().p("AhqCvIAAldIDVAAIAABDIiSAAIAABJIBvAAIAABBIhvAAIAABOICSAAIAABCg");
	this.shape_4.setTransform(-12.3,13.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6CD3DC").s().p("ABBCvIAAkaIiBAAIAAEaIhDAAIAAldIEHAAIAAFdg");
	this.shape_5.setTransform(-43.2,13.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text1sl3, new cjs.Rectangle(-60.4,-21.3,186.6,64.5), null);


(lib.text1sl2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABXCvIgZhHIh7AAIgZBHIhGAAIB9ldIA/AAIB9FdgAAnApIgnhwIgmBwIBNAAg");
	this.shape.setTransform(108.8,13.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AA1CvIhaiQIghAAIAACQIhDAAIAAldIBDAAIAACMIAhAAIBdiMIBSAAIh4CpIB1C0g");
	this.shape_1.setTransform(78.9,13.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABWDRIAAhEIirAAIAABEIg7AAIAAiHIAdAAIBVkaIA9AAIBVEaIAdAAIAACHgAAwBKIgwi0IgxC0IBhAAg");
	this.shape_2.setTransform(48,16.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ABBCvIAAjqIiBDqIhDAAIAAldIBDAAIAADqICBjqIBDAAIAAFdg");
	this.shape_3.setTransform(17.6,13.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AA1CvIhaiQIghAAIAACQIhDAAIAAldIBDAAIAACMIAhAAIBdiMIBSAAIh4CpIB1C0g");
	this.shape_4.setTransform(-12.3,13.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhGCiQgegQgPgbQgQgcAAgmIAAhkQAAgnAQgdQAPgdAegQQAdgQApgBQApABAcAPQAeAPAPAcQAQAbACAlIhDAAQgDgbgSgPQgSgOgaAAQgRAAgPAHQgPAIgJAOQgIAOAAAUIAABkQAAAUAIANQAJANAPAIQAPAHARAAQAaAAASgOQASgOADgZIBDAAQgCAjgQAaQgPAageAPQgcAPgpAAQgpgBgdgPg");
	this.shape_5.setTransform(-43,12.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text1sl2, new cjs.Rectangle(-60.4,-21.3,186.6,64.5), null);


(lib.text31sl4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("ABBCvIAAkbIiBAAIAAEbIhDAAIAAldIEHAAIAAFdg");
	this.shape.setTransform(45.5,2.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("AhHCiQgdgQgQgbQgPgcAAgmIAAhkQAAgnAPgdQAQgdAdgQQAegQApgBQApABAdAPQAdAPAQAbQAPAbACAmIhEAAQgDgbgRgPQgSgOgaAAQgSAAgOAHQgPAIgIAOQgJAOAAAUIAABkQAAAUAJANQAIANAPAIQAOAHASAAQAaAAASgOQARgOADgaIBEAAQgCAkgPAaQgQAbgdAOQgdAOgpAAQgpAAgegPg");
	this.shape_1.setTransform(15.4,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6CD3DC").s().p("AhbCUQgigggCg6IBEAAQABAbASAPQASAOAbgBQAYABAPgLQAQgLABgYQAAgQgKgKQgKgKgYAAIg5AAIAAhCIAxAAQAWAAALgJQAKgKAAgPQAAgPgHgKQgHgJgLgGQgMgFgOAAQgYAAgPAQQgQAPAAAZIhEAAQABglAPgbQAPgbAcgQQAcgPAkAAQAfAAAaALQAbALARAWQARAYAAAjQAAAXgHASQgIASgQAOQAUANAKAUQAKATAAAaQgBAhgPAXQgQAYgcAMQgbANglAAQg9gBgigfg");
	this.shape_2.setTransform(-15,2.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6CD3DC").s().p("ABBCvIAAkbIiBAAIAAEbIhDAAIAAldIEHAAIAAFdg");
	this.shape_3.setTransform(-45.7,2.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text31sl4, new cjs.Rectangle(-62.9,-32.2,125.8,64.5), null);


(lib.text4sl1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AgnCvIAAhQIBPAAIAABQgAggA8IAAjqIBBAAIAADqg");
	this.shape.setTransform(189.3,16.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("ABBCvIAAjqIiBDqIhDAAIAAldIBDAAIAADqICBjqIBDAAIAAFdg");
	this.shape_1.setTransform(158.9,16.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AA1CvIhaiQIghAAIAACQIhDAAIAAldIBDAAIAACMIAhAAIBdiMIBSAAIh4CpIB1C0g");
	this.shape_2.setTransform(129,16.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("ABWDRIAAhEIirAAIAABEIg7AAIAAiHIAdAAIBVkaIA9AAIBVEaIAdAAIAACHgAAwBKIgwi0IgxC0IBhAAg");
	this.shape_3.setTransform(98.1,20);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2E2D").s().p("ABBCvIAAjqIiBDqIhDAAIAAldIBDAAIAADqICBjqIBDAAIAAFdg");
	this.shape_4.setTransform(67.7,16.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F2E2D").s().p("AA1CvIhaiQIghAAIAACQIhDAAIAAldIBDAAIAACMIAhAAIBdiMIBSAAIh4CpIB1C0g");
	this.shape_5.setTransform(37.8,16.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F2E2D").s().p("AhHCiQgdgPgQgdQgPgcAAglIAAhkQAAgnAPgdQAQgdAdgQQAegQApgBQApABAcAPQAdAPAQAcQAQAaACAmIhDAAQgDgcgTgOQgRgOgaAAQgRAAgPAIQgPAHgJANQgIAPAAAUIAABkQAAAUAIANQAJANAPAHQAPAIARAAQAaAAARgOQATgNADgaIBDAAQgCAjgQAaQgQAbgdAOQgcAPgpAAQgpAAgegQg");
	this.shape_6.setTransform(7.1,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text4sl1, new cjs.Rectangle(-10.3,-17.9,217,64.5), null);


(lib.text3sl1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AhpCvIAAldIDTAAIAABDIiRAAIAABJIBuAAIAABBIhuAAIAABOICRAAIAABCg");
	this.shape.setTransform(200.2,34.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("ABBCvIAAjqIiBDqIhDAAIAAldIBDAAIAADqICBjqIBDAAIAAFdg");
	this.shape_1.setTransform(169.2,34.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AiHCvIAAldIA/AAIAAEbIAqAAIAAkbIA9AAIAAEbIApAAIAAkbIA/AAIAAFdg");
	this.shape_2.setTransform(138.9,34.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("AiDCvIAAldIBDAAIAABrIBLAAQAqABAaARQAbAQANAcQANAbAAAgQAAAhgNAbQgNAcgbAQQgaARgqAAgAhABtIBLAAQASAAANgJQAMgIAFgLQAGgNAAgOQAAgOgGgMQgFgMgMgIQgNgIgSAAIhLAAg");
	this.shape_3.setTransform(109.6,34.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2E2D").s().p("ABWCvIhWj2IhXD2IhEAAIB9ldIA9AAIB9Fdg");
	this.shape_4.setTransform(78.1,34.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F2E2D").s().p("AhHCjQgdgPgQgeQgPgdAAgnIAAhkQAAgmAPgdQAQgeAdgQQAegQApAAQAqAAAdAQQAeAQAPAeQAQAdAAAmIAABkQAAAngQAdQgPAegeAPQgdAQgqABQgpgBgegQgAgghpQgPAHgJAOQgIAOAAAUIAABkQAAAVAIANQAJAPAPAHQAPAIARgBQASABAPgIQAPgHAJgPQAIgNAAgVIAAhkQAAgUgIgOQgJgOgPgHQgPgIgSAAQgRAAgPAIg");
	this.shape_5.setTransform(47.6,34.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F2E2D").s().p("AiDCvIAAldIDmAAIAABDIijAAIAABJIBXAAQAzABAdAcQAcAcABAyQAAAugcAcQgcAcg3AAgAhABtIBXAAQAVAAAKgKQALgLAAgSQAAgTgMgKQgKgKgUAAIhXAAg");
	this.shape_6.setTransform(17.8,34.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text3sl1, new cjs.Rectangle(0,0,217,64.5), null);


(lib.text2sl1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AhIALIAAgVICQAAIAAAVg");
	this.shape.setTransform(199.6,38);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("AhqCvIAAldIDVAAIAABDIiSAAIAABJIBvAAIAABBIhvAAIAABOICSAAIAABCg");
	this.shape_1.setTransform(139.4,34.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AiDCvIAAldIBDAAIAABrIBLAAQAqABAaARQAbAQANAcQANAbAAAgQAAAhgNAbQgNAcgbAQQgaARgqAAgAhABtIBLAAQASAAANgJQAMgIAFgLQAGgNAAgOQAAgOgGgMQgFgMgMgIQgNgIgSAAIhLAAg");
	this.shape_2.setTransform(109.6,34.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("ABECvIAAjgIguCCIgrAAIgtiCIAADgIhBAAIAAldIBFAAIA+CyIA/iyIBFAAIAAFdg");
	this.shape_3.setTransform(78,34.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2E2D").s().p("AhpCvIAAldIDTAAIAABDIiRAAIAABJIBuAAIAABBIhuAAIAABOICRAAIAABCg");
	this.shape_4.setTransform(48.2,34.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F2E2D").s().p("AhHCiQgdgQgQgcQgPgcAAglIAAhkQAAgnAPgdQAQgdAdgQQAegQApgBQApABAcAPQAdAPAQAcQAQAaACAmIhDAAQgDgcgTgOQgRgOgaAAQgRAAgPAIQgPAHgJAOQgIAOAAAUIAABkQAAAUAIANQAJANAPAIQAPAHARAAQAaAAARgOQATgNADgaIBDAAQgCAjgQAaQgQAbgdAOQgcAPgpAAQgpAAgegQg");
	this.shape_5.setTransform(17.5,34.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text2sl1, new cjs.Rectangle(0,0,217,64.5), null);


(lib.text1sl1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("ABBDWIAAjqIiBDqIhDAAIAAldIBDAAIAADqICBjqIBDAAIAAFdgAgOidQgYgBgQgPQgPgQgBgYIAZAAQAAAOAJAJQAIAIAOABIAdAAQANgBAJgIQAJgJAAgOIAYAAQAAAYgQAQQgQAPgXABg");
	this.shape.setTransform(199.6,30.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("AhGCjQgegPgPgeQgQgdAAgnIAAhkQAAgmAQgdQAPgeAegQQAdgQApAAQAqAAAdAQQAeAQAPAeQAQAdAAAmIAABkQAAAngQAdQgPAegeAPQgdAQgqABQgpgBgdgQgAgghpQgPAHgJAOQgIAOAAAUIAABkQAAAVAIANQAJAPAPAHQAPAIARgBQASABAPgIQAOgHAKgPQAIgNAAgVIAAhkQAAgUgIgOQgKgOgOgHQgPgIgSAAQgRAAgPAIg");
	this.shape_1.setTransform(169.2,34.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AiHCvIAAldIA/AAIAAEbIAqAAIAAkbIA9AAIAAEbIApAAIAAkbIA/AAIAAFdg");
	this.shape_2.setTransform(138.9,34.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("AiDCvIAAldIBDAAIAABrIBLAAQAqABAaARQAbAQANAcQANAbAAAgQAAAhgNAbQgNAcgbAQQgaARgqAAgAhABtIBLAAQASAAANgJQAMgIAFgLQAGgNAAgOQAAgOgGgMQgFgMgMgIQgNgIgSAAIhLAAg");
	this.shape_3.setTransform(109.6,34.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2E2D").s().p("ABWCvIhWj2IhXD2IhEAAIB9ldIA9AAIB9Fdg");
	this.shape_4.setTransform(78.1,34.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F2E2D").s().p("AhHCjQgdgPgQgeQgPgdAAgnIAAhkQAAgmAPgdQAQgeAdgQQAegQApAAQAqAAAdAQQAeAQAPAeQAQAdAAAmIAABkQAAAngQAdQgPAegeAPQgdAQgqABQgpgBgegQgAgghpQgPAHgJAOQgIAOAAAUIAABkQAAAVAIANQAJAPAPAHQAPAIARgBQASABAPgIQAPgHAJgPQAIgNAAgVIAAhkQAAgUgIgOQgJgOgPgHQgPgIgSAAQgRAAgPAIg");
	this.shape_5.setTransform(47.6,34.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F2E2D").s().p("AiDCvIAAldIDmAAIAABDIijAAIAABJIBXAAQAzABAdAcQAcAcABAyQAAAugcAcQgcAcg3AAgAhABtIBXAAQAVAAAKgKQALgLAAgSQAAgTgMgKQgKgKgUAAIhXAAg");
	this.shape_6.setTransform(17.8,34.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text1sl1, new cjs.Rectangle(0,0,217,64.5), null);


(lib.sl4300x1050 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.sl4();
	this.instance.parent = this;
	this.instance.setTransform(-150,-150);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sl4300x1050, new cjs.Rectangle(-150,-150,300,300), null);


(lib.sl3300x1050 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.sl3();
	this.instance.parent = this;
	this.instance.setTransform(-150,-150);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sl3300x1050, new cjs.Rectangle(-150,-150,300,300), null);


(lib.sl2300x1050 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.sl2();
	this.instance.parent = this;
	this.instance.setTransform(-151.5,-150);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sl2300x1050, new cjs.Rectangle(-151.5,-150,303,300), null);


(lib.sl1300x1050 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.sl1();
	this.instance.parent = this;
	this.instance.setTransform(-150,-150);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sl1300x1050, new cjs.Rectangle(-150,-150,300,300), null);


(lib.logoai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AgwBFQgTgQgBggIAoAAQACAZAZAAQAZAAAAgSQAAgPgUAAIgMAAIAAgdIAMAAQARAAABgOQAAgHgHgEQgGgEgKAAQgZAAgCAZIgoAAQABgcAQgRQASgTAgAAQAfAAASAOQASANAAAWQAAAJgFAIQgEAJgIAFQAUAIAAAXQAAAbgTAQQgUAPgeAAQgdAAgTgQg");
	this.shape.setTransform(42.2,8.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("AAbBRIAAh5Ig1AAIAAB5IgpAAIAAihICHAAIAAChg");
	this.shape_1.setTransform(42,43.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AAbBRIAAh5Ig1AAIAAB5IgpAAIAAihICHAAIAAChg");
	this.shape_2.setTransform(6.8,8.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("AgxBCQgSgSAAgfIAAgiQAAgeASgSQASgTAfAAQAfAAASASQASAQABAeIgpAAQgBgMgHgGQgIgHgLAAQgLAAgHAHQgIAHAAANIAAAkQAAANAIAIQAHAHALAAQALAAAIgHQAHgGABgMIApAAQgBAdgSARQgSASgfAAQgfAAgSgTg");
	this.shape_3.setTransform(6.8,43.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CD3DC").s().p("AjfDkIgGh7IFblaIBbADIAABYIAUAeIlqFqg");
	this.shape_4.setTransform(25.2,26.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,49.2,52.2);


(lib.frametextsl1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6CD3DC").ss(1,1,1).p("Axwz2MAjhAAAMAAAAntMgjhAAAg");
	this.shape.setTransform(34.1,49.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.frametextsl1, new cjs.Rectangle(-80.6,-78.4,229.4,256.1), null);


(lib.familyvert = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.family3r();
	this.instance.parent = this;
	this.instance.setTransform(-150,-259);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.familyvert, new cjs.Rectangle(-150,-259,300,518), null);


(lib.desclogoai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AB3BeIAAgNIgoAAIAAg7IALAAIAAAwIAGAAIAAgwIAKAAIAAAwIAGAAIAAgwIALAAIAAAwIAHAAIAAAYgAgJBRQgEgBgDgDQgDgEgBgEQgCgDAAgGIAAgRQAAgEACgFIAEgHQADgCAEgCQAFgCAEABQAGgBADACQAEACADACQAEAEABADQABAFAAAEIAAARQAAAGgBADQgCAEgDAEQgDADgEABQgDACgGAAQgEAAgFgCgAgFAiIgEAEQgBACAAADIAAARQAAAEABADIAEADIAFABIAFgBQADgBABgCQACgDAAgEIAAgRQAAgDgCgCIgEgEQgCgBgDgBQgCABgDABgAkMBQQgEgCgEgFQgCgFAAgGIALAAQAAADACACQABADADAAIAFABIAFgBIADgCQABAAAAgBQAAAAAAgBQABAAAAgBQAAgBAAgBIgBgDIgCgCIgFAAIgKAAIAAgMIAJAAQAEAAABgCQABAAAAAAQABgBAAAAQAAgBAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAgBIgEgBIgFACQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAgBABIgBAFIgMAAQAAgEACgFQACgDACgDIAHgEIAJgBIAFAAIAGACQADACABABQADADAAACQACADAAAEQAAAEgCADIgEAFQADACACAEQACADAAAFQAAAEgCADIgEAGIgHADIgIACQgHAAgFgDgADYBRIgPgXIgGAAIAAAXIgLAAIAAg7IALAAIAAAYIAGAAIAQgYIAOAAIgVAdIAUAegACmBRIAAgnIgWAnIgMAAIAAg7IAMAAIAAAoIAWgoIALAAIAAA7gAA+BRIAAgnIgWAnIgLAAIAAg7IALAAIAAAoIAWgoIAMAAIAAA7gAhHBRIAAg7IAYAAIAJACQAEABADAEIADAGIACAIIgCAHIgDAHQgDADgEABQgDACgGAAIgNAAIAAASgAg8A0IANAAIAEgBIADgCIACgDIAAgDIAAgDIgCgEIgDgCIgEgBIgNAAgAhsBRIAAgwIgRAAIAAgLIAtAAIAAALIgRAAIAAAwgAijBQIgHgEQgDgDgCgEQgBgEAAgFIAAgRQAAgEABgFIAFgHQADgCAEgCQAEgCAFABQAFgBAFACIAHAEIAEAGQACAEAAAFIgMAAIgBgFIgEgDQgCgBgEgBQgDABgCABIgEAEQgCACAAADIAAARQAAAEACACQACADACAAQACACADAAIAGgBIAEgDQABgCAAgDIAMAAQAAAEgCAEIgEAGQgDADgEABIgKABQgFAAgEgBgAi/BRIgEgMIgVAAIgEAMIgMAAIAVg7IALAAIAVA7gAjHA7IgHgTIgGATIANAAgAAxASIgFgBIgDgDQgCgCAAgDIAFAAIAAADIACACIADABIAFAAIADgBIACgCIAAgDIAEAAIgBAFIgDADIgFABgAjXgVQgEgBgDgEQgDgBgCgFIgBgJIAAgRIABgJQACgFADgDIAHgDQAEgDAFAAQAGAAAEADQAEABADACQADADABAFIACAJIAAARIgCAJQgCAFgCABQgCAEgFABQgEACgGAAQgFAAgEgCgAjThEIgEAEQgCADAAADIAAARQAAADACACIAEAFIAFABIAGgBIAEgFQABgCAAgDIAAgRQAAgDgBgDIgEgEIgGgBgAENgUIAAgoIgWAoIgMAAIAAg8IAMAAIAAApIAWgpIALAAIAAA8gADagUIAAg8IALAAIAAA8gAC2gUIAAg8IAMAAIAAATQAGAAADACQAEABADADIADAHIABAIIgBAHIgDAHIgHAFQgDABgGAAgADCgfIAEgBIADgCIACgDIAAgDIAAgEIgCgDIgDgCIgEgBgACmgUIAAgZIgWAAIAAAZIgMAAIAAg8IAMAAIAAAYIAWAAIAAgYIALAAIAAA8gABygUIAAgZIgWAAIAAAZIgLAAIAAg8IALAAIAAAYIAWAAIAAgYIALAAIAAA8gAAigUIAAg8IAkAAIAAAMIgYAAIAAAMIASAAIAAALIgSAAIAAAOIAYAAIAAALgAALgUIAAgmIgHAWIgHAAIgIgWIAAAmIgLAAIAAg8IAMAAIAKAfIAKgfIAMAAIAAA8gAhEgUIAAg8IAkAAIAAAMIgZAAIAAAMIATAAIAAALIgTAAIAAAOIAZAAIAAALgAh7gUIAAg8IAYAAQAGAAAEACIAGAEIAEAIQABADAAAEQAAAFgBADIgEAGQgDAEgDABQgEABgGABIgMAAIAAASgAhvgxIAMAAIAFgBIACgDIACgDIABgDIgBgEIgCgCIgCgCIgFgBIgMAAgAivgUIAAg8IAYAAQAFABAFACQAEACADADQACAEAAAFIgBAHIgEAGIAFAFQABAEAAADQAAAGgCAEQgCAEgEACQgFACgFAAgAikgfIAPAAQAEgBABgBQACgCAAgDIgBgDIgCgDIgEgBIgPAAgAikg4IANAAIAEgBIADgBIABgEIgBgDIgDgCIgEgBIgNAAgAkKgVQgEgCgDgDQgDgCgCgEQgBgEAAgFIAAgRIABgJQACgFADgDIAHgDQADgDAGAAQAGAAADACQAEACADACQADADACAEIACAJIgMAAIgCgGIgEgDIgFgBIgFABIgEAEQgCADAAADIAAARQAAADACACQABADADABIAFABIAFgBQABAAAAAAQABgBABAAQAAAAAAgBQABAAAAgBIACgFIAMAAIgCAIQgCAFgDABQgCADgFACQgDABgGAAQgFAAgEgBgAD/hTQAAAAgBAAQgBAAAAAAQgBgBAAAAQgBAAAAAAIgEgEQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAgBIAEAAIABADIACACIACABIAFAAIADgBIACgCIABgDIAEAAIgBAFIgEAEQgCABgDAAg");
	this.shape.setTransform(65,21.7,2.319,2.321);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,130,43.4);


(lib.border = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#2F2E2D").ss(1,1,1).p("Ayv/PMAlfAAAMAAAA+fMglfAAAg");
	this.shape.setTransform(30,325,1.25,2.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.border, new cjs.Rectangle(-121,-201,302,1052), null);


(lib.anim2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("EgSuAllMgABg/HMAlfgMCMAAABLJg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120,-240.5,240,481);


// stage content:
(lib.pzspbf300x1050 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.border();
	this.instance.parent = this;
	this.instance.setTransform(120,200);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(375));

	// transition-sl5
	this.instance_1 = new lib.trans21sl2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(120,658.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(364).to({_off:false},0).to({y:160.5},7).wait(4));

	// text2-sl5
	this.instance_2 = new lib.text2sl5();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-181.7,500);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(314).to({_off:false},0).to({x:102.5},6).to({_off:true},52).wait(3));

	// text1-sl5
	this.instance_3 = new lib.text1sl5();
	this.instance_3.parent = this;
	this.instance_3.setTransform(392.7,914);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(314).to({_off:false},0).to({x:110},6).to({_off:true},52).wait(3));

	// desc-logo - sl3
	this.instance_4 = new lib.desclogoai("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(317,131.1,0.877,0.877,0,0,0,0,43.4);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(246).to({_off:false},0).to({x:147},5).to({_off:true},121).wait(3));

	// logo - sl3
	this.instance_5 = new lib.logoai("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(362.1,77,1.994,1.993,0,0,0,24.6,26.1);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(240).to({_off:false},0).to({x:74},5).to({_off:true},127).wait(3));

	// transition-sl4
	this.instance_6 = new lib.trans3();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-128,200);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(306).to({_off:false},0).to({x:120},7).to({_off:true},59).wait(3));

	// text31-sl4
	this.instance_7 = new lib.text31sl4();
	this.instance_7.parent = this;
	this.instance_7.setTransform(150,919.3,0.05,0.05,0,0,0,1,0);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(282).to({_off:false},0).to({regX:0,scaleX:1,scaleY:1,alpha:1},5).to({scaleX:1.15,scaleY:1.15,y:919.2},2).to({scaleX:1,scaleY:1,y:919.3},2).to({_off:true},23).wait(61));

	// text3-sl4
	this.instance_8 = new lib.text3sl4();
	this.instance_8.parent = this;
	this.instance_8.setTransform(152,854.1,0.05,0.05,0,0,0,1,1);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(273).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:1,scaleY:1,x:187.8,alpha:1},5).to({regX:0,regY:0,scaleX:1.15,scaleY:1.15,x:193.3,y:854},2).to({scaleX:1,scaleY:1,x:187.7},2).to({_off:true},32).wait(61));

	// text2-sl4
	this.instance_9 = new lib.text2sl4();
	this.instance_9.parent = this;
	this.instance_9.setTransform(148.4,801.1,0.05,0.05,0,0,0,1,1);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(264).to({_off:false},0).to({regX:0,regY:0,scaleX:1,scaleY:1,x:117.2,y:801,alpha:1},5).to({scaleX:1.15,scaleY:1.15,x:112.3},2).to({regX:1.1,regY:1.1,scaleX:1,scaleY:1,x:118.3,y:802.1},2).to({_off:true},41).wait(61));

	// text1-sl4
	this.instance_10 = new lib.text1sl4();
	this.instance_10.parent = this;
	this.instance_10.setTransform(148.4,743.1,0.05,0.05,0,0,0,1,1);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(254).to({_off:false},0).to({regX:0,regY:0,scaleX:1,scaleY:1,x:117.2,y:743,alpha:1},6).to({scaleX:1.15,scaleY:1.15,x:112.3},2).to({scaleX:1,scaleY:1,x:117.2},2).to({_off:true},50).wait(61));

	// family
	this.instance_11 = new lib.familyvert();
	this.instance_11.parent = this;
	this.instance_11.setTransform(150,438);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(246).to({_off:false},0).to({alpha:1},8).to({_off:true},60).wait(61));

	// transition-sl3
	this.instance_12 = new lib.trans3();
	this.instance_12.parent = this;
	this.instance_12.setTransform(365,200);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(233).to({_off:false},0).to({x:120},7).to({_off:true},74).wait(61));

	// slide-4
	this.instance_13 = new lib.sl4300x1050();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-160,900);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(208).to({_off:false},0).to({x:150},5).to({_off:true},91).wait(71));

	// slide-3
	this.instance_14 = new lib.sl3300x1050();
	this.instance_14.parent = this;
	this.instance_14.setTransform(460,150);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(208).to({_off:false},0).to({x:150},5).to({_off:true},91).wait(71));

	// text3-sl3
	this.instance_15 = new lib.text3sl3();
	this.instance_15.parent = this;
	this.instance_15.setTransform(148.9,584,0.05,0.05,0,0,0,1,0);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(195).to({_off:false},0).to({regX:0,scaleX:1,scaleY:1,x:125.7,alpha:1},6).to({scaleX:1.15,scaleY:1.15,x:122.1},2).to({regX:0.1,regY:0.1,scaleX:1,scaleY:1,x:125.8,y:584.1},2).to({_off:true},99).wait(71));

	// text21-sl3
	this.instance_16 = new lib.text21sl3();
	this.instance_16.parent = this;
	this.instance_16.setTransform(150,523,0.05,0.05,0,0,0,1,1);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(185).to({_off:false},0).to({regX:0,regY:0,scaleX:1,scaleY:1,alpha:1},6).to({scaleX:1.15,scaleY:1.15},2).to({scaleX:1,scaleY:1},2).to({_off:true},109).wait(71));

	// text2-sl3
	this.instance_17 = new lib.text2sl3();
	this.instance_17.parent = this;
	this.instance_17.setTransform(149.6,451.1,0.05,0.05,0,0,0,0,1);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(175).to({_off:false},0).to({regY:0,scaleX:1,scaleY:1,x:142,y:451,alpha:1},6).to({scaleX:1.15,scaleY:1.15,x:140.8},2).to({regX:0.1,regY:0.1,scaleX:1,scaleY:1,x:142.1,y:451.1},2).to({_off:true},109).wait(81));

	// text1-sl3
	this.instance_18 = new lib.text1sl3();
	this.instance_18.parent = this;
	this.instance_18.setTransform(148.4,395.1,0.05,0.05,0,0,0,1,1);
	this.instance_18.alpha = 0;
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(165).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:1,scaleY:1,x:117.3,alpha:1},6).to({regX:0,regY:0,scaleX:1.15,scaleY:1.15,x:112.3,y:395},2).to({scaleX:1,scaleY:1,x:117.2},2).to({_off:true},119).wait(81));

	// transition-sl2
	this.instance_19 = new lib.trans21sl2();
	this.instance_19.parent = this;
	this.instance_19.setTransform(120,1297.5);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(158).to({_off:false},0).to({y:27.5},7).to({_off:true},129).wait(81));

	// slide-2
	this.instance_20 = new lib.sl2300x1050();
	this.instance_20.parent = this;
	this.instance_20.setTransform(-159.5,900);
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(128).to({_off:false},0).to({x:150.5},5).to({_off:true},161).wait(81));

	// slide-1
	this.instance_21 = new lib.sl1300x1050();
	this.instance_21.parent = this;
	this.instance_21.setTransform(460,150);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(128).to({_off:false},0).to({x:150},5).to({_off:true},161).wait(81));

	// text2-sl2
	this.instance_22 = new lib.text2sl2();
	this.instance_22.parent = this;
	this.instance_22.setTransform(148.9,530.1,0.05,0.05,0,0,0,1,1);
	this.instance_22.alpha = 0;
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(115).to({_off:false},0).to({regX:0,regY:0,scaleX:1,scaleY:1,x:125.7,y:530,alpha:1},6).to({scaleX:1.15,scaleY:1.15,x:122.1},2).to({scaleX:1,scaleY:1,x:125.7},2).to({_off:true},169).wait(81));

	// text1-sl2
	this.instance_23 = new lib.text1sl2();
	this.instance_23.parent = this;
	this.instance_23.setTransform(148.4,450.1,0.05,0.05,0,0,0,1,1);
	this.instance_23.alpha = 0;
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(105).to({_off:false},0).to({regX:0,regY:0,scaleX:1,scaleY:1,x:117.2,y:450,alpha:1},6).to({scaleX:1.15,scaleY:1.15,x:112.3},2).to({scaleX:1,scaleY:1,x:117.2},2).to({_off:true},179).wait(81));

	// transition-sl1
	this.instance_24 = new lib.anim2("synched",0);
	this.instance_24.parent = this;
	this.instance_24.setTransform(150,1689.5,1.25,2.626);
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(98).to({_off:false},0).to({y:419.5},7).to({_off:true},189).wait(81));

	// frame-text
	this.instance_25 = new lib.frametextsl1();
	this.instance_25.parent = this;
	this.instance_25.setTransform(148.4,472.1,0.05,0.05,0,0,0,1,1);
	this.instance_25.alpha = 0;
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(54).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:1.1,scaleY:1.1,x:112.7,alpha:1},6).to({regX:0,regY:0,scaleX:1.15,scaleY:1.15,x:110.9,y:472},2).to({scaleX:1.1,scaleY:1.1,x:112.6},2).to({_off:true},230).wait(81));

	// text4-sl1
	this.instance_26 = new lib.text4sl1();
	this.instance_26.parent = this;
	this.instance_26.setTransform(148.7,603.1,0.05,0.05,0,0,0,71,22);
	this.instance_26.alpha = 0;
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(44).to({_off:false},0).to({regX:70.2,regY:21.4,scaleX:1,scaleY:1,x:122.1,y:623.4,alpha:1},6,cjs.Ease.get(0.5)).to({regX:70.1,scaleX:1.15,scaleY:1.15,x:117.8,y:626.6},2).to({regX:70.2,scaleX:1,scaleY:1,x:122.1,y:623.4},2).to({_off:true},240).wait(81));

	// text3-sl1
	this.instance_27 = new lib.text3sl1();
	this.instance_27.parent = this;
	this.instance_27.setTransform(148.2,523.1,0.05,0.05,0,0,0,71,22);
	this.instance_27.alpha = 0;
	this.instance_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(34).to({_off:false},0).to({regX:70.2,regY:21.4,scaleX:1,scaleY:1,x:111.7,y:543.4,alpha:1},6,cjs.Ease.get(0.5)).to({scaleX:1.15,scaleY:1.15,x:106,y:546.6},2).to({scaleX:1,scaleY:1,x:111.7,y:543.4},2).to({_off:true},250).wait(81));

	// text2-sl1
	this.instance_28 = new lib.text2sl1();
	this.instance_28.parent = this;
	this.instance_28.setTransform(148.2,461.1,0.05,0.05,0,0,0,71,22);
	this.instance_28.alpha = 0;
	this.instance_28._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(24).to({_off:false},0).to({regX:70.2,regY:21.4,scaleX:1,scaleY:1,x:111.7,y:481.4,alpha:1},6,cjs.Ease.get(0.5)).to({scaleX:1.15,scaleY:1.15,x:106,y:484.6},2).to({scaleX:1,scaleY:1,x:111.7,y:481.4},2).to({_off:true},260).wait(81));

	// text1-sl1
	this.instance_29 = new lib.text1sl1();
	this.instance_29.parent = this;
	this.instance_29.setTransform(148.1,398.1,0.05,0.05,0,0,0,70.2,21.1);
	this.instance_29.alpha = 0;
	this.instance_29._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(14).to({_off:false},0).to({regY:21.4,scaleX:1,scaleY:1,x:111.7,y:418.4,alpha:1},6,cjs.Ease.get(0.5)).to({scaleX:1.15,scaleY:1.15,x:106,y:421.6},2).to({regX:70.3,scaleX:1,scaleY:1,x:111.8,y:418.4},2).to({_off:true},270).wait(81));

	// desc-logo
	this.instance_30 = new lib.desclogoai("synched",0);
	this.instance_30.parent = this;
	this.instance_30.setTransform(307,131.1,0.877,0.877,0,0,0,0,43.4);
	this.instance_30._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(8).to({_off:false},0).to({x:147},5).to({_off:true},281).wait(81));

	// logo
	this.instance_31 = new lib.logoai("synched",0);
	this.instance_31.parent = this;
	this.instance_31.setTransform(360.1,77.3,1.994,1.994,0,0,0,24.6,26.2);
	this.instance_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(2).to({_off:false},0).to({regY:26.1,scaleY:1.99,x:74.5,y:76.9},5).to({_off:true},287).wait(81));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbBSCMAAAikDMAu3AAAMAAACkDg");
	this.shape.setTransform(150,525);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(375));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(149.5,524.5,301,1051);
// library properties:
lib.properties = {
	id: 'BB1F55DD0DF8CD43AF22ACF19B73D8FD',
	width: 300,
	height: 1050,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/family3r.jpg", id:"family3r"},
		{src:"images/sl1.jpg", id:"sl1"},
		{src:"images/sl2.jpg", id:"sl2"},
		{src:"images/sl3.jpg", id:"sl3"},
		{src:"images/sl4.jpg", id:"sl4"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['BB1F55DD0DF8CD43AF22ACF19B73D8FD'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;