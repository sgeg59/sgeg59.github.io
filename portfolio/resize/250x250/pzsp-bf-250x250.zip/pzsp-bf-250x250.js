(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.family = function() {
	this.initialize(img.family);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,206,151);


(lib.sl1250x250 = function() {
	this.initialize(img.sl1250x250);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,125,114);


(lib.sl2250x250 = function() {
	this.initialize(img.sl2250x250);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,125,114);


(lib.sl3250x250 = function() {
	this.initialize(img.sl3250x250);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,125,114);


(lib.sl4250x250 = function() {
	this.initialize(img.sl4250x250);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,125,114);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.trans21sl2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AzhZyMAAAgnhMAnDgMCMAAAAzjg");
	this.shape.setTransform(5,-75.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.trans21sl2, new cjs.Rectangle(-120,-240.5,250,330), null);


(lib.trans3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AzhTiMAAAgnDMAnDAAAMAAAAnDg");
	this.shape.setTransform(5,-75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.trans3, new cjs.Rectangle(-120,-200,250,250), null);


(lib.text3sl4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("AAkBiIAAieIhHAAIAACeIgmAAIAAjDICTAAIAADDg");
	this.shape.setTransform(42.4,-1.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("AgnBbQgQgJgJgQQgJgPAAgVIAAg4QAAgVAJgRQAJgQAQgJQARgJAWgBQAXABAQAIQARAJAIAPQAJAQABAUIgmAAQgCgPgJgIQgLgIgOAAQgJAAgIAEQgJAEgFAIQgEAIAAALIAAA4QAAALAEAHQAFAIAJAEQAIAEAJAAQAOAAALgIQAJgIACgOIAmAAQgBAUgJAPQgIAOgRAIQgQAJgXgBQgWAAgRgIg");
	this.shape_1.setTransform(25.5,-1.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6CD3DC").s().p("AgyBTQgUgSAAggIAlAAQABAPAKAIQAKAIAPAAQANAAAJgGQAIgGABgNQAAgJgFgGQgGgGgNAAIggAAIAAgkIAbAAQAMAAAGgGQAGgFAAgJQAAgIgEgFQgDgGgHgDQgHgCgHAAQgNAAgJAIQgJAIAAAPIgmAAQABgVAIgPQAIgPARgJQAPgJAUAAQARAAAOAGQAQAHAJAMQAKANAAAUQAAANgFAKQgEALgIAHQALAHAFALQAGALgBAOQAAATgJANQgIANgQAHQgPAHgVAAQghAAgTgSg");
	this.shape_2.setTransform(8.6,-1.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6CD3DC").s().p("AAkBiIAAieIhIAAIAACeIglAAIAAjDICTAAIAADDg");
	this.shape_3.setTransform(-8.6,-1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CD3DC").s().p("AgSBiIAAieIg3AAIAAglICTAAIAAAlIg2AAIAACeg");
	this.shape_4.setTransform(-42.6,-1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6CD3DC").s().p("AgnBcQgQgJgJgQQgJgRAAgVIAAg4QAAgWAJgQQAJgQAQgKQAQgJAXAAQAXAAARAJQAQAKAJAQQAJAQAAAWIAAA4QAAAVgJARQgJAQgQAJQgRAJgXAAQgXAAgQgJgAgRg6QgIAEgGAIQgEAHAAAMIAAA4QAAALAEAIQAGAIAIAEQAIAEAJAAQAKAAAJgEQAIgEAEgIQAGgIAAgLIAAg4QAAgMgGgHQgEgIgIgEQgJgEgKAAQgJAAgIAEg");
	this.shape_5.setTransform(-59.6,-1.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text3sl4, new cjs.Rectangle(-70.1,-21.3,123.2,37.9), null);


(lib.text3sl3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("AAiENQgZgPgNgYQgPgZAAgfQAAgfAPgZQANgYAZgPQAZgOAfgBQAeABAZAOQAZAPAPAYQAPAZAAAfQAAAfgPAZQgPAYgZAPQgZAPgeAAQgfAAgZgPgABCCWQgJAJAAAPQAAAPAJAKQAIAJAQAAQAPAAAJgJQAJgKAAgPQAAgPgJgJQgJgKgPAAQgQAAgIAKgAi6CgIFblbIAZAZIlaFcgAiRhOQgZgPgOgYQgPgZAAgeQAAggAPgYQAOgZAZgPQAZgOAegBQAfABAZAOQAZAPAOAZQAPAYAAAgQAAAegPAZQgOAYgZAPQgZAOgfABQgegBgZgOgAhxjGQgJALAAAPQAAAOAJAJQAIAKAPABQAQgBAJgKQAJgJAAgOQAAgPgJgLQgJgKgQABQgPgBgIAKg");
	this.shape.setTransform(12,-8.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("AhdEDQgrgYgXgqQgXgqgBgzIBqAAQAAAnAVAZQAVAYAjABQAYAAARgMQASgLAKgTQAJgSAAgXIAAgTQAAgVgJgTQgKgTgSgMQgRgKgYgBQgXABgRALQgRAMgJAUIhuhJIA5kDIEKAAIAABfIi1AAIgaB0QAOgJASgEQAQgFAUAAQAvACAoAXQAoAZAYApQAYAqABAzIAAAGQgBAzgUAqQgVAqgoAYQgnAZg3AAQg6AAgrgZg");
	this.shape_1.setTransform(-36.8,-8.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text3sl3, new cjs.Rectangle(-62.9,-62.5,101.4,100.8), null);


(lib.text2sl5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape.setTransform(5.8,59.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("AgFAXIgGgDQgDgCgBgEQgCgDAAgFIAAgdIAHAAIAAAcQAAAEABADQACADADABQACABACAAQADAAADgBQACgBABgDQACgDAAgDIAAgdIAHAAIAAAuIgHAAIAAgFQgBADgEABIgGACIgFgBg");
	this.shape_1.setTransform(2.2,57.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AgKAYIAAguIAHAAIAAAFQACgDACgBQADgCAEAAIADAAIAAAHIgDAAQgDAAgDABQgCACgBACQgCADAAAEIAAAcg");
	this.shape_2.setTransform(-1.5,57.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_3.setTransform(-4.4,59.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_4.setTransform(-8,58.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F2E2D").s().p("AgHAXQgEgCgDgEQgCgDgBgGIAIAAQAAAFADADQADACAEAAQAFAAADgCQAAgBAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBQABAAAAgBQAAgBgBAAQAAgBAAAAQAAgBgBAAQgBgCgEgBIgIgCIgFgCIgFgDQgCgDAAgEQABgEACgDQACgDADgCQAEgBAEAAQAEAAAEABQADACACADQADADABAFIgIAAQAAgEgDgCQgDgCgDAAIgGACQgDACABADQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQABABAAAAQABAAAAABQABAAABAAQAAAAABAAIAIACQAFACADACQADADABAGQAAAFgCADQgCADgFABQgDABgFAAQgEAAgEgBg");
	this.shape_5.setTransform(-12.6,57.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F2E2D").s().p("AgRAXIAAgGIAZghIgYAAIAAgGIAhAAIAAAGIgaAhIAaAAIAAAGg");
	this.shape_6.setTransform(-16.8,57.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_7.setTransform(-21.3,58.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_8.setTransform(-28.1,57.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2F2E2D").s().p("AgDAXIAAgnIgOAAIAAgGIAjAAIAAAGIgOAAIAAAng");
	this.shape_9.setTransform(-32.5,57.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2F2E2D").s().p("AAMAgIAAgjIgWAjIgHAAIAAguIAHAAIAAAjIAWgjIAGAAIAAAugAgBgTQgDAAgCgBIgFgEIgBgGIAFAAQAAAAAAABQAAAAABABQAAAAAAABQABABAAAAQABAAAAABQAAAAABAAQAAAAABAAQABABAAAAIADAAQABAAAAgBQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAgBQAAgBAAAAQABgBAAAAQAAgBAAAAIAFAAIgBAGIgEAEQgDABgDAAg");
	this.shape_10.setTransform(-37,56.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgDgDAAgFIABgFIAEgEQACgCAEgBIAHgCIAMgBIAAAAQAAgEgCgDQgCgCgDgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGADgDQACgEAEgBQAEgCADABQAEgBAEACQAFACACAEQADAEAAAHIAAAcIgGAAIAAgEQgCACgFACQgDABgEAAQgEAAgEgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQABADACADQADACAEAAQADAAADgCQADgBACgCQACgDAAgDIAAgHIgMACg");
	this.shape_11.setTransform(-41.9,57.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAEACIAHAFQACAEABAFIgHAAIgCgFIgEgDQgCgBgDAAQgCAAgDABIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAIAFgBIAEgEIACgFIAHAAQgBAGgCAEQgDADgEACQgEABgEAAQgEAAgEgBg");
	this.shape_12.setTransform(-46.5,57.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2F2E2D").s().p("AgJAXQgEgCgCgDQgCgDAAgFIABgFIACgEQACgCAFgBIAIgCIAKgBIAAAAQAAgEgBgDQgBgCgEgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQAAgGADgDQADgEAEgBQAEgCADABQAFgBAEACQAEACACAEQADAEABAHIAAAcIgIAAIAAgEQgBACgFACQgDABgEAAQgEAAgDgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQAAADADADQACACAGAAQACAAADgCQADgBACgCQABgDAAgDIAAgHIgLACg");
	this.shape_13.setTransform(-53.3,57.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2F2E2D").s().p("AALAXIAAgUIgVAAIAAAUIgHAAIAAgtIAHAAIAAATIAVAAIAAgTIAHAAIAAAtg");
	this.shape_14.setTransform(-58.2,57.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_15.setTransform(-65.2,57.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2F2E2D").s().p("AADAgIAAg2IgMALIAAgJIAMgKIAGAAIAAA+g");
	this.shape_16.setTransform(26.9,43.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2F2E2D").s().p("AgHAfQgEgCgDgEQgDgEAAgHIAAAAIABAAIACAAIADAAIABAAIAAABQAAADABADQACACADACQACABADAAQAFAAADgDQADgDAAgFQAAgDgCgDIgEgEQgCgCgDAAIgEAAIAAgFIAEAAQAEAAADgEQAEgDAAgFQAAgDgCgDIgEgEQgDgBgDAAQgCAAgCABQgDACgCACQgBADAAAEIAAABIgBAAIgDAAIgCAAIgBAAIAAgBQAAgHADgEQACgEAFgBQAEgCADAAQAFAAAEACQAEABADAEQACAEAAAGQAAAFgCAFIgFAEQADABACAFQACAEAAAFQAAAGgCAEQgDAEgEACQgEACgEAAQgEAAgEgCg");
	this.shape_17.setTransform(23.2,43.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2F2E2D").s().p("AgDAJIADgIIgEAAIAAgJIAJAAIAAAJIgDAIg");
	this.shape_18.setTransform(17.7,46.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgCgDAAgFIABgFIACgEQADgCAEgBIAIgCIALgBIAAAAQgBgEgBgDQgCgCgDgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGACgDQADgEAEgBQAEgCADABQAEgBAFACQAEACACAEQADAEABAHIAAAcIgHAAIAAgEQgCACgFACQgDABgEAAQgEAAgEgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQAAADADADQACACAFAAQADAAADgCQADgBACgCQABgDABgDIAAgHIgMACg");
	this.shape_19.setTransform(14.1,44.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2F2E2D").s().p("AgRAXIAAgtIAUAAQAFAAADACIAEAEIABAHIgBAFQgBADgCABQADABABADIACAGQAAAEgCADQgBADgDABQgDACgFAAgAgKARIAOAAQADAAACgCQACgBAAgEQAAgDgCgCQgCgCgDAAIgOAAgAgKgCIANAAQADAAACgCQACgCAAgDQAAgEgCgBQgCgCgDAAIgNAAg");
	this.shape_20.setTransform(9.5,44.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_21.setTransform(4.7,44.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2F2E2D").s().p("AgJAXQgEgCgCgDQgDgDABgFIABgFIACgEQACgCAFgBIAIgCIAKgBIAAAAQABgEgCgDQgBgCgEgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQAAgGADgDQADgEAEgBQAEgCADABQAEgBAFACQAEACADAEQACAEABAHIAAAcIgIAAIAAgEQgBACgFACQgDABgEAAQgEAAgDgBgAAAACQgEAAgDACQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIAAADQAAADACADQADACAFAAQACAAADgCQADgBACgCQACgDgBgDIAAgHIgLACg");
	this.shape_22.setTransform(-0.1,44.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2F2E2D").s().p("AAKAXIAAgSIgEACIgEAAIgIgCQgFgBgCgEQgDgDAAgHIAAgMIAHAAIAAAMQAAAEACACIADAEIAGAAIAEAAIAEgBIAAgVIAHAAIAAAtgAAMgGIAAABIAAgBIAAgBg");
	this.shape_23.setTransform(-4.8,44.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2F2E2D").s().p("AgNAfIAAgGQADAAADgBQACgBABgDIABgFIgRguIAHAAIANAlIANglIAIAAIgUA3QgCAFgDACIgFABIgEgBg");
	this.shape_24.setTransform(-9,45.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2F2E2D").s().p("AAKAXIgNgUIgHAAIAAAUIgHAAIAAgtIAHAAIAAATIAFAAIANgTIAJAAIgQAVIARAYg");
	this.shape_25.setTransform(-13,44.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_26.setTransform(-17.8,44.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2F2E2D").s().p("AASAlIAAgLIgkAAIAAALIgGAAIAAgSIABAAIACAAIACgBQAAAAAAgBQABAAAAAAQAAgBABAAQAAgBAAAAIACgHIABgLIABgRIABgQIAeAAIAAA3IAHAAIAAASgAgGgUIgCAYQgBAKgDAFIAXAAIAAgwIgQAAg");
	this.shape_27.setTransform(-23.1,44.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2F2E2D").s().p("AgNAfIAAgGQADAAACgBQADgBABgDIACgFIgSguIAIAAIAMAlIAOglIAHAAIgVA3QgBAFgDACIgFABIgEgBg");
	this.shape_28.setTransform(-29.9,45.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAEACIAHAFQACAEABAFIgHAAIgCgFIgEgDQgCgBgDAAQgCAAgDABIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAIAFgBIAEgEIACgFIAHAAQgBAGgCAEQgDADgEACQgEABgEAAQgEAAgEgBg");
	this.shape_29.setTransform(-34.3,44.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_30.setTransform(-39,44.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_31.setTransform(-43.7,45.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2F2E2D").s().p("AAQAdIAAgLIgfAAIAAALIgHAAIAAgSIADAAIABAAIACAAIACgFIABgGIABgPIABgNIAbAAIAAAnIAHAAIAAASgAgFgPIgCAQIgCAKIASAAIAAghIgOAAg");
	this.shape_32.setTransform(-48.8,45.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgCgDgBgFIABgFIAEgEQACgCAEgBIAHgCIAMgBIAAAAQAAgEgCgDQgBgCgDgCQgDgBgDAAQgDAAgDACQgDACgBAFIgHAAQAAgGAEgDQACgEAEgBQAEgCADABQAEgBAEACQAFACACAEQADAEAAAHIAAAcIgGAAIAAgEQgDACgDACQgEABgEAAQgEAAgEgBgAAAACQgEAAgDACQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQABADACADQADACAEAAQADAAADgCQADgBACgCQACgDAAgDIAAgHIgMACg");
	this.shape_33.setTransform(-53.7,44.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_34.setTransform(-60.4,44.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2F2E2D").s().p("AAKAXIAAgnIgTAAIAAAnIgHAAIAAgtIAhAAIAAAtg");
	this.shape_35.setTransform(-65.2,44.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2F2E2D").s().p("AAXAXIgOgUIgGAAIAAAUIgFAAIAAgUIgHAAIgNAUIgIAAIAQgYIgOgVIAIAAIAMATIAGAAIAAgTIAFAAIAAATIAGAAIAMgTIAIAAIgOAVIAQAYg");
	this.shape_36.setTransform(78.1,31.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2F2E2D").s().p("AgJAXQgEgCgCgDQgCgDAAgFIAAgFIADgEQADgCAEgBIAHgCIALgBIAAAAQAAgEgBgDQgBgCgDgCQgDgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGACgDQADgEAEgBQAEgCADABQAFgBADACQAFACADAEQACAEAAAHIAAAcIgHAAIAAgEQgCACgDACQgEABgEAAQgEAAgDgBgAAAACQgEAAgDACQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIAAADQgBADADADQADACAFAAQACAAADgCQADgBACgCQABgDAAgDIAAgHIgLACg");
	this.shape_37.setTransform(72.5,31.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#2F2E2D").s().p("AAQAdIAAgMIgfAAIAAAMIgHAAIAAgSIADAAIACAAIABAAIACgFIABgHIABgOIABgNIAbAAIAAAnIAHAAIAAASgAgFgOIgBAPIgDAKIATAAIAAghIgPAAg");
	this.shape_38.setTransform(67.6,32.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_39.setTransform(62.7,31.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_40.setTransform(58,32.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#2F2E2D").s().p("AAKAXIAAgnIgTAAIAAAnIgHAAIAAgtIAhAAIAAAtg");
	this.shape_41.setTransform(53.1,31.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_42.setTransform(46.3,31.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#2F2E2D").s().p("AgTAXIAAgGIAFgBQABAAAAAAQABAAAAgBQAAAAAAAAQABgBAAAAQAAAAAAgBQAAAAABAAQAAgBAAAAQAAgBAAAAIABgGIABgKIABgRIAbAAIAAAtIgHAAIAAgnIgOAAIgBAQIgCAMQgBAFgCADQgCACgDABIgEAAIgDAAg");
	this.shape_43.setTransform(41.2,31.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_44.setTransform(36.7,31.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#2F2E2D").s().p("AAQAdIAAgMIgfAAIAAAMIgHAAIAAgSIADAAIABAAIACAAIACgFIABgHIABgOIABgNIAbAAIAAAnIAHAAIAAASgAgFgOIgCAPIgCAKIASAAIAAghIgOAAg");
	this.shape_45.setTransform(31.8,32.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#2F2E2D").s().p("AgCAXIAAgnIgPAAIAAgGIAjAAIAAAGIgOAAIAAAng");
	this.shape_46.setTransform(27.3,31.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_47.setTransform(22.9,31.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#2F2E2D").s().p("AgRAXIAAgtIAUAAQAFAAADACIAEAEIABAHIgBAFQgBADgCABQADABABADIACAGQAAAEgCADQgBADgDABQgDACgFAAgAgKARIAOAAQADAAACgCQACgBAAgEQAAgDgCgCQgCgCgDAAIgOAAgAgKgCIANAAQADAAACgCQACgCAAgDQAAgEgCgBQgCgCgDAAIgNAAg");
	this.shape_48.setTransform(16.2,31.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#2F2E2D").s().p("AAQAXIAAgtIAGAAIAAAtgAgVAXIAAgtIAHAAIAAARIAJAAQAFAAADACQADACACADIABAHIgBAHQgCADgDACQgDACgGAAgAgOARIAJAAQAEAAABgCQACgCAAgFQAAgEgCgCQgBgCgEAAIgJAAg");
	this.shape_49.setTransform(8.8,31.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_50.setTransform(3.6,32.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_51.setTransform(-1.4,31.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#2F2E2D").s().p("AgCAXIAAgnIgPAAIAAgGIAjAAIAAAGIgPAAIAAAng");
	this.shape_52.setTransform(-5.9,31.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_53.setTransform(-10.3,32.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgCgDAAgFIABgFIACgEQADgCAEgBIAIgCIALgBIAAAAQgBgEgBgDQgCgCgDgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGACgDQADgEAEgBQAEgCADABQAEgBAFACQAEACACAEQADAEABAHIAAAcIgHAAIAAgEQgCACgFACQgDABgEAAQgEAAgEgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQAAADADADQACACAFAAQADAAADgCQADgBACgCQABgDABgDIAAgHIgMACg");
	this.shape_54.setTransform(-15.2,31.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#2F2E2D").s().p("AgRAXIAAgtIAUAAQAFAAADACIAEAEIABAHIgBAFQgBADgCABQADABABADIACAGQAAAEgCADQgBADgDABQgDACgFAAgAgKARIAOAAQADAAACgCQACgBAAgEQAAgDgCgCQgCgCgDAAIgOAAgAgKgCIANAAQADAAACgCQACgCAAgDQAAgEgCgBQgCgCgDAAIgNAAg");
	this.shape_55.setTransform(-19.8,31.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#2F2E2D").s().p("AAKAXIgNgUIgHAAIAAAUIgHAAIAAgtIAHAAIAAATIAGAAIAMgTIAIAAIgPAVIARAYg");
	this.shape_56.setTransform(-24.1,31.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_57.setTransform(-30.9,31.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#2F2E2D").s().p("AAKAXIgNgUIgHAAIAAAUIgHAAIAAgtIAHAAIAAATIAGAAIAMgTIAIAAIgPAVIARAYg");
	this.shape_58.setTransform(-35.2,31.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#2F2E2D").s().p("AAKAXIAAgnIgTAAIAAAnIgHAAIAAgtIAhAAIAAAtg");
	this.shape_59.setTransform(-40.1,31.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#2F2E2D").s().p("AgOAfIABgGQADAAACgBQADgBABgDIACgFIgRguIAGAAIANAlIANglIAHAAIgUA3QgBAFgDACIgFABIgFgBg");
	this.shape_60.setTransform(-44.6,32.7);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#2F2E2D").s().p("AAKAXIgOgUIgGAAIAAAUIgHAAIAAgtIAHAAIAAATIAGAAIAMgTIAIAAIgPAVIARAYg");
	this.shape_61.setTransform(-48.6,31.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_62.setTransform(-53.4,31.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#2F2E2D").s().p("AAKAXIAAgnIgTAAIAAAnIgHAAIAAgtIAhAAIAAAtg");
	this.shape_63.setTransform(-58.2,31.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_64.setTransform(-65.2,31.8);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_65.setTransform(89.6,19);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_66.setTransform(84.6,19);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#2F2E2D").s().p("AANAdIAAgMIggAAIAAgtIAHAAIAAAnIATAAIAAgnIAGAAIAAAnIAHAAIAAASg");
	this.shape_67.setTransform(79.9,19.6);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#2F2E2D").s().p("AAKAXIgOgUIgGAAIAAAUIgHAAIAAgtIAHAAIAAATIAFAAIAOgTIAHAAIgPAVIARAYg");
	this.shape_68.setTransform(75.3,19);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgCgDgBgFIABgFIAEgEQABgCAFgBIAHgCIALgBIAAAAQAAgEgBgDQgBgCgDgCQgDgBgDAAQgDAAgDACQgDACgBAFIgHAAQAAgGAEgDQACgEAEgBQAEgCADABQAFgBADACQAFACADAEQACAEAAAHIAAAcIgHAAIAAgEQgCACgDACQgEABgEAAQgEAAgEgBgAAAACQgEAAgDACQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIAAADQgBADADADQADACAEAAQADAAADgCQADgBACgCQABgDAAgDIAAgHIgLACg");
	this.shape_69.setTransform(70.4,19);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_70.setTransform(63.7,19);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#2F2E2D").s().p("AAKAXIAAgnIgTAAIAAAnIgHAAIAAgtIAhAAIAAAtg");
	this.shape_71.setTransform(58.9,19);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#2F2E2D").s().p("AAKAXIAAgSIgIAAIgKASIgIAAIAMgSQgDgBgDgCIgDgEIgBgGIABgGQACgEADgCQACgCAGAAIARAAIAAAtgAgGgOQgBACAAAEQAAAEABACQADACADAAIAKAAIAAgQIgKAAQgDAAgDACg");
	this.shape_72.setTransform(52.1,19);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_73.setTransform(47.5,19);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#2F2E2D").s().p("AANAdIAAgMIggAAIAAgtIAHAAIAAAnIATAAIAAgnIAGAAIAAAnIAHAAIAAASg");
	this.shape_74.setTransform(42.7,19.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#2F2E2D").s().p("AgJAXQgEgCgCgDQgCgDAAgFIABgFIACgEQACgCAFgBIAIgCIALgBIAAAAQgBgEgBgDQgBgCgEgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQAAgGADgDQADgEAEgBQAEgCADABQAFgBAEACQAEACACAEQADAEABAHIAAAcIgHAAIAAgEQgCACgFACQgDABgEAAQgEAAgDgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQAAADADADQACACAGAAQACAAADgCQADgBACgCQABgDABgDIAAgHIgMACg");
	this.shape_75.setTransform(37.6,19);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#2F2E2D").s().p("AAQAXIAAghIgOAWIgDAAIgOgWIAAAhIgHAAIAAgtIAHAAIAPAaIAQgaIAHAAIAAAtg");
	this.shape_76.setTransform(32.2,19);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_77.setTransform(26.9,19.8);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_78.setTransform(22,19);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#2F2E2D").s().p("AgCAoIAAgQIgDAAQgEAAgFgCQgEgCgCgEQgDgEAAgHIAAgKQAAgHADgEQACgEAEgBQAFgCAEAAIADAAIAAgQIAFAAIAAAQIADAAQAFAAAEACQADABADAEQADAEAAAHIAAAKQAAAHgDAEQgDAEgDACQgEACgFAAIgDAAIAAAQgAADARIADAAQADAAACgBQADgBACgDQABgDAAgDIAAgLQAAgEgBgCIgFgEQgCgCgDAAIgDAAgAgKgPIgFAEQgBACAAAEIAAALQAAADABADQACADADABQACABADAAIADAAIAAgiIgDAAQgDAAgCACg");
	this.shape_79.setTransform(16.7,19);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#2F2E2D").s().p("AALAXIAAgUIgVAAIAAAUIgHAAIAAgtIAHAAIAAATIAVAAIAAgTIAHAAIAAAtg");
	this.shape_80.setTransform(11.2,19);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_81.setTransform(6.2,19);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#2F2E2D").s().p("AAKAXIAAgSIgHAAIgLASIgIAAIAMgSQgDgBgDgCIgDgEIgBgGIABgGQABgEADgCQADgCAGAAIARAAIAAAtgAgFgOQgCACAAAEQAAAEACACQACACADAAIAKAAIAAgQIgKAAQgDAAgCACg");
	this.shape_82.setTransform(-0.6,19);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgCgDgBgFIABgFIAEgEQACgCAEgBIAHgCIAMgBIAAAAQAAgEgCgDQgBgCgDgCQgDgBgDAAQgDAAgDACQgDACgBAFIgHAAQAAgGAEgDQACgEAEgBQAEgCADABQAEgBAEACQAFACACAEQADAEAAAHIAAAcIgGAAIAAgEQgDACgDACQgEABgEAAQgEAAgEgBgAAAACQgEAAgDACQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQABADACADQADACAEAAQADAAADgCQADgBACgCQACgDAAgDIAAgHIgMACg");
	this.shape_83.setTransform(-5.1,19);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#2F2E2D").s().p("AALAXIAAgUIgVAAIAAAUIgHAAIAAgtIAHAAIAAATIAVAAIAAgTIAHAAIAAAtg");
	this.shape_84.setTransform(-10,19);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#2F2E2D").s().p("AgIAfQgEgCgCgEQgDgEAAgHIAAgQQAAgGABgEQABgEADgDQACgDAEgCIAIgDIAMgEIACAGIgMAEIgHADIgGAFQgBACAAAFIAAABQACgDADgCIAFgBIAJACQAEACACAEQADADAAAGIAAAIQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgDIgEADQgBACAAAEIAAAIQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgIQAAgEgBgCIgEgDIgGgBIgFABg");
	this.shape_85.setTransform(-14.8,18.2);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_86.setTransform(-19.5,19);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_87.setTransform(-24.3,19.8);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#2F2E2D").s().p("AAQAdIAAgMIgfAAIAAAMIgHAAIAAgSIADAAIABAAIACgBIACgEIABgHIABgOIABgNIAbAAIAAAnIAHAAIAAASgAgFgOIgBAPIgDAKIASAAIAAggIgOAAg");
	this.shape_88.setTransform(-29.3,19.6);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_89.setTransform(-34.2,19);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#2F2E2D").s().p("AAKAXIAAgnIgTAAIAAAnIgHAAIAAgtIAhAAIAAAtg");
	this.shape_90.setTransform(-39,19);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_91.setTransform(-45.8,19);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_92.setTransform(-50.5,19);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#2F2E2D").s().p("AgTAXIAAgGIAFgBQABAAAAAAQABAAAAgBQAAAAAAAAQABgBAAAAQAAAAAAgBQAAAAAAAAQABgBAAAAQAAgBAAAAIABgGIABgKIABgRIAbAAIAAAtIgHAAIAAgnIgOAAIgBAQIgCAMQgBAFgCADQgCACgDABIgEAAIgDAAg");
	this.shape_93.setTransform(-55.6,19);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_94.setTransform(-60.1,19);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#2F2E2D").s().p("AgUAfIAAg+IAjAAIAAAHIgbAAIAAAVIAOAAIAJACQAEABACACQACADABADIABAGQAAAEgDAEQgBAFgEACQgEADgHgBgAgMAYIAOAAQAGAAADgCQADgDAAgFQAAgGgDgCQgDgDgGAAIgOAAg");
	this.shape_95.setTransform(-64.9,18.2);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#2F2E2D").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_96.setTransform(44.2,8.1);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#2F2E2D").s().p("AAQAXIAAghIgOAWIgDAAIgOgWIAAAhIgHAAIAAgtIAHAAIAPAaIAQgaIAHAAIAAAtg");
	this.shape_97.setTransform(39.9,6.2);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#2F2E2D").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_98.setTransform(35.7,8.1);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#2F2E2D").s().p("AgRAXIAAgtIAUAAQAFAAADACIAEAEIABAHIgBAFQgBADgCABQADABABADIACAGQAAAEgCADQgBADgDABQgDACgFAAgAgKARIAOAAQADAAACgCQACgBAAgEQAAgDgCgCQgCgCgDAAIgOAAgAgKgCIANAAQADAAACgCQACgCAAgDQAAgEgCgBQgCgCgDAAIgNAAg");
	this.shape_99.setTransform(32.2,6.2);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#2F2E2D").s().p("AAKAXIgOgUIgGAAIAAAUIgHAAIAAgtIAHAAIAAATIAFAAIAOgTIAIAAIgQAVIARAYg");
	this.shape_100.setTransform(27.9,6.2);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#2F2E2D").s().p("AAHAgIAAgSIgbAAIAAgGIAbgnIAIAAIAAAnIAGAAIAAAGIgGAAIAAASgAgMAIIATAAIAAgcg");
	this.shape_101.setTransform(21.1,5.4);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#2F2E2D").s().p("AADAgIAAg2IgMAKIAAgIIAMgLIAHAAIAAA/g");
	this.shape_102.setTransform(17.1,5.4);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#2F2E2D").s().p("AADAgIAAg2IgLAKIAAgIIALgLIAHAAIAAA/g");
	this.shape_103.setTransform(14.1,5.4);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#2F2E2D").s().p("AgMADIAAgFIAZAAIAAAFg");
	this.shape_104.setTransform(8.9,6);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#2F2E2D").s().p("AAQAXIAAghIgOAWIgDAAIgOgWIAAAhIgHAAIAAgtIAHAAIAPAaIAQgaIAHAAIAAAtg");
	this.shape_105.setTransform(2.1,6.2);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#2F2E2D").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_106.setTransform(-2.1,8.1);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#2F2E2D").s().p("AgRAXIAAgtIAUAAQAFAAADACIAEAEIABAHIgBAFQgBADgCABQADABABADIACAGQAAAEgCADQgBADgDABQgDACgFAAgAgKARIAOAAQADAAACgCQACgBAAgEQAAgDgCgCQgCgCgDAAIgOAAgAgKgCIANAAQADAAACgCQACgCAAgDQAAgEgCgBQgCgCgDAAIgNAAg");
	this.shape_107.setTransform(-5.6,6.2);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#2F2E2D").s().p("AAKAXIgNgUIgHAAIAAAUIgHAAIAAgtIAHAAIAAATIAGAAIAMgTIAIAAIgPAVIARAYg");
	this.shape_108.setTransform(-10,6.2);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#2F2E2D").s().p("AAIAgIAAgSIgcAAIAAgGIAcgnIAGAAIAAAnIAHAAIAAAGIgHAAIAAASgAgNAIIAVAAIAAgcg");
	this.shape_109.setTransform(-16.8,5.4);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#2F2E2D").s().p("AgHAfQgFgCgCgEQgDgEAAgHIAAgBIAHAAIAAABQAAAEABADQACADADAAQACACACAAQADAAADgCQACAAACgDQACgDAAgEIAAgKIgFACIgHACQgDAAgEgCQgFgBgCgEQgDgEAAgHIAAgDQAAgHADgEQACgEAFgCQAEgCADABQAFgBAEACQAEACADAEQACAEAAAHIAAAbQAAAHgCAEQgDAEgEACQgEACgFgBQgDABgEgCgAgEgXQgDAAgCADQgBADAAAEIAAADQAAAEABADQACADADAAQACACACAAQADAAADgCQACAAACgDQACgDAAgEIAAgDQAAgEgCgDQgCgDgCAAQgDgCgDAAQgCAAgCACg");
	this.shape_110.setTransform(-21.5,5.4);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#2F2E2D").s().p("AAAAXQgDgCgDgEQgDgEAAgHIAAgDIgKAAIAAAUIgHAAIAAgtIAHAAIAAATIAKAAIAAgCQAAgHADgEQADgEADgCQAEgCAEABQAFgBAEACQAEACADAEQADAEAAAHIAAALQAAAHgDAEQgDAEgEACIgJABIgIgBgAADgQIgDAEQgCADAAAEIAAALQAAAEACADQAAACADABQACACADAAQAEAAACgCQADgBABgCQACgDAAgEIAAgLQAAgEgCgDIgEgEQgCgBgEAAQgDAAgCABg");
	this.shape_111.setTransform(-29,6.2);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#2F2E2D").s().p("AgQAXIAAgtIAIAAIAAARIAJAAQAGAAADACQAEACACADIABAHIgCAHQgBADgEACQgDACgGAAgAgIARIAJAAQAFAAACgCQACgCAAgFQAAgEgCgCQgCgCgFAAIgJAAg");
	this.shape_112.setTransform(-34.3,6.2);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#2F2E2D").s().p("AAQAdIAAgLIgfAAIAAALIgHAAIAAgSIAEAAIABAAIABgBIACgDIABgHIABgPIABgNIAbAAIAAAnIAHAAIAAASgAgGgPIgBAQIgCAKIATAAIAAggIgPAAg");
	this.shape_113.setTransform(-39.3,6.8);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#2F2E2D").s().p("AgJAXQgEgCgCgDQgDgDABgFIABgFIACgEQACgCAFgBIAIgCIAKgBIAAAAQABgEgCgDQgBgCgEgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQAAgGADgDQADgEAEgBQAEgCADABQAEgBAFACQAEACADAEQACAEABAHIAAAcIgIAAIAAgEQgBACgFACQgDABgEAAQgEAAgDgBgAAAACQgEAAgDACQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIAAADQAAADACADQADACAFAAQACAAADgCQADgBACgCQACgDgBgDIAAgHIgLACg");
	this.shape_114.setTransform(-44.2,6.2);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#2F2E2D").s().p("AAWAdIAAgLIgyAAIAAguIAHAAIAAAnIAPAAIAAgnIAGAAIAAAnIAPAAIAAgnIAHAAIAAAnIAHAAIAAASg");
	this.shape_115.setTransform(-49.6,6.8);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_116.setTransform(-55.5,6.2);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#2F2E2D").s().p("AgTAXIAAgGIAFgBQABAAAAAAQABAAAAgBQAAAAAAAAQABgBAAAAQAAAAAAgBQAAAAAAAAQABgBAAAAQAAgBAAAAIABgGIABgKIABgRIAbAAIAAAtIgHAAIAAgnIgOAAIgBAQIgCAMQgBAFgCADQgCACgDABIgEAAIgDAAg");
	this.shape_117.setTransform(-60.7,6.2);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#2F2E2D").s().p("AAKAXIAAgnIgTAAIAAAnIgHAAIAAgtIAhAAIAAAtg");
	this.shape_118.setTransform(-65.2,6.2);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgDgDAAgFIABgFIAEgEQACgCAEgBIAHgCIAMgBIAAAAQAAgEgCgDQgCgCgDgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGADgDQACgEAEgBQAEgCADABQAEgBAEACQAFACACAEQADAEAAAHIAAAcIgGAAIAAgEQgCACgFACQgDABgEAAQgEAAgEgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQABADACADQADACAEAAQADAAADgCQADgBACgCQACgDAAgDIAAgHIgMACg");
	this.shape_119.setTransform(68.8,-6.6);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#2F2E2D").s().p("AgIAgIATg4IgcAAIAAgGIAjAAIAAAGIgTA4g");
	this.shape_120.setTransform(64.5,-7.4);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#2F2E2D").s().p("AgRAgIAAgGIAVgZIAFgGQADgEAAgEQAAgEgCgDIgFgDQgCgCgDABQgCgBgCACIgFADQgBADgBAEIAAACIAAAAIgDAAIgCAAIgBAAIAAgCQAAgGADgFQACgEAEgCQAFgBADAAQAEAAAEABQAFACACAEQADAEAAAHQAAAFgDAFIgGAIIgSAVIAbAAIAAAGg");
	this.shape_121.setTransform(60.2,-7.4);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#2F2E2D").s().p("AgDAJIADgIIgEAAIAAgJIAJAAIAAAJIgDAIg");
	this.shape_122.setTransform(54.7,-4.3);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#2F2E2D").s().p("AgJAXQgEgCgCgDQgCgDAAgFIABgFIACgEQACgCAFgBIAIgCIALgBIAAAAQgBgEgBgDQgBgCgEgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQAAgGADgDQADgEAEgBQAEgCADABQAFgBAEACQAEACACAEQADAEABAHIAAAcIgHAAIAAgEQgCACgFACQgDABgEAAQgEAAgDgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQAAADADADQACACAGAAQACAAADgCQADgBACgCQABgDABgDIAAgHIgMACg");
	this.shape_123.setTransform(51.1,-6.6);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#2F2E2D").s().p("AgRAXIAAgtIAUAAQAFAAADACIAEAEIABAHIgBAFQgBADgCABQADABABADIACAGQAAAEgCADQgBADgDABQgDACgFAAgAgKARIAOAAQADAAACgCQACgBAAgEQAAgDgCgCQgCgCgDAAIgOAAgAgKgCIANAAQADAAACgCQACgCAAgDQAAgEgCgBQgCgCgDAAIgNAAg");
	this.shape_124.setTransform(46.5,-6.6);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_125.setTransform(41.7,-6.6);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_126.setTransform(36.9,-5.8);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#2F2E2D").s().p("AgJAXQgEgCgCgDQgCgDgBgFIABgFIADgEQADgCAEgBIAHgCIALgBIAAAAQAAgEgBgDQgBgCgDgCQgDgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGACgDQADgEAEgBQAEgCADABQAFgBADACQAFACADAEQACAEAAAHIAAAcIgHAAIAAgEQgCACgDACQgEABgEAAQgEAAgDgBgAAAACQgEAAgDACQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIAAADQgBADADADQADACAFAAQACAAADgCQADgBACgCQABgDAAgDIAAgHIgLACg");
	this.shape_127.setTransform(32,-6.6);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAEACIAHAFQACAEABAFIgHAAIgCgFIgEgDQgCgBgDAAQgCAAgDABIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAIAFgBIAEgEIACgFIAHAAQgBAGgCAEQgDADgEACQgEABgEAAQgEAAgEgBg");
	this.shape_128.setTransform(27.4,-6.6);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_129.setTransform(22.5,-6.6);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#2F2E2D").s().p("AANAgIAAg3IgZAAIAAA3IgHAAIAAg+IAnAAIAAA+g");
	this.shape_130.setTransform(17.3,-7.4);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#2F2E2D").s().p("AgNAfIAAgGQAEAAACgBQACgBABgDIABgFIgRguIAHAAIANAlIANglIAIAAIgUA3QgBAFgEACIgFABIgEgBg");
	this.shape_131.setTransform(10.5,-5.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAEACIAHAFQACAEABAFIgHAAIgCgFIgEgDQgCgBgDAAQgCAAgDABIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAIAFgBIAEgEIACgFIAHAAQgBAGgCAEQgDADgEACQgEABgEAAQgEAAgEgBg");
	this.shape_132.setTransform(6.1,-6.6);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_133.setTransform(1.4,-6.6);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_134.setTransform(-3.4,-5.8);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#2F2E2D").s().p("AAQAdIAAgLIgfAAIAAALIgHAAIAAgSIADAAIACAAIABgBIACgDIABgHIABgPIABgNIAbAAIAAAnIAHAAIAAASgAgFgPIgBAQIgDAKIATAAIAAghIgPAAg");
	this.shape_135.setTransform(-8.4,-6);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgCgDAAgFIABgFIACgEQADgCAEgBIAIgCIALgBIAAAAQgBgEgBgDQgCgCgDgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGACgDQADgEAEgBQAEgCADABQAEgBAFACQAEACACAEQADAEABAHIAAAcIgHAAIAAgEQgCACgFACQgDABgEAAQgEAAgEgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQAAADADADQACACAFAAQADAAADgCQADgBACgCQABgDABgDIAAgHIgMACg");
	this.shape_136.setTransform(-13.4,-6.6);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_137.setTransform(-20.1,-6.6);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#2F2E2D").s().p("AAKAXIAAgnIgTAAIAAAnIgHAAIAAgtIAhAAIAAAtg");
	this.shape_138.setTransform(-24.9,-6.6);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#2F2E2D").s().p("AAQAXIAAgtIAGAAIAAAtgAgVAXIAAgtIAHAAIAAARIAJAAQAFAAADACQADACACADIABAHIgBAHQgCADgDACQgDACgGAAgAgOARIAJAAQAEAAABgCQACgCAAgFQAAgEgCgCQgBgCgEAAIgJAAg");
	this.shape_139.setTransform(-32.2,-6.6);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_140.setTransform(-37.5,-5.8);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_141.setTransform(-42.5,-6.6);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#2F2E2D").s().p("AgDAXIAAgnIgOAAIAAgGIAjAAIAAAGIgPAAIAAAng");
	this.shape_142.setTransform(-46.9,-6.6);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_143.setTransform(-51.3,-5.8);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgDgDAAgFIACgFIADgEQACgCAEgBIAIgCIALgBIAAAAQgBgEgBgDQgCgCgDgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGADgDQACgEAEgBQAEgCADABQAEgBAEACQAFACACAEQADAEABAHIAAAcIgHAAIAAgEQgDACgEACQgDABgEAAQgEAAgEgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQABADACADQACACAFAAQADAAADgCQADgBACgCQABgDABgDIAAgHIgMACg");
	this.shape_144.setTransform(-56.2,-6.6);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#2F2E2D").s().p("AgRAXIAAgtIAUAAQAFAAADACIAEAEIABAHIgBAFQgBADgCABQADABABADIACAGQAAAEgCADQgBADgDABQgDACgFAAgAgKARIAOAAQADAAACgCQACgBAAgEQAAgDgCgCQgCgCgDAAIgOAAgAgKgCIANAAQADAAACgCQACgCAAgDQAAgEgCgBQgCgCgDAAIgNAAg");
	this.shape_145.setTransform(-60.8,-6.6);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#2F2E2D").s().p("AAKAXIgNgUIgHAAIAAAUIgHAAIAAgtIAHAAIAAATIAFAAIANgTIAJAAIgQAVIARAYg");
	this.shape_146.setTransform(-65.2,-6.6);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_147.setTransform(92.7,-19.4);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#2F2E2D").s().p("AAQAXIAAgtIAGAAIAAAtgAgVAXIAAgtIAHAAIAAARIAJAAQAFAAADACQADACACADIABAHIgBAHQgCADgDACQgDACgGAAgAgOARIAJAAQAEAAABgCQACgCAAgFQAAgEgCgCQgBgCgEAAIgJAAg");
	this.shape_148.setTransform(87.4,-19.4);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#2F2E2D").s().p("AALAXIAAgUIgVAAIAAAUIgHAAIAAgtIAHAAIAAATIAVAAIAAgTIAHAAIAAAtg");
	this.shape_149.setTransform(82,-19.4);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#2F2E2D").s().p("AgCAXIAAgnIgPAAIAAgGIAjAAIAAAGIgOAAIAAAng");
	this.shape_150.setTransform(77.6,-19.4);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#2F2E2D").s().p("AgJAXQgEgCgCgDQgCgDAAgFIABgFIACgEQACgCAFgBIAIgCIALgBIAAAAQgBgEgBgDQgBgCgEgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQAAgGADgDQADgEAEgBQAEgCADABQAFgBAEACQAEACACAEQADAEABAHIAAAcIgHAAIAAgEQgCACgFACQgDABgEAAQgEAAgDgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQAAADADADQACACAGAAQACAAADgCQADgBACgCQABgDABgDIAAgHIgMACg");
	this.shape_151.setTransform(73.1,-19.4);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#2F2E2D").s().p("AALAXIAAgUIgVAAIAAAUIgHAAIAAgtIAHAAIAAATIAVAAIAAgTIAHAAIAAAtg");
	this.shape_152.setTransform(68.3,-19.4);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#2F2E2D").s().p("AAQAXIAAghIgOAWIgDAAIgOgWIAAAhIgHAAIAAgtIAHAAIAPAaIAQgaIAHAAIAAAtg");
	this.shape_153.setTransform(62.8,-19.4);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_154.setTransform(57.4,-19.4);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#2F2E2D").s().p("AAKAXIgNgUIgHAAIAAAUIgHAAIAAgtIAHAAIAAATIAFAAIANgTIAJAAIgQAVIARAYg");
	this.shape_155.setTransform(53.2,-19.4);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#2F2E2D").s().p("AAMAXIgMgTIgMATIgHAAIAPgXIgPgWIAIAAIALARIALgRIAIAAIgPAWIAQAXg");
	this.shape_156.setTransform(48.6,-19.4);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_157.setTransform(44.1,-19.4);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_158.setTransform(39.4,-18.6);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#2F2E2D").s().p("AgCAXIAAgnIgPAAIAAgGIAjAAIAAAGIgOAAIAAAng");
	this.shape_159.setTransform(34.9,-19.4);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgCgDAAgFIABgFIACgEQADgCAEgBIAIgCIALgBIAAAAQgBgEgBgDQgCgCgDgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGACgDQADgEAEgBQAEgCADABQAEgBAFACQAEACACAEQADAEABAHIAAAcIgHAAIAAgEQgCACgFACQgDABgEAAQgEAAgEgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQAAADADADQACACAFAAQADAAADgCQADgBACgCQABgDABgDIAAgHIgMACg");
	this.shape_160.setTransform(28.5,-19.4);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#2F2E2D").s().p("AALAXIAAgUIgVAAIAAAUIgHAAIAAgtIAHAAIAAATIAVAAIAAgTIAHAAIAAAtg");
	this.shape_161.setTransform(23.6,-19.4);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#2F2E2D").s().p("AAQAXIAAghIgOAWIgDAAIgOgWIAAAhIgHAAIAAgtIAHAAIAPAaIAQgaIAHAAIAAAtg");
	this.shape_162.setTransform(16.1,-19.4);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#2F2E2D").s().p("AAKAXIAAgSIgIAAIgKASIgIAAIAMgSQgEgBgCgCIgDgEIgBgGIABgGQACgEADgCQACgCAGAAIARAAIAAAtgAgGgOQgBACAAAEQAAAEABACQADACADAAIAKAAIAAgQIgKAAQgDAAgDACg");
	this.shape_163.setTransform(10.8,-19.4);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#2F2E2D").s().p("AgPAXIAAgtIAGAAIAAARIALAAQAFAAAEACQADACABADIABAHIgBAHQgBADgEACQgDACgGAAgAgJARIALAAQADAAACgCQACgCABgFQgBgEgCgCQgCgCgDAAIgLAAg");
	this.shape_164.setTransform(6.8,-19.4);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#2F2E2D").s().p("AAQAXIAAghIgOAWIgDAAIgOgWIAAAhIgHAAIAAgtIAHAAIAPAaIAQgaIAHAAIAAAtg");
	this.shape_165.setTransform(1.4,-19.4);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_166.setTransform(-3.9,-19.4);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAEACIAHAFQACAEABAFIgHAAIgCgFIgEgDQgCgBgDAAQgCAAgDABIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAIAFgBIAEgEIACgFIAHAAQgBAGgCAEQgDADgEACQgEABgEAAQgEAAgEgBg");
	this.shape_167.setTransform(-8.6,-19.4);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#2F2E2D").s().p("AAQAXIAAghIgOAWIgDAAIgOgWIAAAhIgHAAIAAgtIAHAAIAPAaIAQgaIAHAAIAAAtg");
	this.shape_168.setTransform(-16,-19.4);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#2F2E2D").s().p("AAQAXIAAgtIAGAAIAAAtgAgVAXIAAgtIAHAAIAAARIAJAAQAFAAADACQADACACADIABAHIgBAHQgCADgDACQgDACgGAAgAgOARIAJAAQAEAAABgCQACgCAAgFQAAgEgCgCQgBgCgEAAIgJAAg");
	this.shape_169.setTransform(-21.9,-19.4);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#2F2E2D").s().p("AALAXIAAgUIgVAAIAAAUIgHAAIAAgtIAHAAIAAATIAVAAIAAgTIAHAAIAAAtg");
	this.shape_170.setTransform(-27.3,-19.4);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#2F2E2D").s().p("AgDAXIAAgnIgOAAIAAgGIAjAAIAAAGIgPAAIAAAng");
	this.shape_171.setTransform(-31.7,-19.4);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_172.setTransform(-36.1,-19.4);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#2F2E2D").s().p("AAQAdIAAgLIgfAAIAAALIgHAAIAAgSIADAAIABAAIACAAIACgFIABgHIABgOIABgNIAbAAIAAAnIAHAAIAAASgAgFgOIgBAPIgDAKIASAAIAAghIgOAAg");
	this.shape_173.setTransform(-41,-18.8);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_174.setTransform(-45.9,-19.4);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#2F2E2D").s().p("AgMAXIAAgtIAaAAIAAAGIgUAAIAAAng");
	this.shape_175.setTransform(-49.9,-19.4);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_176.setTransform(-54.3,-19.4);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#2F2E2D").s().p("AALAXIAAgUIgVAAIAAAUIgHAAIAAgtIAHAAIAAATIAVAAIAAgTIAHAAIAAAtg");
	this.shape_177.setTransform(-59.2,-19.4);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#2F2E2D").s().p("AAQAXIAAghIgOAWIgDAAIgOgWIAAAhIgHAAIAAgtIAHAAIAPAaIAQgaIAHAAIAAAtg");
	this.shape_178.setTransform(-64.7,-19.4);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#2F2E2D").s().p("AAKAXIAAgSIgIAAIgKASIgIAAIAMgSQgDgBgDgCIgDgEIgBgGIABgGQACgEADgCQACgCAGAAIARAAIAAAtgAgGgOQgBACAAAEQAAAEABACQADACADAAIAKAAIAAgQIgKAAQgDAAgDACg");
	this.shape_179.setTransform(30.1,-32.2);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAEACIAHAFQACAEABAFIgHAAIgCgFIgEgDQgCgBgDAAQgCAAgDABIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAIAFgBIAEgEIACgFIAHAAQgBAGgCAEQgDADgEACQgEABgEAAQgEAAgEgBg");
	this.shape_180.setTransform(25.8,-32.2);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#2F2E2D").s().p("AgCAXIAAgnIgPAAIAAgGIAjAAIAAAGIgOAAIAAAng");
	this.shape_181.setTransform(21.4,-32.2);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_182.setTransform(17.1,-32.2);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#2F2E2D").s().p("AAKAXIAAgSIgIAAIgKASIgIAAIAMgSQgDgBgDgCIgDgEIgBgGIABgGQABgEADgCQAEgCAFAAIARAAIAAAtgAgGgOQgBACAAAEQAAAEABACQADACADAAIAKAAIAAgQIgKAAQgDAAgDACg");
	this.shape_183.setTransform(12.3,-32.2);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#2F2E2D").s().p("AgTAXIAAgGIAFgBQABAAAAAAQABAAAAgBQAAAAAAAAQABgBAAAAQAAAAAAgBQAAAAABAAQAAgBAAAAQAAgBAAAAIABgGIABgKIABgRIAbAAIAAAtIgHAAIAAgnIgOAAIgBAQIgCAMQgBAFgCADQgCACgDABIgEAAIgDAAg");
	this.shape_184.setTransform(7.5,-32.2);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#2F2E2D").s().p("AgRAXIAAgtIAUAAQAFAAADACIAEAEIABAHIgBAFQgBADgCABQADABABADIACAGQAAAEgCADQgBADgDABQgDACgFAAgAgKARIAOAAQADAAACgCQACgBAAgEQAAgDgCgCQgCgCgDAAIgOAAgAgKgCIANAAQADAAACgCQACgCAAgDQAAgEgCgBQgCgCgDAAIgNAAg");
	this.shape_185.setTransform(3.1,-32.2);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#2F2E2D").s().p("AgJAXQgEgCgCgDQgDgDABgFIAAgFIADgEQACgCAFgBIAHgCIALgBIAAAAQABgEgCgDQgCgCgCgCQgDgBgDAAQgDAAgDACQgDACgBAFIgHAAQAAgGADgDQADgEAEgBQAEgCADABQAFgBAEACQAEACADAEQACAEABAHIAAAcIgIAAIAAgEQgCACgDACQgEABgEAAQgEAAgDgBgAAAACQgEAAgDACQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIAAADQAAADACADQADACAFAAQACAAADgCQADgBACgCQACgDgBgDIAAgHIgLACg");
	this.shape_186.setTransform(-1.8,-32.2);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#2F2E2D").s().p("AgCAXIAAgnIgPAAIAAgGIAjAAIAAAGIgOAAIAAAng");
	this.shape_187.setTransform(-6.1,-32.2);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAEACIAHAFQACAEABAFIgHAAIgCgFIgEgDQgCgBgDAAQgCAAgDABIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAIAFgBIAEgEIACgFIAHAAQgBAGgCAEQgDADgEACQgEABgEAAQgEAAgEgBg");
	this.shape_188.setTransform(-10.4,-32.2);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_189.setTransform(-15.2,-32.2);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#2F2E2D").s().p("AAQAdIAAgMIgfAAIAAAMIgHAAIAAgSIADAAIACAAIABAAIACgFIABgHIABgOIABgNIAbAAIAAAnIAHAAIAAASgAgFgOIgBAPIgDAKIATAAIAAggIgPAAg");
	this.shape_190.setTransform(-20.1,-31.6);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_191.setTransform(-25,-32.2);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_192.setTransform(-29.7,-31.4);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#2F2E2D").s().p("AAKAXIAAgnIgTAAIAAAnIgHAAIAAgtIAhAAIAAAtg");
	this.shape_193.setTransform(-34.6,-32.2);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgDgDAAgFIABgFIAEgEQACgCAEgBIAHgCIAMgBIAAAAQAAgEgCgDQgCgCgDgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGADgDQACgEAEgBQAEgCADABQAEgBAEACQAFACACAEQADAEAAAHIAAAcIgGAAIAAgEQgCACgFACQgDABgEAAQgEAAgEgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQABADACADQADACAEAAQADAAADgCQADgBACgCQACgDAAgDIAAgHIgMACg");
	this.shape_194.setTransform(-41.5,-32.2);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#2F2E2D").s().p("AAKAXIgOgUIgGAAIAAAUIgHAAIAAgtIAHAAIAAATIAFAAIAOgTIAIAAIgQAVIARAYg");
	this.shape_195.setTransform(-45.7,-32.2);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#2F2E2D").s().p("AAQAdIAAgMIgfAAIAAAMIgHAAIAAgSIADAAIACAAIABAAIACgFIABgHIABgOIABgNIAbAAIAAAnIAHAAIAAASgAgFgOIgBAPIgDAKIATAAIAAggIgPAAg");
	this.shape_196.setTransform(-50.7,-31.6);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_197.setTransform(-55.8,-32.2);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#2F2E2D").s().p("AAKAXIgNgUIgHAAIAAAUIgHAAIAAgtIAHAAIAAATIAGAAIAMgTIAIAAIgPAVIARAYg");
	this.shape_198.setTransform(-60.1,-32.2);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#2F2E2D").s().p("AgKAeQgEgDgDgFQgCgFAAgGIAAgVQAAgGACgGQADgFAEgCQAFgCAFgBQAGABAEACQAFACACAEQADAFAAAGIgHAAQAAgGgEgEQgEgDgFAAQgDABgDABQgDACgCADQgBADAAAFIAAAVQAAAFABADQACAEADABQADACADAAQAFAAAEgEQAEgDAAgGIAHAAQAAAGgDAEQgCAEgFADQgEACgGAAQgFAAgFgCg");
	this.shape_199.setTransform(-65.1,-33);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text2sl5, new cjs.Rectangle(-69.6,-41,166.9,104.4), null);


(lib.text2sl4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("AAoBiIAAjDIAmAAIAADDgAhNBiIAAjDIAmAAIAAA8IABAAQAYAAAOAKQAPAKAHAPQAHAOAAASQAAASgHAQQgHAPgPAKQgOAIgYABgAgnA9IABAAQALgBAGgEQAHgEADgHQAEgHAAgIQAAgHgEgIQgDgGgHgFQgGgEgLAAIgBAAg");
	this.shape.setTransform(34.9,-1.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("AAwB1IAAgmIhfAAIAAAmIghAAIAAhLIAQAAIAwieIAhAAIAwCeIAQAAIAABLgAAbAqIgbhlIgbBlIA2AAg");
	this.shape_1.setTransform(18.1,0.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6CD3DC").s().p("AgnBcQgQgJgJgQQgJgRAAgVIAAg4QAAgWAJgQQAJgQAQgKQAQgJAXAAQAXAAARAJQARAKAIAQQAJAQAAAWIAAA4QAAAVgJARQgIAQgRAJQgRAJgXAAQgXAAgQgJgAgSg6QgHAEgFAIQgFAHgBAMIAAA4QABALAFAIQAFAIAHAEQAJAEAJAAQAKAAAIgEQAJgEAFgIQAEgIAAgLIAAg4QAAgMgEgHQgFgIgJgEQgIgEgKAAQgJAAgJAEg");
	this.shape_2.setTransform(1.1,-1.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6CD3DC").s().p("Ag3BiIAAjDIBvAAIAAAlIhKAAIAACeg");
	this.shape_3.setTransform(-15.4,-1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CD3DC").s().p("AAoBiIAAjDIAmAAIAADDgAhNBiIAAjDIAmAAIAAA8IABAAQAYAAAOAKQAPAKAHAPQAHAOAAASQAAASgHAQQgHAPgPAKQgOAIgYABgAgnA9IABAAQALgBAGgEQAHgEADgHQAEgHAAgIQAAgHgEgIQgDgGgHgFQgGgEgLAAIgBAAg");
	this.shape_4.setTransform(-33.1,-1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6CD3DC").s().p("AhJBiIAAjDIBQAAQAeAAAQAQQAQAPAAAZQAAANgEAKQgEAKgKAHQALAHAGALQAGAKAAANQAAAbgQAQQgQAOgeABgAgkA9IAxAAQALAAAHgGQAFgGAAgKQABgLgHgFQgGgGgLABIgxAAgAgkgSIAsAAQALAAAGgGQAHgFAAgLQAAgKgHgFQgGgFgLAAIgsAAg");
	this.shape_5.setTransform(-49.6,-1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text2sl4, new cjs.Rectangle(-60.4,-21.3,106.2,37.9), null);


(lib.text2sl3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("AgOBJIAAh1IgpAAIAAgcIBvAAIAAAcIgqAAIAAB1g");
	this.shape.setTransform(42,-3.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("AgdBEQgNgGgGgNQgGgMAAgQIAAgqQAAgPAGgNQAGgMANgHQAMgHARAAQASAAAMAHQAMAHAGAMQAHANAAAPIAAAqQAAAQgHAMQgGANgMAGQgMAIgSgBQgRABgMgIgAgNgrQgGACgEAHQgDAFAAAIIAAAqQAAAIADAHQAEAGAGADQAGACAHAAQAIAAAFgCQAHgDAEgGQADgHAAgIIAAgqQAAgIgDgFQgEgHgHgCQgFgEgIAAQgHAAgGAEg");
	this.shape_1.setTransform(29.2,-3.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6CD3DC").s().p("AgdBEQgNgHgGgMQgHgLABgQIAAgpQgBgQAHgNQAGgMANgHQAMgGARgBQARAAAMAHQAMAGAHALQAGAMACAPIgdAAQgBgKgIgHQgHgFgLAAQgHAAgGADQgGACgEAHQgEAFABAJIAAApQgBAIAEAGQAEAGAGADQAGACAHABQALgBAHgFQAIgGABgKIAdAAQgCAPgGAKQgHAMgMAFQgMAHgRgBQgRAAgMgGg");
	this.shape_2.setTransform(3.8,-3.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6CD3DC").s().p("AgdBEQgNgGgGgNQgGgMAAgQIAAgqQAAgPAGgNQAGgMANgHQAMgHARAAQASAAAMAHQAMAHAGAMQAHANAAAPIAAAqQAAAQgHAMQgGANgMAGQgMAIgSgBQgRABgMgIgAgNgrQgGACgEAHQgDAFAAAIIAAAqQAAAIADAHQAEAGAGADQAGACAHAAQAIAAAFgCQAHgDAEgGQADgHAAgIIAAgqQAAgIgDgFQgEgHgHgCQgFgEgIAAQgHAAgGAEg");
	this.shape_3.setTransform(-9,-3.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CD3DC").s().p("AAbBJIAAg8Ig2AAIAAA8IgcAAIAAiRIAcAAIAAA6IA2AAIAAg6IAcAAIAACRg");
	this.shape_4.setTransform(-21.8,-3.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6CD3DC").s().p("AgmA+QgOgOgBgXIAdAAQAAALAIAFQAHAHALgBQAKAAAHgEQAGgFAAgJQABgHgFgEQgEgFgKAAIgXAAIAAgbIAUAAQAJAAAEgDQAFgFAAgGQAAgGgDgFQgDgEgFgBQgFgDgGAAQgJABgHAFQgGAHAAAKIgdAAQABgOAGgMQAHgMALgGQAMgHAOAAQANAAALAFQAMAFAHAJQAHAKAAAOQAAAKgDAIQgDAHgHAHQAIAEAEAIQAFAJAAAKQgBAPgGAJQgHAKgLAGQgMAEgPAAQgZAAgPgNg");
	this.shape_5.setTransform(-34.4,-3.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#6CD3DC").s().p("Ag2BJIAAiRIA7AAQAXAAALALQAMAMAAASQAAAKgDAHQgDAIgHAGQAJAEAEAIQAEAIABAKQgBAUgLAMQgMAMgXgBgAgaAuIAkAAQAIAAAEgFQAFgEAAgIQAAgHgFgEQgFgFgHAAIgkAAgAgagOIAgAAQAIAAAFgDQAFgFgBgIQABgHgFgEQgFgEgIABIggAAg");
	this.shape_6.setTransform(-47,-3.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text2sl3, new cjs.Rectangle(-55.7,-18.9,106.2,29.4), null);


(lib.text2sl2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAiENQgZgPgNgYQgPgZAAgfQAAgfAPgZQANgYAZgPQAZgOAfgBQAeABAZAOQAZAPAPAYQAPAZAAAfQAAAfgPAZQgPAYgZAPQgZAPgeAAQgfAAgZgPgABCCWQgJAJAAAPQAAAPAJAKQAIAJAQAAQAPAAAJgJQAJgKAAgPQAAgPgJgJQgJgKgPAAQgQAAgIAKgAi6CgIFblbIAZAZIlaFcgAiRhOQgZgPgOgYQgPgZAAgeQAAggAPgYQAOgZAZgPQAZgOAegBQAfABAZAOQAZAPAOAZQAPAYAAAgQAAAegPAZQgOAYgZAPQgZAOgfABQgegBgZgOgAhxjGQgJALAAAPQAAAOAJAJQAIAKAPABQAQgBAJgKQAJgJAAgOQAAgPgJgLQgJgKgQABQgPgBgIAKg");
	this.shape.setTransform(12,-8.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhdEDQgrgYgXgqQgXgqgBgzIBqAAQAAAnAVAZQAVAYAjABQAYAAARgMQASgLAKgTQAJgSAAgXIAAgTQAAgVgJgTQgKgTgSgMQgRgKgYgBQgXABgRALQgRAMgJAUIhuhJIA5kDIEKAAIAABfIi1AAIgaB0QAOgJASgEQAQgFAUAAQAvACAoAXQAoAZAYApQAYAqABAzIAAAGQgBAzgUAqQgVAqgoAYQgnAZg3AAQg6AAgrgZg");
	this.shape_1.setTransform(-36.8,-8.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text2sl2, new cjs.Rectangle(-62.9,-62.5,101.4,100.8), null);


(lib.text1sl5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AgFAXIgGgDQgCgCgCgEQgCgDAAgFIAAgdIAHAAIAAAcQAAAEACADQABADACABQADABACAAQADAAADgBQACgBACgDQABgDAAgDIAAgdIAHAAIAAAuIgHAAIAAgFQgCADgDABIgGACIgFgBg");
	this.shape.setTransform(101.2,12.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("AgKAYIAAguIAHAAIAAAFQACgDACgBQADgCAEAAIADAAIAAAHIgDAAQgDAAgDABQgCACgBACQgCADAAAEIAAAcg");
	this.shape_1.setTransform(97.6,12.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_2.setTransform(94.6,14.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("AgNAfIAAgGIAEAAIADgBIABgCIADgHIgRguIAGAAIANAlIANglIAHAAIgUA6QAAABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAIgHABg");
	this.shape_3.setTransform(91.3,13.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2E2D").s().p("AAFAdIgFgBQgBgBAAAAQgBAAAAgBQgBAAAAgBQgBAAAAgBIgBgGIAAgdIgGAAIAAgGIAGAAIAAgKIAGAAIAAAKIALAAIAAAGIgLAAIAAAdIABADIADABIAHAAIAAAHg");
	this.shape_4.setTransform(87.6,11.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F2E2D").s().p("AAFAgIgGgBQAAgBgBAAQAAAAgBgBQAAAAgBgBQAAAAAAgBIgBgGIAAgzIAGAAIAAAzIAAADIAEABIABAAIAAAHg");
	this.shape_5.setTransform(85.1,11.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F2E2D").s().p("AgJAXQgEgCgCgDQgDgDABgFIABgFIACgEQACgCAFgBIAHgCIALgBIAAAAQABgEgCgDQgCgCgCgCQgDgBgDAAQgDAAgDACQgDACgBAFIgHAAQAAgGADgDQADgEAEgBQAEgCADABQAFgBAEACQAEACADAEQACAEAAAHIAAAcIgHAAIAAgEQgCACgDACQgEABgEAAQgEAAgDgBgAAAACQgEAAgDACQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIAAADQAAADACADQADACAFAAQACAAADgCQADgBACgCQACgDgBgDIAAgHIgLACg");
	this.shape_6.setTransform(81.4,12.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_7.setTransform(76.8,12.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2F2E2D").s().p("AgKAYIAAguIAHAAIAAAFQACgDACgBQADgCAEAAIADAAIAAAHIgDAAQgDAAgDABQgCACgBACQgCADAAAEIAAAcg");
	this.shape_8.setTransform(73.2,12.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2F2E2D").s().p("AgMADIAAgFIAZAAIAAAFg");
	this.shape_9.setTransform(69.7,12.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_10.setTransform(65.5,13.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2F2E2D").s().p("AgHAXQgEgCgDgEQgCgDAAgGIAGAAQABAFADADQAEACADAAQAFAAADgCQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAgBQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBAAAAQgCgCgEgBIgIgCIgFgCIgFgDQgBgDAAgEQgBgEADgDQACgDAEgCQADgBAEAAQAEAAADABQAFACABADQADADAAAFIgGAAQgBgEgDgCQgCgCgEAAIgGACQgCACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQAAABAAAAQABAAAAABQABAAABAAQAAAAABAAIAHACQAGACADACQAEADAAAGQgBAFgCADQgCADgDABQgEABgFAAQgEAAgEgBg");
	this.shape_11.setTransform(60.9,12.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2F2E2D").s().p("AgRAXIAAgGIAaghIgZAAIAAgGIAhAAIAAAGIgZAhIAaAAIAAAGg");
	this.shape_12.setTransform(56.7,12.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_13.setTransform(52.2,13.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_14.setTransform(45.4,12.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2F2E2D").s().p("AgCAXIAAgnIgPAAIAAgGIAjAAIAAAGIgPAAIAAAng");
	this.shape_15.setTransform(41,12.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2F2E2D").s().p("AAMAgIAAgjIgWAjIgHAAIAAguIAHAAIAAAjIAWgjIAGAAIAAAugAgBgTQgDAAgCgCIgFgDIgBgGIAFAAQAAAAAAABQABAAAAABQAAAAAAABQABABAAAAQABAAAAABQAAAAABAAQAAAAABAAQABABAAAAIADAAQAAAAABgBQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAgBQAAgBAAAAQABgBAAAAQAAgBAAAAIAFAAIgBAGIgEADQgDACgDAAg");
	this.shape_16.setTransform(36.5,11.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2F2E2D").s().p("AgJAXQgEgCgCgDQgCgDgBgFIABgFIADgEQADgCAEgBIAHgCIALgBIAAAAQAAgEgBgDQgBgCgDgCQgDgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGACgDQADgEAEgBQAEgCADABQAFgBADACQAFACADAEQACAEAAAHIAAAcIgHAAIAAgEQgCACgDACQgEABgEAAQgEAAgDgBgAAAACQgEAAgDACQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIAAADQgBADADADQADACAFAAQACAAADgCQADgBACgCQABgDAAgDIAAgHIgLACg");
	this.shape_17.setTransform(31.6,12.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAEACIAHAFQACAEABAFIgHAAIgCgFIgEgDQgCgBgDAAQgCAAgDABIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAIAFgBIAEgEIACgFIAHAAQgBAGgCAEQgDADgEACQgEABgEAAQgEAAgEgBg");
	this.shape_18.setTransform(27,12.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgDgDAAgFIABgFIAEgEQACgCAEgBIAHgCIAMgBIAAAAQAAgEgCgDQgCgCgDgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGADgDQACgEAEgBQAEgCADABQAEgBAEACQAFACACAEQADAEAAAHIAAAcIgGAAIAAgEQgCACgFACQgDABgEAAQgEAAgEgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQABADACADQADACAEAAQADAAADgCQADgBACgCQACgDAAgDIAAgHIgMACg");
	this.shape_19.setTransform(20.2,12.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2F2E2D").s().p("AALAXIAAgUIgVAAIAAAUIgHAAIAAgtIAHAAIAAATIAVAAIAAgTIAHAAIAAAtg");
	this.shape_20.setTransform(15.3,12.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_21.setTransform(8.3,12.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_22.setTransform(3.3,12.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2F2E2D").s().p("AANAdIAAgLIggAAIAAguIAHAAIAAAnIATAAIAAgnIAGAAIAAAnIAHAAIAAASg");
	this.shape_23.setTransform(-1.4,13);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgCgDgBgFIABgFIAEgEQABgCAFgBIAHgCIALgBIAAAAQAAgEgBgDQgBgCgDgCQgDgBgDAAQgDAAgDACQgDACgBAFIgHAAQAAgGAEgDQACgEAEgBQAEgCADABQAFgBADACQAFACADAEQACAEAAAHIAAAcIgHAAIAAgEQgCACgDACQgEABgEAAQgEAAgEgBgAAAACQgEAAgDACQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIAAADQgBADADADQADACAEAAQADAAADgCQADgBACgCQABgDAAgDIAAgHIgLACg");
	this.shape_24.setTransform(-6.6,12.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_25.setTransform(-11.3,13.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgDgDAAgFIACgFIADgEQACgCAEgBIAIgCIALgBIAAAAQgBgEgBgDQgCgCgDgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGADgDQACgEAEgBQAEgCADABQAEgBAEACQAFACACAEQADAEABAHIAAAcIgHAAIAAgEQgDACgEACQgDABgEAAQgEAAgEgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQABADACADQACACAFAAQADAAADgCQADgBACgCQABgDABgDIAAgHIgMACg");
	this.shape_26.setTransform(-16.2,12.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2F2E2D").s().p("AgTAXIAAgGIAFgBQABAAAAAAQABAAAAgBQAAAAAAAAQABgBAAAAQAAAAAAgBQAAAAAAAAQABgBAAAAQAAgBAAAAIABgGIABgKIABgRIAbAAIAAAtIgHAAIAAgnIgOAAIgBAQIgCAMQgBAFgCADQgCACgDABIgEAAIgDAAg");
	this.shape_27.setTransform(-21.3,12.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2F2E2D").s().p("AAKAXIgNgUIgHAAIAAAUIgHAAIAAgtIAHAAIAAATIAGAAIAMgTIAIAAIgPAVIARAYg");
	this.shape_28.setTransform(-25.3,12.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_29.setTransform(-30.1,12.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2F2E2D").s().p("AAQAdIAAgLIgfAAIAAALIgHAAIAAgSIAEAAIAAAAIACgBIACgDIABgHIABgPIABgNIAbAAIAAAnIAHAAIAAASgAgGgPIgBAQIgCAKIASAAIAAghIgOAAg");
	this.shape_30.setTransform(-35,13);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_31.setTransform(-41.9,12.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2F2E2D").s().p("AAQAXIAAgtIAGAAIAAAtgAgVAXIAAgtIAHAAIAAARIAJAAQAFAAADACQADACACADIABAHIgBAHQgCADgDACQgDACgGAAgAgOARIAJAAQAEAAABgCQACgCAAgFQAAgEgCgCQgBgCgEAAIgJAAg");
	this.shape_32.setTransform(-47.2,12.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2F2E2D").s().p("AALAXIAAgUIgVAAIAAAUIgHAAIAAgtIAHAAIAAATIAVAAIAAgTIAHAAIAAAtg");
	this.shape_33.setTransform(-52.6,12.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2F2E2D").s().p("AgDAXIAAgnIgOAAIAAgGIAjAAIAAAGIgPAAIAAAng");
	this.shape_34.setTransform(-57,12.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2F2E2D").s().p("AAKAXIgNgUIgHAAIAAAUIgHAAIAAgtIAHAAIAAATIAGAAIAMgTIAIAAIgPAVIARAYg");
	this.shape_35.setTransform(-60.9,12.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_36.setTransform(-65.7,12.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_37.setTransform(-70.5,12.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_38.setTransform(-75.2,13.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#2F2E2D").s().p("AANAgIAAg3IgZAAIAAA3IgHAAIAAg+IAnAAIAAA+g");
	this.shape_39.setTransform(-80.4,11.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#2F2E2D").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_40.setTransform(102.4,1.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#2F2E2D").s().p("AgMAXIAAgtIAaAAIAAAGIgUAAIAAAng");
	this.shape_41.setTransform(99.6,-0.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#2F2E2D").s().p("AgHAfQgFgDgCgDQgDgEAAgGQAAgFACgEQABgEAEgCQgDgCgBgDQgCgDAAgFQAAgHACgEQADgDAEgCQAEgCADAAQAEAAAFACQAEACACADQADAEAAAHQgBAFgCADQgBADgDACQAEACABAEQACAEAAAFQAAAGgDAEQgCADgEADQgEACgFAAQgDAAgEgCgAgFAFIgDADQgDADAAAEQAAADADACIADAFQADABACAAQADAAACgBQADgCACgDQABgCABgDQgBgEgBgDQgCgCgDgBQgCgCgDAAQgCAAgDACgAgHgWQgDADAAAGQAAADACACQABADACACIAFABIAFgBIAFgFQABgCAAgDQAAgGgDgDQgCgDgGAAQgEAAgDADg");
	this.shape_42.setTransform(93.3,-1.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#2F2E2D").s().p("AADAgIAAg2IgLALIAAgJIALgKIAHAAIAAA+g");
	this.shape_43.setTransform(89.2,-1.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#2F2E2D").s().p("AgIAfQgEgCgDgEQgCgEAAgHIAAgbQAAgHACgEQADgEAEgCQAEgBAEAAQAFAAAEABQADACAEAEQACAEAAAHIAAAbQAAAHgCAEQgEAEgDACQgEABgFABQgEgBgEgBgAgFgYQgDACgBACQgBADAAAEIAAAcQAAADABADQABACADACQADABACAAQADAAADgBIAEgEQACgDgBgDIAAgcQABgEgCgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_44.setTransform(85.5,-1.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#2F2E2D").s().p("AgRAgIAAgHIAVgYIAGgGQABgEABgEQgBgEgBgDIgFgDQgCgCgDABQgCgBgDACIgEADQgCAEAAADIAAACIgBAAIgCAAIgCAAIgBAAIAAgCQAAgGACgEQADgEAFgDQAEgBADAAQAFAAAEABQADADADAEQADADAAAHQAAAFgDAFIgGAIIgRAUIAaAAIAAAHg");
	this.shape_45.setTransform(80.8,-1.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#2F2E2D").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_46.setTransform(77.3,1.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#2F2E2D").s().p("AAHAgIAAgRIgbAAIAAgHIAbgmIAIAAIAAAmIAGAAIAAAHIgGAAIAAARgAgMAIIATAAIAAgcg");
	this.shape_47.setTransform(73.7,-1.2);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#2F2E2D").s().p("AgHAfQgFgCgCgEQgDgEAAgHIAAgbQAAgHADgEQACgEAFgCQAEgBADAAQAFAAAEABQADACADAEQADAEAAAHIAAAbQAAAHgDAEQgDAEgDACQgEABgFABQgDgBgEgBgAgFgYQgDACgBACQgCADAAAEIAAAcQAAADACADQABACADACQADABACAAQADAAACgBQADgCACgCQABgDAAgDIAAgcQAAgEgBgDIgFgEQgCgBgDAAQgCAAgDABg");
	this.shape_48.setTransform(69.1,-1.2);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#2F2E2D").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_49.setTransform(65.4,1.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#2F2E2D").s().p("AgIAfQgDgCgEgEQgCgEAAgHIAAgbQAAgHACgEQAEgEADgCQAFgBADAAQAFAAADABQAEACAEAEQACAEAAAHIAAAbQAAAHgCAEQgEAEgEACQgDABgFABQgDgBgFgBgAgEgYQgEACgBACQgCADABAEIAAAcQgBADACADQABACAEACQACABACAAQADAAADgBIAEgEQABgDAAgDIAAgcQAAgEgBgDIgEgEQgDgBgDAAQgCAAgCABg");
	this.shape_50.setTransform(61.8,-1.2);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#2F2E2D").s().p("AgHAfQgEgCgDgEQgDgEAAgHIAAAAIABAAIACAAIADAAIABAAIAAABQAAADABADIAFAEQACABADAAQAFAAADgDQADgDAAgFQAAgDgCgDIgEgEQgCgCgDAAIgEAAIAAgFIAEAAQAEAAADgEQAEgDAAgFQAAgDgCgDIgEgEQgDgBgDAAQgCAAgCABQgDACgCACQgBADAAAEIAAABIgBAAIgDAAIgCAAIgBAAIAAgBQAAgHADgEQACgEAFgBQAEgCADAAQAFAAAEACQAEABADAEQACAEAAAGQAAAFgCAFIgFAEQADABACAFQACAEAAAFQAAAGgCAEQgDAEgEACQgEACgEAAQgEAAgEgCg");
	this.shape_51.setTransform(57,-1.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_52.setTransform(50.4,-0.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#2F2E2D").s().p("AAKAXIAAgnIgTAAIAAAnIgHAAIAAgtIAhAAIAAAtg");
	this.shape_53.setTransform(45.6,-0.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#2F2E2D").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_54.setTransform(40,1.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#2F2E2D").s().p("AgMAXIAAgtIAaAAIAAAGIgTAAIAAAng");
	this.shape_55.setTransform(37.2,-0.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#2F2E2D").s().p("AgHAfQgFgDgDgDQgCgEAAgGQAAgFACgEQACgEAEgCQgEgCgCgDQgBgDAAgFQgBgHADgEQACgDAFgCQAEgCADAAQAFAAAEACQAEACACADQADAEAAAHQAAAFgDADQgBADgDACQADACADAEQABAEAAAFQAAAGgDAEQgCADgEADQgEACgFAAQgDAAgEgCgAgFAFIgDADQgCADgBAEQABADACACIADAFQADABACAAQADAAACgBQAEgCABgDQABgCABgDQgBgEgBgDQgBgCgEgBQgCgCgDAAQgCAAgDACgAgHgWQgCADAAAGQAAADABACQABADACACIAFABIAFgBIAFgFQABgCAAgDQAAgGgDgDQgCgDgGAAQgEAAgDADg");
	this.shape_56.setTransform(30.8,-1.2);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#2F2E2D").s().p("AADAgIAAg2IgLALIAAgJIALgKIAHAAIAAA+g");
	this.shape_57.setTransform(26.8,-1.2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#2F2E2D").s().p("AgIAfQgDgCgEgEQgCgEAAgHIAAgbQAAgHACgEQAEgEADgCQAEgBAEAAQAFAAAEABQAEACADAEQACAEAAAHIAAAbQAAAHgCAEQgDAEgEACQgEABgFABQgEgBgEgBgAgFgYQgCACgCACQgCADABAEIAAAcQgBADACADQACACACACQADABACAAQADAAADgBIAEgEQABgDAAgDIAAgcQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_58.setTransform(23,-1.2);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#2F2E2D").s().p("AgRAgIAAgHIAVgYIAGgGQABgEAAgEQABgEgCgDIgFgDQgCgCgDABQgCgBgDACIgEADQgBAEAAADIAAACIgCAAIgCAAIgCAAIgBAAIAAgCQAAgGACgEQAEgEAEgDQADgBAEAAQAEAAAFABQADADAEAEQACADAAAHQAAAFgCAFIgHAIIgRAUIAaAAIAAAHg");
	this.shape_59.setTransform(18.3,-1.2);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#2F2E2D").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_60.setTransform(14.8,1.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#2F2E2D").s().p("AgHAfQgEgCgDgEQgDgEAAgHIAAAAIABAAIACAAIADAAIABAAIAAABQAAADABADIAFAEQACABADAAQAFAAADgDQADgDAAgFQAAgDgCgDIgEgEQgCgCgDAAIgEAAIAAgFIAEAAQAEAAADgEQAEgDAAgFQAAgDgCgDIgEgEQgDgBgDAAQgCAAgCABQgDACgCACQgBADAAAEIAAABIgBAAIgDAAIgCAAIgBAAIAAgBQAAgHADgEQACgEAFgBQAEgCADAAQAFAAAEACQAEABADAEQACAEAAAGQAAAFgCAFIgFAEQADABACAFQACAEAAAFQAAAGgCAEQgDAEgEACQgEACgEAAQgEAAgEgCg");
	this.shape_61.setTransform(11.2,-1.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#2F2E2D").s().p("AgHAfQgEgCgEgEQgCgEAAgHIAAgbQAAgHACgEQAEgEAEgCQADgBAEAAQAEAAAFABQADACAEAEQACAEAAAHIAAAbQAAAHgCAEQgEAEgDACQgFABgEABQgEgBgDgBgAgFgYQgDACgBACQgBADAAAEIAAAcQAAADABADQABACADACQADABACAAQADAAACgBQADgCACgCQACgDgBgDIAAgcQABgEgCgDIgFgEQgCgBgDAAQgCAAgDABg");
	this.shape_62.setTransform(6.6,-1.2);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#2F2E2D").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_63.setTransform(3,1.5);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#2F2E2D").s().p("AAIAgIAAgRIgcAAIAAgHIAcgmIAGAAIAAAmIAHAAIAAAHIgHAAIAAARgAgNAIIAVAAIAAgcg");
	this.shape_64.setTransform(-0.6,-1.2);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#2F2E2D").s().p("AADAgIAAg2IgLALIAAgJIALgKIAGAAIAAA+g");
	this.shape_65.setTransform(-4.5,-1.2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAEACIAHAFQACAEABAFIgHAAIgCgFIgEgDQgCgBgDAAQgCAAgDABIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAIAFgBIAEgEIACgFIAHAAQgBAGgCAEQgDADgEACQgEABgEAAQgEAAgEgBg");
	this.shape_66.setTransform(-10.2,-0.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#2F2E2D").s().p("AgDAXIAAgnIgOAAIAAgGIAjAAIAAAGIgPAAIAAAng");
	this.shape_67.setTransform(-16.5,-0.4);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_68.setTransform(-20.9,-0.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#2F2E2D").s().p("AgOAfIABgGQAEAAACgBQACgBABgDIABgFIgQguIAGAAIANAlIANglIAHAAIgTA3QgBAFgEACIgFABIgFgBg");
	this.shape_69.setTransform(-25.3,0.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#2F2E2D").s().p("AgRAXIAAgtIAUAAQAFAAADACIAEAEIABAHIgBAFQgBADgCABQADABABADIACAGQAAAEgCADQgBADgDABQgDACgFAAgAgKARIAOAAQADAAACgCQACgBAAgEQAAgDgCgCQgCgCgDAAIgOAAgAgKgCIANAAQADAAACgCQACgCAAgDQAAgEgCgBQgCgCgDAAIgNAAg");
	this.shape_70.setTransform(-29.7,-0.4);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#2F2E2D").s().p("AgDAXIAAgnIgOAAIAAgGIAjAAIAAAGIgOAAIAAAng");
	this.shape_71.setTransform(-34.2,-0.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAEACIAHAFQACAEABAFIgHAAIgCgFIgEgDQgCgBgDAAQgCAAgDABIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAIAFgBIAEgEIACgFIAHAAQgBAGgCAEQgDADgEACQgEABgEAAQgEAAgEgBg");
	this.shape_72.setTransform(-38.5,-0.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#2F2E2D").s().p("AAMAgIAAgjIgWAjIgHAAIAAguIAHAAIAAAjIAWgjIAGAAIAAAugAgBgTQgDAAgCgBIgFgFIgBgFIAFAAQAAAAAAABQAAAAABABQAAAAAAABQABABAAAAQABAAAAABQABAAAAAAQABAAAAAAQABAAAAAAIADAAQAAAAABAAQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAgBQAAgBAAAAQABgBAAAAQAAgBAAAAIAFAAIgBAFIgEAFQgDABgDAAg");
	this.shape_73.setTransform(-43.4,-1.2);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAAHIgcAAIAAAEQAAAEABADQACACACABQADACACAAQAEAAADgDQADgCABgEIAHAAQgBAFgCAEQgDADgEACQgEABgEAAQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAABIAVAAIAAgBQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_74.setTransform(-48.2,-0.4);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#2F2E2D").s().p("AAQAdIAAgLIgfAAIAAALIgHAAIAAgSIAEAAIABAAIABAAIACgFIABgGIABgPIABgNIAbAAIAAAnIAHAAIAAASgAgGgPIgBAQIgCAKIASAAIAAghIgOAAg");
	this.shape_75.setTransform(-53.1,0.2);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#2F2E2D").s().p("AAKAXIAAgSIgHAAIgLASIgIAAIAMgSQgDgBgDgCIgDgEIgBgGIABgGQABgEADgCQADgCAGAAIARAAIAAAtgAgFgOQgCACAAAEQAAAEACACQACACADAAIAKAAIAAgQIgKAAQgDAAgCACg");
	this.shape_76.setTransform(-60,-0.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_77.setTransform(-64.6,-0.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#2F2E2D").s().p("AANAdIAAgLIggAAIAAguIAHAAIAAAnIATAAIAAgnIAGAAIAAAnIAHAAIAAASg");
	this.shape_78.setTransform(-69.4,0.2);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#2F2E2D").s().p("AAKAXIgNgUIgHAAIAAAUIgHAAIAAgtIAHAAIAAATIAGAAIAMgTIAIAAIgPAVIARAYg");
	this.shape_79.setTransform(-74,-0.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#2F2E2D").s().p("AARAgIgGgSIgWAAIgFASIgHAAIAUg+IAHAAIAUA+gAAKAHIgKgcIgIAcIASAAg");
	this.shape_80.setTransform(-79,-1.2);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#2F2E2D").s().p("AAAAJIALgJIgLgIIAAgHIAPAMIAAAGIgPAOgAgOAJIAJgJIgJgIIAAgHIAOAMIAAAGIgOAOg");
	this.shape_81.setTransform(101.6,-13.3);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#2F2E2D").s().p("AANAfIAAg3IgZAAIAAA3IgHAAIAAg+IAnAAIAAA+g");
	this.shape_82.setTransform(96.7,-14);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#2F2E2D").s().p("AgKAeQgEgCgDgGQgCgFAAgGIAAgVQAAgGACgGQADgFAEgCQAFgDAFAAQAGAAAEADQAFACACAEQADAFAAAGIgHAAQAAgGgEgEQgEgDgFAAQgDABgDABQgDACgCADQgBADAAAFIAAAVQAAAFABADQACAEADABQADABADABQAFAAAEgEQAEgDAAgGIAHAAQAAAGgDAFQgCAEgFACQgEADgGAAQgFAAgFgDg");
	this.shape_83.setTransform(91.5,-14);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#2F2E2D").s().p("AgNAbQgFgFgBgJIAHAAQABAGADADQAEAEAFAAQAGAAADgEQADgDAAgFQAAgFgEgDQgDgDgFAAIgIAAIAAgGIAIAAIAFgBQACgBACgDQABgCAAgDQAAgEgBgCIgDgEQgDgBgEgBIgFACIgEAEQgCADAAAEIgHAAQABgGACgFQACgEAFgCQAEgDAEAAQAGAAAEADQAFADACAEQABAEAAAFIgBAHQgCADgEADQAEABACAEQADAEAAAGQAAAEgCAEQgCAEgEACQgEADgHABQgIAAgGgGg");
	this.shape_84.setTransform(86.5,-14);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#2F2E2D").s().p("AANAfIAAg3IgZAAIAAA3IgHAAIAAg+IAnAAIAAA+g");
	this.shape_85.setTransform(81.3,-14);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#2F2E2D").s().p("AABADIAAgGIAPgMIAAAHIgKAIIAKAJIAAAIgAgPADIAAgGIAPgMIAAAHIgJAIIAJAJIAAAIg");
	this.shape_86.setTransform(76.4,-13.3);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#2F2E2D").s().p("AgKAeQgEgCgDgGQgCgFAAgGIAAgVQAAgGACgGQADgFAEgCQAFgDAFAAQAGAAAFADQAEACADAFQACAGAAAGIAAAVQAAAGgCAFQgDAGgEACQgFADgGAAQgFAAgFgDgAgGgXQgDACgCADQgBADAAAFIAAAVQAAAFABADQACAEADABQADABADABQAEgBADgBQADgBACgEQABgDAAgFIAAgVQAAgFgBgDQgCgDgDgCQgDgBgEgBQgDABgDABg");
	this.shape_87.setTransform(69.8,-14);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#2F2E2D").s().p("AARAfIgGgSIgVAAIgGASIgHAAIAUg+IAHAAIAUA+gAAKAIIgKgdIgIAdIASAAg");
	this.shape_88.setTransform(64.7,-14);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#2F2E2D").s().p("AAKAXIgNgUIgHAAIAAAUIgHAAIAAgtIAHAAIAAATIAGAAIAMgTIAIAAIgPAVIARAYg");
	this.shape_89.setTransform(58.2,-13.2);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#2F2E2D").s().p("AAMAXIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtg");
	this.shape_90.setTransform(53.2,-13.2);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#2F2E2D").s().p("AAWAdIAAgMIgyAAIAAgtIAHAAIAAAnIAPAAIAAgnIAGAAIAAAnIAPAAIAAgnIAHAAIAAAnIAHAAIAAASg");
	this.shape_91.setTransform(47.7,-12.6);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#2F2E2D").s().p("AAMAfIAAgjIgWAjIgHAAIAAgtIAHAAIAAAjIAWgjIAGAAIAAAtgAgBgTQgDAAgCgBIgFgFIgBgGIAFAAQAAABAAABQABAAAAABQAAAAAAABQABAAAAABQABAAAAABQAAAAABAAQAAAAABAAQABAAAAAAIADAAQAAAAABAAQABAAAAAAQABAAAAAAQABgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAFAAIgBAGIgEAFQgDABgDAAg");
	this.shape_92.setTransform(41.6,-14);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAFACQAEACACAEQADAEAAAHIAAALQAAAHgDAEQgCAEgEACIgJABQgEAAgEgBgAgFgQIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAQADAAADgCQACgBACgCQABgDAAgEIAAgLQAAgEgBgDIgEgEQgDgBgDAAQgCAAgDABg");
	this.shape_93.setTransform(36.8,-13.2);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#2F2E2D").s().p("AgRAgIAAg+IAHAAIAAAFQACgDADgCIAFgBQAFAAAEACQAEABADAEQACAEAAAHIAAAMQAAAGgCAEQgDAEgEACQgEACgFAAQgCAAgDgCIgFgEIAAAVgAgEgXQgDABgCADQgBACAAAEIAAANQAAACABADQACADADABQACABACAAQADAAADgBQACgBACgDQACgDAAgCIAAgNQAAgEgCgCIgEgEQgDgCgDAAQgCAAgCACg");
	this.shape_94.setTransform(32,-12.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#2F2E2D").s().p("AgDAXIAAgnIgOAAIAAgGIAjAAIAAAGIgPAAIAAAng");
	this.shape_95.setTransform(27.6,-13.2);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#2F2E2D").s().p("AgIAXQgEgCgCgEQgDgEAAgHIAAgLQAAgHADgEQACgEAEgCQAEgCAEABQAEgBAEACIAHAFQACAEABAFIgHAAIgCgFIgEgDQgCgBgDAAQgCAAgDABIgEAEQgBADAAAEIAAALQAAAEABADQACACACABQADACACAAIAFgBIAEgEIACgFIAHAAQgBAGgCAEQgDADgEACQgEABgEAAQgEAAgEgBg");
	this.shape_96.setTransform(23.3,-13.2);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#2F2E2D").s().p("AgKAXQgDgCgCgDQgDgDAAgFIACgFIADgEQACgCAEgBIAIgCIALgBIAAAAQgBgEgBgDQgCgCgDgCQgCgBgDAAQgDAAgDACQgDACgBAFIgHAAQABgGADgDQACgEAEgBQAEgCADABQAEgBAEACQAFACACAEQADAEABAHIAAAcIgHAAIAAgEQgDACgEACQgDABgEAAQgEAAgEgBgAAAACQgEAAgCACQgBAAgBAAQAAABgBAAQAAAAAAABQgBAAAAABIgBADQABADACADQACACAFAAQADAAADgCQADgBACgCQABgDABgDIAAgHIgMACg");
	this.shape_97.setTransform(18.5,-13.2);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#2F2E2D").s().p("AgNAbQgGgFAAgJIAHAAQAAAGAFADQAEAEAEAAQAGAAADgEQADgDAAgFQAAgFgDgDQgEgDgFAAIgIAAIAAgGIAIAAIAFgBQACgBACgDQABgCAAgDQAAgEgBgCIgEgEQgCgBgDgBIgGACIgEAEQgCADAAAEIgHAAQAAgGADgFQADgEAEgCQAEgDAFAAQAFAAAFADQADADADAEQACAEAAAFIgCAHQgCADgEADQAFABACAEQACAEAAAGQAAAEgCAEQgCAEgEACQgDADgIABQgIAAgGgGg");
	this.shape_98.setTransform(13.7,-14);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text1sl5, new cjs.Rectangle(-85.4,-22,191.1,40.4), null);


(lib.text1sl4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("Ag7BiIAAjDIB3AAIAAAlIhRAAIAAAqIA9AAIAAAkIg9AAIAAArIBRAAIAAAlg");
	this.shape.setTransform(35.4,-1.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("AhLBiIAAjDIAjAAIAACeIAYAAIAAieIAiAAIAACeIAWAAIAAieIAkAAIAADDg");
	this.shape_1.setTransform(18.1,-1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6CD3DC").s().p("AhJBiIAAjDIAmAAIAAA8IApAAQAXAAAPAKQAPAKAIAPQAHAOAAASQAAASgHAQQgIAPgPAKQgPAIgXABgAgjA9IApAAQALgBAGgEQAHgEADgHQADgHAAgIQAAgHgDgIQgDgGgHgFQgGgEgLAAIgpAAg");
	this.shape_2.setTransform(1.7,-1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6CD3DC").s().p("AAwBiIgwiKIgwCKIgmAAIBGjDIAhAAIBGDDg");
	this.shape_3.setTransform(-15.9,-1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CD3DC").s().p("AgnBcQgRgJgIgQQgIgRgBgVIAAg4QABgWAIgQQAIgQARgKQARgJAWAAQAYAAAQAJQARAKAJAQQAIAQAAAWIAAA4QAAAVgIARQgJAQgRAJQgQAJgYAAQgWAAgRgJgAgSg6QgHAEgFAIQgFAHgBAMIAAA4QABALAFAIQAFAIAHAEQAJAEAJAAQALAAAHgEQAJgEAFgIQAEgIAAgLIAAg4QAAgMgEgHQgFgIgJgEQgHgEgLAAQgJAAgJAEg");
	this.shape_4.setTransform(-32.9,-1.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6CD3DC").s().p("AhJBiIAAjDICBAAIAAAlIhcAAIAAAqIAxAAQAcAAARAPQAPAQABAbQAAAbgQAQQgQAOgeABgAgkA9IAxAAQALAAAHgGQAFgGAAgKQABgLgHgFQgGgGgLABIgxAAg");
	this.shape_5.setTransform(-49.6,-1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text1sl4, new cjs.Rectangle(-60.4,-21.3,106.2,37.9), null);


(lib.text1sl3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("AAlB3IAAiCIhICCIgmAAIAAjDIAmAAIAACDIBIiDIAlAAIAADDgAgHhYQgOAAgIgJQgJgJAAgMIANAAQAAAHAGAFQAEAEAIAAIAQAAQAHAAAFgEQAEgFABgHIANAAQAAAMgJAJQgIAJgNAAg");
	this.shape.setTransform(35.1,-3.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6CD3DC").s().p("AAoBiIAAjDIAmAAIAADDgAhNBiIAAjDIAmAAIAAA8IABAAQAYAAAOAKQAPAKAHAPQAHAOAAASQAAASgHAQQgHAPgPAKQgOAIgYABgAgnA9IABAAQALgBAGgEQAHgEADgHQAEgHAAgIQAAgHgEgIQgDgGgHgFQgGgEgLAAIgBAAg");
	this.shape_1.setTransform(17.9,-1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6CD3DC").s().p("AhJBiIAAjDIBRAAQAdAAAQAQQAQAPAAAZQAAANgEAKQgFAKgIAHQAKAHAGALQAGAKAAANQAAAbgQAQQgQAOgeABgAgkA9IAxAAQAMAAAFgGQAHgGgBgKQAAgLgGgFQgHgGgKABIgxAAgAgkgSIAsAAQALAAAHgGQAFgFABgLQgBgKgFgFQgHgFgLAAIgsAAg");
	this.shape_2.setTransform(1.4,-1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6CD3DC").s().p("AhJBiIAAjDIBPAAQAXAAAPAKQAPAJAIAPQAHAPAAASQAAATgHAOQgIAQgPAJQgPAKgXAAIgpAAIAAA8gAgjABIApAAQALgBAGgDQAHgFADgHQADgHAAgIQAAgHgDgHQgDgHgHgFQgGgEgLAAIgpAAg");
	this.shape_3.setTransform(-15.3,-1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CD3DC").s().p("Ag7BiIAAjDIB3AAIAAAlIhRAAIAAAqIA9AAIAAAkIg9AAIAAArIBRAAIAAAlg");
	this.shape_4.setTransform(-32.6,-1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6CD3DC").s().p("AAlBiIAAieIhJAAIAACeIglAAIAAjDICTAAIAADDg");
	this.shape_5.setTransform(-49.9,-1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text1sl3, new cjs.Rectangle(-60.4,-21.3,106.2,37.9), null);


(lib.text1sl2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAxBiIgOgoIhFAAIgOAoIgnAAIBGjDIAjAAIBGDDgAAWAXIgWg/IgVA/IArAAg");
	this.shape.setTransform(35.1,-1.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAeBiIgyhQIgTAAIAABQIglAAIAAjDIAlAAIAABPIATAAIAzhPIAuAAIhDBeIBCBlg");
	this.shape_1.setTransform(18.4,-1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAwB1IAAgmIhfAAIAAAmIghAAIAAhLIAQAAIAwieIAhAAIAwCeIAQAAIAABLgAAbAqIgbhlIgbBlIA2AAg");
	this.shape_2.setTransform(1.1,0.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAkBiIAAiDIhICDIglAAIAAjDIAlAAIAACCIBIiCIAmAAIAADDg");
	this.shape_3.setTransform(-15.9,-1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAeBiIgyhQIgTAAIAABQIglAAIAAjDIAlAAIAABPIATAAIAzhPIAuAAIhDBeIBCBlg");
	this.shape_4.setTransform(-32.6,-1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgnBbQgQgJgJgQQgJgPAAgVIAAg4QAAgVAJgRQAJgQAQgJQAQgJAXgBQAXABAQAIQAQAJAJAPQAJAQABAUIgmAAQgBgPgKgIQgLgIgOAAQgJAAgJAEQgIAEgEAIQgGAIAAALIAAA4QAAALAGAHQAEAIAIAEQAJAEAJAAQAOAAALgIQAKgIABgOIAmAAQgBAUgJAPQgJAOgQAIQgQAJgXgBQgXAAgQgIg");
	this.shape_5.setTransform(-49.8,-1.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text1sl2, new cjs.Rectangle(-60.4,-21.3,106.2,37.9), null);


(lib.text4sl1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AgVBiIAAgtIArAAIAAAtgAgSAiIAAiDIAkAAIAACDg");
	this.shape.setTransform(112.5,20.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("AAlBiIAAiDIhICDIgmAAIAAjDIAmAAIAACDIBIiDIAlAAIAADDg");
	this.shape_1.setTransform(95.5,20.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AAeBiIgyhQIgTAAIAABQIglAAIAAjDIAlAAIAABPIATAAIAzhPIAuAAIhDBfIBCBkg");
	this.shape_2.setTransform(78.8,20.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("AAwB1IAAgmIhfAAIAAAmIghAAIAAhLIAQAAIAwieIAhAAIAwCeIAQAAIAABLgAAbAqIgbhlIgbBlIA2AAg");
	this.shape_3.setTransform(61.5,22.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2E2D").s().p("AAkBiIAAiDIhHCDIgmAAIAAjDIAmAAIAACDIBHiDIAmAAIAADDg");
	this.shape_4.setTransform(44.5,20.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F2E2D").s().p("AAeBiIgyhQIgTAAIAABQIglAAIAAjDIAlAAIAABPIATAAIAzhPIAuAAIhDBfIBCBkg");
	this.shape_5.setTransform(27.8,20.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F2E2D").s().p("AgnBbQgQgJgJgPQgJgQAAgVIAAg4QAAgVAJgRQAJgQAQgJQARgJAWgBQAXABAQAIQARAJAIAPQAJAPABAVIgmAAQgCgPgJgIQgLgIgOAAQgJAAgIAEQgJAEgFAIQgEAIAAALIAAA4QAAALAEAIQAFAHAJAEQAIAEAJAAQAOAAALgIQAJgIACgOIAmAAQgBAUgJAPQgIAOgRAIQgQAIgXAAQgWABgRgJg");
	this.shape_6.setTransform(10.7,20.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text4sl1, new cjs.Rectangle(0,0,123.2,37.9), null);


(lib.text3sl1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("Ag7BiIAAjDIB3AAIAAAlIhRAAIAAAqIA9AAIAAAkIg9AAIAAArIBRAAIAAAlg");
	this.shape.setTransform(112.8,20.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("AAlBiIAAiDIhICDIgmAAIAAjDIAmAAIAACDIBIiDIAlAAIAADDg");
	this.shape_1.setTransform(95.5,20.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AhLBiIAAjDIAkAAIAACeIAWAAIAAieIAiAAIAACeIAYAAIAAieIAjAAIAADDg");
	this.shape_2.setTransform(78.6,20.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("AhJBiIAAjDIAmAAIAAA8IApAAQAXABAPAJQAPAKAIAPQAHAOAAASQAAASgHAQQgIAPgPAKQgPAIgXABgAgjA9IApAAQALAAAGgFQAHgEADgHQADgHAAgIQAAgHgDgHQgDgIgHgEQgGgEgLAAIgpAAg");
	this.shape_3.setTransform(62.2,20.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2E2D").s().p("AAwBiIgwiKIgwCKIgmAAIBGjDIAhAAIBGDDg");
	this.shape_4.setTransform(44.6,20.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F2E2D").s().p("AgnBcQgQgJgJgQQgIgRgBgVIAAg4QABgWAIgQQAJgQAQgKQAQgJAXAAQAXAAARAJQARAKAIAQQAJAQAAAWIAAA4QAAAVgJARQgIAQgRAJQgRAJgXAAQgXAAgQgJgAgSg6QgIAEgEAIQgFAHAAAMIAAA4QAAALAFAIQAEAIAIAEQAJAEAJAAQALAAAHgEQAJgEAFgIQAEgIAAgLIAAg4QAAgMgEgHQgFgIgJgEQgHgEgLAAQgJAAgJAEg");
	this.shape_5.setTransform(27.5,20.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F2E2D").s().p("AhJBiIAAjDICAAAIAAAlIhbAAIAAAqIAwAAQAdgBAQARQARAPAAAbQAAAbgQAPQgQAPgeABgAgkA9IAxAAQAMAAAFgGQAHgFgBgLQAAgLgGgFQgHgFgKAAIgxAAg");
	this.shape_6.setTransform(10.9,20.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text3sl1, new cjs.Rectangle(0,0,123.2,37.9), null);


(lib.text2sl1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AgoAGIAAgLIBRAAIAAALg");
	this.shape.setTransform(112.5,22.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("Ag7BiIAAjDIB3AAIAAAlIhRAAIAAAqIA9AAIAAAkIg9AAIAAArIBRAAIAAAlg");
	this.shape_1.setTransform(78.8,20.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AhJBiIAAjDIAmAAIAAA8IApAAQAXABAPAJQAPAKAIAPQAHAOAAASQAAASgHAQQgIAPgPAKQgPAIgXABgAgjA9IApAAQALAAAGgFQAHgEADgHQADgHAAgIQAAgHgDgHQgDgIgHgEQgGgEgLAAIgpAAg");
	this.shape_2.setTransform(62.2,20.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("AAmBiIAAh9IgaBJIgXAAIgZhJIAAB9IglAAIAAjDIAnAAIAiBjIAkhjIAmAAIAADDg");
	this.shape_3.setTransform(44.5,20.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2E2D").s().p("Ag7BiIAAjDIB3AAIAAAlIhRAAIAAAqIA9AAIAAAkIg9AAIAAArIBRAAIAAAlg");
	this.shape_4.setTransform(27.8,20.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F2E2D").s().p("AgnBbQgQgJgJgPQgJgQAAgVIAAg4QAAgVAJgRQAJgQAQgJQARgJAWgBQAXABAQAIQARAJAIAPQAJAPABAVIgmAAQgCgPgJgIQgLgIgOAAQgJAAgIAEQgJAEgFAIQgEAIAAALIAAA4QAAALAEAIQAFAHAJAEQAIAEAJAAQAOAAALgIQAJgIACgOIAmAAQgBAUgJAPQgIAOgRAIQgQAIgXAAQgWABgRgJg");
	this.shape_5.setTransform(10.7,20.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text2sl1, new cjs.Rectangle(0,0,123.2,37.9), null);


(lib.text1sl1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AAkB3IAAiCIhHCCIgmAAIAAjCIAmAAIAACCIBHiCIAmAAIAADCgAgIhYQgNAAgIgJQgJgIAAgNIANAAQAAAHAGAEQAEAFAHABIARAAQAHgBAFgFQAEgEABgHIANAAQAAANgJAIQgIAJgNAAg");
	this.shape.setTransform(50.9,18.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("AgnBcQgQgJgJgQQgIgRgBgVIAAg4QABgWAIgQQAJgQAQgKQAQgJAXAAQAXAAARAJQARAKAIAQQAJAQAAAWIAAA4QAAAVgJARQgIAQgRAJQgRAJgXAAQgXAAgQgJgAgSg6QgHAEgFAIQgFAHgBAMIAAA4QABALAFAIQAFAIAHAEQAJAEAJAAQAKAAAIgEQAJgEAFgIQAEgIAAgLIAAg4QAAgMgEgHQgFgIgJgEQgIgEgKAAQgJAAgJAEg");
	this.shape_1.setTransform(33.9,20.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AhLBiIAAjDIAjAAIAACeIAYAAIAAieIAiAAIAACeIAWAAIAAieIAkAAIAADDg");
	this.shape_2.setTransform(17,20.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("AhJBiIAAjDIAmAAIAAA8IApAAQAXABAPAJQAPAKAIAPQAHAOAAASQAAASgHAQQgIAPgPAKQgPAIgXABgAgjA9IApAAQALAAAGgFQAHgEADgHQADgHAAgIQAAgHgDgHQgDgIgHgEQgGgEgLAAIgpAAg");
	this.shape_3.setTransform(0.6,20.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2E2D").s().p("AAwBiIgwiKIgwCKIgmAAIBGjDIAhAAIBGDDg");
	this.shape_4.setTransform(-17,20.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F2E2D").s().p("AgnBcQgRgJgIgQQgJgRAAgVIAAg4QAAgWAJgQQAIgQARgKQAQgJAXAAQAXAAARAJQAQAKAKAQQAIAQAAAWIAAA4QAAAVgIARQgKAQgQAJQgRAJgXAAQgXAAgQgJgAgRg6QgJAEgFAIQgEAHAAAMIAAA4QAAALAEAIQAFAIAJAEQAIAEAJAAQAKAAAJgEQAIgEAEgIQAFgIABgLIAAg4QgBgMgFgHQgEgIgIgEQgJgEgKAAQgJAAgIAEg");
	this.shape_5.setTransform(-34.1,20.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F2E2D").s().p("AhJBiIAAjDICBAAIAAAlIhbAAIAAAqIAvAAQAdgBAQARQAQAPABAbQAAAbgQAPQgQAPgeABgAgjA9IAwAAQALAAAGgGQAGgFABgLQAAgLgHgFQgHgFgKAAIgwAAg");
	this.shape_6.setTransform(-50.7,20.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text1sl1, new cjs.Rectangle(-61.6,0,123.2,37.9), null);


(lib.slide4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.slide4, null, null);


(lib.slide4250x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.sl4250x250();
	this.instance.parent = this;
	this.instance.setTransform(-62.5,-57);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.slide4250x250, new cjs.Rectangle(-62.5,-57,125,114), null);


(lib.slide2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.sl2250x250();
	this.instance.parent = this;
	this.instance.setTransform(-62.5,-57);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.slide2, new cjs.Rectangle(-62.5,-57,125,114), null);


(lib.slide1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.sl1250x250();
	this.instance.parent = this;
	this.instance.setTransform(-56,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.slide1, new cjs.Rectangle(-56,-60,125,114), null);


(lib.sl3250x250_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.sl3250x250();
	this.instance.parent = this;
	this.instance.setTransform(-62.5,-57);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sl3250x250_1, new cjs.Rectangle(-62.5,-57,125,114), null);


(lib.logoai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AgwBFQgTgQgBggIAoAAQACAZAZAAQAZAAAAgSQAAgPgUAAIgMAAIAAgdIAMAAQARAAABgOQAAgHgHgEQgGgEgKAAQgZAAgCAZIgoAAQABgcAQgRQASgTAgAAQAfAAASAOQASANAAAWQAAAJgFAIQgEAJgIAFQAUAIAAAXQAAAbgTAQQgUAPgeAAQgdAAgTgQg");
	this.shape.setTransform(42.2,8.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2E2D").s().p("AAbBRIAAh5Ig1AAIAAB5IgpAAIAAihICHAAIAAChg");
	this.shape_1.setTransform(42,43.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2E2D").s().p("AAbBRIAAh5Ig1AAIAAB5IgpAAIAAihICHAAIAAChg");
	this.shape_2.setTransform(6.8,8.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F2E2D").s().p("AgxBCQgSgSAAgfIAAgiQAAgeASgSQASgTAfAAQAfAAASASQASAQABAeIgpAAQgBgMgHgGQgIgHgLAAQgLAAgHAHQgIAHAAANIAAAkQAAANAIAIQAHAHALAAQALAAAIgHQAHgGABgMIApAAQgBAdgSARQgSASgfAAQgfAAgSgTg");
	this.shape_3.setTransform(6.8,43.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CD3DC").s().p("AjfDkIgGh7IFblaIBbADIAABYIAUAeIlqFqg");
	this.shape_4.setTransform(25.2,26.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,49.2,52.2);


(lib.frametextsl1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6CD3DC").ss(1,1,1).p("AsasEIY1AAIAAYJI41AAg");
	this.shape.setTransform(-60.1,-11.9,0.821,0.811,0,0,0,-79.1,-0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.frametextsl1, new cjs.Rectangle(-61.3,-75.2,132.4,127.3), null);


(lib.family_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.family();
	this.instance.parent = this;
	this.instance.setTransform(-103,-75.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.family_1, new cjs.Rectangle(-103,-75.5,206,151), null);


(lib.desclogoai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2E2D").s().p("AB3BeIAAgNIgoAAIAAg7IALAAIAAAwIAGAAIAAgwIAKAAIAAAwIAGAAIAAgwIALAAIAAAwIAHAAIAAAYgAgJBRQgEgBgDgDQgDgEgBgEQgCgDAAgGIAAgRQAAgEACgFIAEgHQADgCAEgCQAFgCAEABQAGgBADACQAEACADACQAEAEABADQABAFAAAEIAAARQAAAGgBADQgCAEgDAEQgDADgEABQgDACgGAAQgEAAgFgCgAgFAiIgEAEQgBACAAADIAAARQAAAEABADIAEADIAFABIAFgBQADgBABgCQACgDAAgEIAAgRQAAgDgCgCIgEgEQgCgBgDgBQgCABgDABgAkMBQQgEgCgEgFQgCgFAAgGIALAAQAAADACACQABADADAAIAFABIAFgBIADgCQABAAAAgBQAAAAAAgBQABAAAAgBQAAgBAAgBIgBgDIgCgCIgFAAIgKAAIAAgMIAJAAQAEAAABgCQABAAAAAAQABgBAAAAQAAgBAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAgBIgEgBIgFACQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAgBABIgBAFIgMAAQAAgEACgFQACgDACgDIAHgEIAJgBIAFAAIAGACQADACABABQADADAAACQACADAAAEQAAAEgCADIgEAFQADACACAEQACADAAAFQAAAEgCADIgEAGIgHADIgIACQgHAAgFgDgADYBRIgPgXIgGAAIAAAXIgLAAIAAg7IALAAIAAAYIAGAAIAQgYIAOAAIgVAdIAUAegACmBRIAAgnIgWAnIgMAAIAAg7IAMAAIAAAoIAWgoIALAAIAAA7gAA+BRIAAgnIgWAnIgLAAIAAg7IALAAIAAAoIAWgoIAMAAIAAA7gAhHBRIAAg7IAYAAIAJACQAEABADAEIADAGIACAIIgCAHIgDAHQgDADgEABQgDACgGAAIgNAAIAAASgAg8A0IANAAIAEgBIADgCIACgDIAAgDIAAgDIgCgEIgDgCIgEgBIgNAAgAhsBRIAAgwIgRAAIAAgLIAtAAIAAALIgRAAIAAAwgAijBQIgHgEQgDgDgCgEQgBgEAAgFIAAgRQAAgEABgFIAFgHQADgCAEgCQAEgCAFABQAFgBAFACIAHAEIAEAGQACAEAAAFIgMAAIgBgFIgEgDQgCgBgEgBQgDABgCABIgEAEQgCACAAADIAAARQAAAEACACQACADACAAQACACADAAIAGgBIAEgDQABgCAAgDIAMAAQAAAEgCAEIgEAGQgDADgEABIgKABQgFAAgEgBgAi/BRIgEgMIgVAAIgEAMIgMAAIAVg7IALAAIAVA7gAjHA7IgHgTIgGATIANAAgAAxASIgFgBIgDgDQgCgCAAgDIAFAAIAAADIACACIADABIAFAAIADgBIACgCIAAgDIAEAAIgBAFIgDADIgFABgAjXgVQgEgBgDgEQgDgBgCgFIgBgJIAAgRIABgJQACgFADgDIAHgDQAEgDAFAAQAGAAAEADQAEABADACQADADABAFIACAJIAAARIgCAJQgCAFgCABQgCAEgFABQgEACgGAAQgFAAgEgCgAjThEIgEAEQgCADAAADIAAARQAAADACACIAEAFIAFABIAGgBIAEgFQABgCAAgDIAAgRQAAgDgBgDIgEgEIgGgBgAENgUIAAgoIgWAoIgMAAIAAg8IAMAAIAAApIAWgpIALAAIAAA8gADagUIAAg8IALAAIAAA8gAC2gUIAAg8IAMAAIAAATQAGAAADACQAEABADADIADAHIABAIIgBAHIgDAHIgHAFQgDABgGAAgADCgfIAEgBIADgCIACgDIAAgDIAAgEIgCgDIgDgCIgEgBgACmgUIAAgZIgWAAIAAAZIgMAAIAAg8IAMAAIAAAYIAWAAIAAgYIALAAIAAA8gABygUIAAgZIgWAAIAAAZIgLAAIAAg8IALAAIAAAYIAWAAIAAgYIALAAIAAA8gAAigUIAAg8IAkAAIAAAMIgYAAIAAAMIASAAIAAALIgSAAIAAAOIAYAAIAAALgAALgUIAAgmIgHAWIgHAAIgIgWIAAAmIgLAAIAAg8IAMAAIAKAfIAKgfIAMAAIAAA8gAhEgUIAAg8IAkAAIAAAMIgZAAIAAAMIATAAIAAALIgTAAIAAAOIAZAAIAAALgAh7gUIAAg8IAYAAQAGAAAEACIAGAEIAEAIQABADAAAEQAAAFgBADIgEAGQgDAEgDABQgEABgGABIgMAAIAAASgAhvgxIAMAAIAFgBIACgDIACgDIABgDIgBgEIgCgCIgCgCIgFgBIgMAAgAivgUIAAg8IAYAAQAFABAFACQAEACADADQACAEAAAFIgBAHIgEAGIAFAFQABAEAAADQAAAGgCAEQgCAEgEACQgFACgFAAgAikgfIAPAAQAEgBABgBQACgCAAgDIgBgDIgCgDIgEgBIgPAAgAikg4IANAAIAEgBIADgBIABgEIgBgDIgDgCIgEgBIgNAAgAkKgVQgEgCgDgDQgDgCgCgEQgBgEAAgFIAAgRIABgJQACgFADgDIAHgDQADgDAGAAQAGAAADACQAEACADACQADADACAEIACAJIgMAAIgCgGIgEgDIgFgBIgFABIgEAEQgCADAAADIAAARQAAADACACQABADADABIAFABIAFgBQABAAAAAAQABgBABAAQAAAAAAgBQABAAAAgBIACgFIAMAAIgCAIQgCAFgDABQgCADgFACQgDABgGAAQgFAAgEgBgAD/hTQAAAAgBAAQgBAAAAAAQgBgBAAAAQgBAAAAAAIgEgEQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAgBIAEAAIABADIACACIACABIAFAAIADgBIACgCIABgDIAEAAIgBAFIgEAEQgCABgDAAg");
	this.shape.setTransform(28,9.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,56.1,18.7);


(lib.border = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#2F2E2D").ss(1,1,1).p("AzhzhMAnDAAAMAAAAnDMgnDAAAg");
	this.shape.setTransform(5,-75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.border, new cjs.Rectangle(-121,-201,252,252), null);


(lib.anim5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.anim2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6CD3DC").s().p("AzmZ6MAAAgnsMAnNgMHMgAKAzzg");
	this.shape.setTransform(5.5,-75.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120,-241,251,331.5);


(lib.slide11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.slide1();
	this.instance.parent = this;
	this.instance.setTransform(-6.5,3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.slide11, new cjs.Rectangle(-62.5,-57,125,114), null);


(lib.anim14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.slide4250x250();
	this.instance.parent = this;
	this.instance.setTransform(127.5,-115);

	this.instance_1 = new lib.slide4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-190,172);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(65,-172,125,114);


(lib.anim13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.slide4250x250();
	this.instance.parent = this;
	this.instance.setTransform(127.5,-115);

	this.instance_1 = new lib.slide4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-190,172);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(65,-172,125,114);


(lib.anim8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.slide11();
	this.instance.parent = this;
	this.instance.setTransform(-28.7,-43.3);

	this.instance_1 = new lib.anim5("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(91.3,100.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.2,-100.3,125,114);


(lib.anim7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.slide11();
	this.instance.parent = this;
	this.instance.setTransform(-28.7,-43.3);

	this.instance_1 = new lib.anim5("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(91.3,100.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.2,-100.3,125,114);


// stage content:
(lib.pzspbf250x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.instance = new lib.border();
	this.instance.parent = this;
	this.instance.setTransform(120,200);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(375));

	// transition-sl5
	this.instance_1 = new lib.trans21sl2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(120,498.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(364).to({_off:false},0).to({y:160.5},7).wait(4));

	// text2-sl5
	this.instance_2 = new lib.text2sl5();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-116.5,117);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(314).to({_off:false},0).to({x:133.5},6).to({_off:true},52).wait(3));

	// text1-sl5
	this.instance_3 = new lib.text1sl5();
	this.instance_3.parent = this;
	this.instance_3.setTransform(410.4,218);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(314).to({_off:false},0).to({x:117.7},6).to({_off:true},52).wait(3));

	// desc-logo - sl3
	this.instance_4 = new lib.desclogoai("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(278,52,0.839,0.839,0,0,0,28.6,9.4);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(314).to({_off:false},0).to({x:88},5).to({_off:true},53).wait(3));

	// logo - sl3
	this.instance_5 = new lib.logoai("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(280,37.3,0.85,0.85,0,0,0,24.6,26.2);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(308).to({_off:false},0).to({regY:26.1,x:33.9,y:37.2},5).to({_off:true},59).wait(3));

	// transition-sl4
	this.instance_6 = new lib.trans3();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-128,200);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(302).to({_off:false},0).to({x:120},7).to({_off:true},59).wait(7));

	// text3-sl4
	this.instance_7 = new lib.text3sl4();
	this.instance_7.parent = this;
	this.instance_7.setTransform(125.5,219.1,0.05,0.05,0,0,0,1,1);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(273).to({_off:false},0).to({regX:0,regY:0,scaleX:1.15,scaleY:1.15,x:134.9,y:219,alpha:1},5).to({scaleX:1,scaleY:1,x:133.6},2).wait(2).to({_off:true},32).wait(61));

	// text2-sl4
	this.instance_8 = new lib.text2sl4();
	this.instance_8.parent = this;
	this.instance_8.setTransform(125.4,190.1,0.05,0.05,0,0,0,1,1);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(264).to({_off:false},0).to({regX:0,regY:0,scaleX:1,scaleY:1,x:132.4,y:190,alpha:1},5).to({scaleX:1.15,scaleY:1.15,x:133.5},2).to({regX:1.1,regY:1.1,scaleX:1,scaleY:1,y:191.1},2).to({_off:true},41).wait(61));

	// text1-sl4
	this.instance_9 = new lib.text1sl4();
	this.instance_9.parent = this;
	this.instance_9.setTransform(125.4,162.1,0.05,0.05,0,0,0,1,1);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(254).to({_off:false},0).to({regX:0,regY:0,scaleX:1,scaleY:1,x:132.4,y:162,alpha:1},6).to({scaleX:1.15,scaleY:1.15,x:133.5},2).to({scaleX:1,scaleY:1,x:132.4},2).to({_off:true},50).wait(61));

	// family
	this.instance_10 = new lib.family_1();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-112.9,75.9,0.85,0.85);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(249).to({_off:false},0).to({regX:0.1,regY:0.2,x:125.1,y:76},5).to({_off:true},60).wait(61));

	// transition-sl3
	this.instance_11 = new lib.trans3();
	this.instance_11.parent = this;
	this.instance_11.setTransform(375,200);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(233).to({_off:false},0).to({x:120},7).to({_off:true},74).wait(61));

	// slide-4
	this.instance_12 = new lib.anim13("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(190,172);
	this.instance_12._off = true;

	this.instance_13 = new lib.anim14("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(60,172);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_12}]},198).to({state:[{t:this.instance_13}]},5).to({state:[]},91).wait(81));
	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(198).to({_off:false},0).to({_off:true,x:60},5).wait(172));

	// slide-3
	this.instance_14 = new lib.sl3250x250_1();
	this.instance_14.parent = this;
	this.instance_14.setTransform(-67.5,57);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(198).to({_off:false},0).to({x:62.5},5).to({_off:true},91).wait(81));

	// text3-sl3
	this.instance_15 = new lib.text3sl3();
	this.instance_15.parent = this;
	this.instance_15.setTransform(125.7,212,0.05,0.05,0,0,0,1,0);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(185).to({_off:false},0).to({regX:0,scaleX:1,scaleY:1,x:137.2,alpha:1},6).to({scaleX:1.15,scaleY:1.15,x:139.1},2).to({regX:0.1,regY:0.1,scaleX:1,scaleY:1,x:137.3,y:212.1},2).to({_off:true},99).wait(81));

	// text2-sl3
	this.instance_16 = new lib.text2sl3();
	this.instance_16.parent = this;
	this.instance_16.setTransform(125.2,162.1,0.05,0.05,0,0,0,0,1);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(175).to({_off:false},0).to({regY:0,scaleX:1,scaleY:1,x:127.6,y:162,alpha:1},6).to({scaleX:1.15,scaleY:1.15,x:128},2).to({regX:0.1,regY:0.1,scaleX:1,scaleY:1,x:127.7,y:162.1},2).to({_off:true},109).wait(81));

	// text1-sl3
	this.instance_17 = new lib.text1sl3();
	this.instance_17.parent = this;
	this.instance_17.setTransform(125.4,135.1,0.05,0.05,0,0,0,1,1);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(165).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:1,scaleY:1,x:132.5,alpha:1},6).to({regX:0,regY:0,scaleX:1.15,scaleY:1.15,x:133.5,y:135},2).to({scaleX:1,scaleY:1,x:132.4},2).to({_off:true},119).wait(81));

	// transition-sl2
	this.instance_18 = new lib.trans21sl2();
	this.instance_18.parent = this;
	this.instance_18.setTransform(120,498.5);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(158).to({_off:false},0).to({y:160.5},7).to({_off:true},129).wait(81));

	// slide-2
	this.instance_19 = new lib.slide2();
	this.instance_19.parent = this;
	this.instance_19.setTransform(318.5,57);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(128).to({_off:false},0).to({x:187.5},5,cjs.Ease.get(0.5)).to({_off:true},161).wait(81));

	// slide-1
	this.instance_20 = new lib.anim7("synched",0);
	this.instance_20.parent = this;
	this.instance_20.setTransform(-36.7,99.4);
	this.instance_20._off = true;

	this.instance_21 = new lib.anim8("synched",0);
	this.instance_21.parent = this;
	this.instance_21.setTransform(91.3,100.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_20}]},128).to({state:[{t:this.instance_21}]},5).to({state:[]},161).wait(81));
	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(128).to({_off:false},0).to({_off:true,x:91.3,y:100.4},5).wait(242));

	// text2-sl2
	this.instance_22 = new lib.text2sl2();
	this.instance_22.parent = this;
	this.instance_22.setTransform(125.7,206.1,0.05,0.05,0,0,0,1,1);
	this.instance_22.alpha = 0;
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(115).to({_off:false},0).to({regX:0,regY:0,scaleX:1,scaleY:1,x:137.2,y:206,alpha:1},6).to({scaleX:1.15,scaleY:1.15,x:139.1},2).to({scaleX:1,scaleY:1,x:137.2},2).to({_off:true},169).wait(81));

	// text1-sl2
	this.instance_23 = new lib.text1sl2();
	this.instance_23.parent = this;
	this.instance_23.setTransform(125.4,150.1,0.05,0.05,0,0,0,1,1);
	this.instance_23.alpha = 0;
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(105).to({_off:false},0).to({regX:0,regY:0,scaleX:1,scaleY:1,x:132.4,y:150,alpha:1},6).to({scaleX:1.15,scaleY:1.15,x:133.5},2).to({scaleX:1,scaleY:1,x:132.4},2).to({_off:true},179).wait(81));

	// transition-sl1
	this.instance_24 = new lib.anim2("synched",0);
	this.instance_24.parent = this;
	this.instance_24.setTransform(121,496.5);
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(98).to({_off:false},0).to({x:120,y:159.5},7).to({_off:true},189).wait(81));

	// frame-text
	this.instance_25 = new lib.frametextsl1();
	this.instance_25.parent = this;
	this.instance_25.setTransform(124.8,162.8,0.05,0.05,0,0,0,1,1);
	this.instance_25.alpha = 0;
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(54).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:1.1,scaleY:1.1,x:119.8,alpha:1},6).to({regX:0,regY:0,scaleX:1.15,scaleY:1.15,x:119.5,y:162.7},2).to({scaleX:1.1,scaleY:1.1},2).to({_off:true},230).wait(81));

	// text4-sl1
	this.instance_26 = new lib.text4sl1();
	this.instance_26.parent = this;
	this.instance_26.setTransform(125.5,176.8,0.05,0.05,0,0,0,71,22);
	this.instance_26.alpha = 0;
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(44).to({_off:false},0).to({regX:70.2,regY:21.4,scaleX:1,scaleY:1,x:133.6,y:197.1,alpha:1},6,cjs.Ease.get(0.5)).to({regX:70.1,scaleX:1.15,scaleY:1.15,x:134.8,y:200.3},2).to({regX:70.2,scaleX:1,scaleY:1,x:133.6,y:197.1},2).to({_off:true},240).wait(81));

	// text3-sl1
	this.instance_27 = new lib.text3sl1();
	this.instance_27.parent = this;
	this.instance_27.setTransform(125.5,146.7,0.05,0.05,0,0,0,71,22);
	this.instance_27.alpha = 0;
	this.instance_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(34).to({_off:false},0).to({regX:70.2,regY:21.4,scaleX:1,scaleY:1,x:133.6,y:167,alpha:1},6,cjs.Ease.get(0.5)).to({scaleX:1.15,scaleY:1.15,x:134.9,y:170.2},2).to({scaleX:1,scaleY:1,x:133.6,y:167},2).to({_off:true},250).wait(81));

	// text2-sl1
	this.instance_28 = new lib.text2sl1();
	this.instance_28.parent = this;
	this.instance_28.setTransform(125.5,116.7,0.05,0.05,0,0,0,71,22);
	this.instance_28.alpha = 0;
	this.instance_28._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(24).to({_off:false},0).to({regX:70.2,regY:21.4,scaleX:1,scaleY:1,x:133.6,y:137,alpha:1},6,cjs.Ease.get(0.5)).to({scaleX:1.15,scaleY:1.15,x:134.9,y:140.2},2).to({scaleX:1,scaleY:1,x:133.6,y:137},2).to({_off:true},260).wait(81));

	// text1-sl1
	this.instance_29 = new lib.text1sl1();
	this.instance_29.parent = this;
	this.instance_29.setTransform(128.5,86.7,0.05,0.05,0,0,0,70.2,21.1);
	this.instance_29.alpha = 0;
	this.instance_29._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(14).to({_off:false},0).to({regY:21.4,scaleX:1,scaleY:1,x:195.2,y:107,alpha:1},6,cjs.Ease.get(0.5)).to({scaleX:1.15,scaleY:1.15,x:205.8,y:110.2},2).to({regX:70.3,scaleX:1,scaleY:1,x:195.3,y:107},2).to({_off:true},270).wait(81));

	// desc-logo
	this.instance_30 = new lib.desclogoai("synched",0);
	this.instance_30.parent = this;
	this.instance_30.setTransform(278.3,51.3,0.839,0.839,0,0,0,28.6,9.4);
	this.instance_30._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(8).to({_off:false},0).to({x:88,y:52},5).to({_off:true},281).wait(81));

	// logo
	this.instance_31 = new lib.logoai("synched",0);
	this.instance_31.parent = this;
	this.instance_31.setTransform(280,37.3,0.85,0.85,0,0,0,24.6,26.2);
	this.instance_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(2).to({_off:false},0).to({regY:26.1,x:33.9,y:37.2},5).to({_off:true},287).wait(81));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AzhTiMAAAgnDMAnDAAAMAAAAnDg");
	this.shape.setTransform(125,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(375));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(124.5,124.5,251,251);
// library properties:
lib.properties = {
	id: 'BB1F55DD0DF8CD43AF22ACF19B73D8FD',
	width: 250,
	height: 250,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/family.jpg", id:"family"},
		{src:"images/sl1250x250.jpg", id:"sl1250x250"},
		{src:"images/sl2250x250.jpg", id:"sl2250x250"},
		{src:"images/sl3250x250.jpg", id:"sl3250x250"},
		{src:"images/sl4250x250.jpg", id:"sl4250x250"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['BB1F55DD0DF8CD43AF22ACF19B73D8FD'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;